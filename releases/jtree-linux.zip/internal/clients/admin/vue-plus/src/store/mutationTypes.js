export const HELLO = 'HELLO'
