app.description = 'Players can enter an id or name.';

var inputStage = app.newStage('input');
