// DEFINE STAGES
var thankyouStage = app.newStage('finished');
