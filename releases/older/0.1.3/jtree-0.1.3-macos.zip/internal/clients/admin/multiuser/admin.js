// PARAMETERS
var DEFAULT_NUM_PARTICIPANT_VIEWS   = 4;

// VARIABLES
var playerFieldsToSkip = [
    'app',
    'appIndex',
    'clients',
    'group',
    'groupId',
    'id',
    'link',
    'numPoints',
    'participantId',
    'period',
    'roomId',
    'sessionId',
    'stageId',
    'stage',
    'stageIndex',
    'stageTimerStart',
    'stageTimerDuration',
    'stageTimerTimeLeft',
    'stageTimerRunning',
    'status',
    'time',
    'participant'
];

var participantTimers = {};

function reloadParticipantView() {
    for (var i in selectedParticipants) {
        var id = selectedParticipants[i];
        var url = location.origin + '/' + id;
        $('#participant-frame-' + id).attr('src', url)
    }
}

setView = function(a) {
    $('.view').addClass('hidden');
    $('#view-' + a).removeClass('hidden');
    $('.view-tab').removeClass('active');
    $('#tab-' + a).addClass('active');
}

deleteParticipantBtn = function() {
    var pId = $('#deleteParticipantSelect').val();
    server.deleteParticipant(pId);
}

partLink = function(pId) {
    if (jt.interfaceMode === 'basic') {
        return jt.serverURL() + '/' + pId;
    } else {
        return jt.serverURL() + '/' + pId + '?sessionId=' + jt.data.session.id;
    }
}

roomLink = function(roomId) {
    return jt.serverURL() + '/room/' + roomId;
}

function ParticipantRow(participant) {
    var div = $('<tr class="participant-' + participant.id +'">');
    div.append($('<td>').text(participant.id));
    div.append($('<td class="participant-' + participant.id + '-numClients">').text(participant.numClients));
    div.append($('<td><a href="http://' + partLink(participant.id) + '" target="_blank">' + partLink(participant.id) + '</a></td>'));
    div.append($('<td class="participant-' + participant.id + '-numPoints">').text(round(participant.numPoints, 2)));
    div.append($('<td id="app-' + participant.id + '">').text('-'));
//    div.append($('<td class="participant-' + participant.id + '-appIndex">').text('-'));
    var periodDiv = $('<td>');
    periodDiv.append($('<span class="participant-' + participant.id + '-periodIndex">').text('-'));
    div.append(periodDiv);
    div.append($('<td class="participant-' + participant.id + '-groupId">').text('-'));
    div.append($('<td class="participant-' + participant.id + '-stageId">').text('-'));
    div.append($('<td class="participant-' + participant.id + '-timeleft"><span class="minutes"></span>:<span class="seconds"></span></td>'));
    div.append($('<td class="participant-' + participant.id + '-status">').text('-'));
    return div;
}

function clearSelectedParticipants() {
    const numSelected = selectedParticipants.length;
    for (let i=0; i<numSelected; i++) {
        removeSelectedParticipant(selectedParticipants[0]);
    }
}

function roundValue(obj, dec) {
    if (isNumber(obj)) {
        return round(obj-0, dec);
    } else {
        return obj;
    }
}

function setNumParticipantsFromModal() {
    const amt = $('#setNumParticipants').val();
    server.setNumParticipants(amt);
}

function showSetNumPartsModal() {
    $('#setNumParticipants').val(objLength(jt.data.session.participants));
    $('#setNumParticipantsModal').modal('show');
}

function setParticipantPlayer(pId, player, pDiv) {

    // Get the set of current headers
    var headers = $('#session-participants-headers > th');
    var headersText = [];

    // For each of the current headers, try to add a value for the player.
    for (var j=0; j<headers.length; j++) {
        var field = headers[j].innerHTML;
        if (!playerFieldsToSkip.includes(field)) {
            var foundEl = pDiv.find('.player-' + pId + '-' + field).length > 0;
            var value = '';
            if (player !== null) {
                if (player[field] !== undefined) {
                    value = player[field];
                }
            } else {
                foundEl = false;
            }
            if (!foundEl) {
                pDiv.append($('<td class="player-' + pId + '-' + field +'">'));
            }
            headersText.push(field);
            pDiv.find('.player-' + pId + '-' + field).text(roundValue(value, 2));
        }
    }

    // For each value in the player object,
    for (var i in player) {
        if (!playerFieldsToSkip.includes(i)) {
            if (!headersText.includes(i)) {
                addParticipantPlayerHeader(i);
                headersText.push(i);
            }
            pDiv.find('.player-' + pId + '-' + i).text(roundValue(player[i], 2));
        }
    }
    if (player !== null) {
        $('.participant-' + pId + '-status').text(player.status);
        if (player.status === 'active') {
            pDiv.addClass('player-active');
        } else {
            pDiv.removeClass('player-active');
        }
        var gId = groupId(player.groupId);
        if (player.group !== undefined) {
            gId = player.group.id;
        }
        msgs.playerSetStageIndex({participantId: player.id, stageIndex: player.stageIndex});
        msgs.participantSetGroupId({participantId: player.id, groupId: gId});
        clearInterval(participantTimers[pId]);
        if (player.stageTimerDuration === undefined) {
            var div = $('.participant-' + pId + '-timeleft');
            div.find('.minutes').text('');
            div.find('.seconds').text('');
        } else {
            if (player.stageTimerRunning) {
                var tl = player.stageTimerTimeLeft;
                var st = player.stageTimerStart;
                player.endTime = new Date(st).getTime() + tl;
                var now = Date.now();
                player.timeLeft = player.endTime - now;
                player.stageTimer = setInterval(function() {
                    var now = Date.now();
                    player.timeLeft = player.endTime - now;
                    if (player.timeLeft <= 0) {
                        clearTimeout(player.stageTimer);
                    }
                    var div = $('.participant-' + pId + '-timeleft');
                    var minutes = div.find('.minutes');
                    var seconds = div.find('.seconds');
                    jt.displayTimeLeft(minutes, seconds, player.timeLeft);
                }, jt.data.CLOCK_FREQUENCY);
                participantTimers[pId] = player.stageTimer;
            } else {
                player.timeLeft = player.stageTimerTimeLeft;
            }
            var div = $('.participant-' + pId + '-timeleft');
            var minutes = div.find('.minutes');
            var seconds = div.find('.seconds');
            jt.displayTimeLeft(minutes, seconds, player.timeLeft);
        }
    }

    let participant = player.participant;
    showPlayerCurApp(participant);
    $('.participant-' + participant.id + '-periodIndex').text(participant.periodIndex+1);

}

function updatePartClock() {
    displayTimeLeft($('#clock-minutes'), $('#clock-seconds'), data.timeLeft);
}

function sessionSetAutoplay(b) {
    const iframes = $('iframe.participant-frame');
    for (let i=0; i<iframes.length; i++) {
        let pId = $(iframes[i]).data('pId');
        setParticipantAutoplay(pId, b);
    }
}

function groupId(fullId) {
    if (fullId === undefined) {
        return '';
    }
    var i = fullId.indexOf('_group_');
    return fullId.substring(i + '_group_'.length);
}

function addParticipantPlayerHeader(name) {
    var headers = $('#session-participants-headers');
    headers.append($('<th>').text(name));
    var trows = $('#participants > tr');
    for (var i=0; i<trows.length; i++) {
        var tr = trows[i];
        var id = tr.children[0].innerHTML;
        var td = $('<td class="player-' + id + '-' + name +'">');
        $(tr).append(td);
    }
}

function CustomAppFolder(folder) {
    var div = $('<div>');
    div.addClass('custom-app-folder');
    var location = $('<div>').text(folder);
    location.addClass('custom-app-folder-location');
    div.append(location);
    var actions = $('<div>');
    actions.addClass('actions');
    div.append(actions);
    var fol = folder;
    var removeBtn = $('<a>')
        .click(fol, removeCustomAppFolder)
        .text("remove")
        .addClass('btn')
        .addClass('btn-sm')
        .addClass('btn-secondary')
        .attr('href', '#')
        .attr('role', 'button');
    actions.append(removeBtn);
    return div;
}

function ParticipantView(pId) {
    if (jt.data.session !== null && jt.data.session !== undefined) {
        var url = 'http://' + partLink(pId);
        var frame = $('<iframe>', {
            id:  'participant-frame-' + pId
        });
        $(frame).data('pId', pId);
        frame.attr('src', url);
        frame.addClass('participant-frame');
        return frame;
   } else {
       return null;
   }
}

function removeCustomAppFolder(folder) {

}

function showPlayerCurApp(participant) {
    var appText = participant.appIndex + '-';
    if (participant.appIndex < 1 || participant.appIndex > jt.data.session.apps.length) {
    } else {
        var app = jt.data.session.apps[participant.appIndex-1];
        appText = appText + app.id;
    }
    $('#app-' + participant.id).text(appText);
//    $('.participant-' + participant.id + '-appIndex').text(participant.appIndex);
}

function openClient(event) {
    // TODO
}

// DRAG-DROP UI
function showPanel(t, tt, ll, hh, ww, bb, rr, override) {
    var el = $(t);
    el.removeAttr('hidden');
}

function Panel(id, title, contentEl) {
    var card;
    var search = $('#panel-' + id);
    if (search.length > 0) {
        card = $(search[0]);
    } else {
        card = $('<div class="card panel ui-widget-content">');
        card.attr('id', 'panel-' + id);
        var cardHeader = $('<div>');
        cardHeader.addClass('card-header');
        card.append(cardHeader);
        var headerText = $('<span>').text(title);
        cardHeader.append(headerText);
    }
    // Set z-Index
    if (contentEl !== null) {
        // Close previous view, if any.
        $(card).find('.panel-content2').remove();

        card.append(contentEl);
        $(contentEl).addClass('panel-content2');
    }
    return card;
}

function participantOpenInNewTab() {
    for (var i in selectedParticipants) {
        var pId = selectedParticipants[i];
        participantOpenInNewTabId(pId);
    }
}

function participantOpenInNewTabId(id) {
    var url = location.origin + '/' + id;
    window.open(url);
}

function CardPanel(id, title, contentEl) {
    var cardBlock = $('<div class="card-block panel-content">');
    cardBlock.append(contentEl);
    var card = new Panel(id, title, cardBlock);
    return card;
}

function addCardPanel(id, title, contentEl) {
    var panel = new CardPanel(id, title, contentEl);
    panel.attr('hidden', true);
    $('body').append(panel);
    return panel;
}
function addPanel(id, title, contentEl) {
    var panel = new Panel(id, title, contentEl);
    panel.attr('hidden', true);
    $('body').append(panel);
    return panel;
}

// End DRAG-DROP UI

function setPlayerTimeLeft(participant, tl) {
    $('#timeleft-' + participant.id).text(tl);
}

function showPlayerCurPeriod(participant, p) {
    $('#period-' + participant.id).text(p);
}

function socketConnected() {
    server.refresh();
}

function ClientRow(obj) {
    var div = $('<tr>').attr('id', 'client-' + obj.id);
    div.append($('<td>').text(obj.id));
    div.append($('<td>').text(obj.pId));
    div.append($('<td>').text(obj.lastActivity));
    return div;
}

function showParticipants(participants) {
    resetParticipantsTable();
    sessionSetAutoplay(false);
    if (participants !== undefined) {
        for (var pId in participants) {
            var participant = participants[pId];
            showParticipant(participant);
        }
    }
}

function deleteParticipant(pId) {
    $('.participant-' + pId).remove();
    delete jt.data.session.participants[pId];
    $('#deleteParticipantSelect option[value=' + pId + ']').remove();
}

function resetParticipantsTable() {
    $('#participants').empty();
    $('#session-participants-headers').empty();
    const headers = ['id', 'clients', 'link', 'numPoints', 'app', 'period', 'group', 'stage', 'time', 'status'];
    for (let i=0; i<headers.length; i++) {
        $('#session-participants-headers').append($('<th>').text(headers[i]));
    }
}

function viewAllParticipants() {
    for (var pId in jt.data.session.participants) {
        var participant = jt.data.session.participants[pId];
        viewParticipant(participant.id);
    }
}

function viewParticipant(pId) {
    const view = new ParticipantView(pId);
    const elId = 'session-participant-' + pId;
    const existsAlready = $('#panel-' + elId).length > 0;
    const panel = addPanel(elId, 'Participant ' + pId, view);
    $('#panel-' + elId).addClass('participant-view');
    if (!existsAlready) {
        var newWinBtn = $('<button type="button" class="headerBtn close float-right"><i title="open in new window" class="fa fa-external-link"></i></button>');
        newWinBtn.click(function() {
            participantOpenInNewTabId(pId);
        });
        $($(panel).children()[0]).append(newWinBtn);
        var autoplayBtn = $('<button title="toggle autoplay" id="' + pId + '-autoplay" type="button" class="headerBtn close float-right">A</button>');
        autoplayBtn.click(function() {
            toggleParticipantAutoplay(pId);
        });
        $($(panel).children()[0]).append(autoplayBtn);
    }
    showPanel('#panel-' + elId, 0, 0, '', '', '', '', false);
    $('#views').append(panel);
}

function toggleParticipantAutoplay(pId) {
    const elId = 'panel-session-participant-' + pId;
    const el = $('#' + elId);
    const apEl = $('#' + pId + '-autoplay');
    setParticipantAutoplay(pId, !apEl.hasClass('headerBtn-on'));
}

function setParticipantAutoplay(pId, b) {
    const elId = 'panel-session-participant-' + pId;
    const el = $('#' + elId);
    const apEl = $('#' + pId + '-autoplay');
    if (b) {
        apEl.addClass('headerBtn-on');
    } else {
        apEl.removeClass('headerBtn-on');
    }
    server.setAutoplay(pId, b);
    // let iframe = el.find('iframe')[0];
    // if (iframe.contentWindow.setAutoplay !== undefined) {
    //     iframe.contentWindow.setAutoplay(b);
    // }
}

function showAppFolders(folders) {
    $('#custom-app-folders').empty();
    for (var i in folders) {
        var folder = folders[i];
        showCustomAppFolder(folder);
    }
}

function showCustomAppFolder(folder) {
    var folderRow = new CustomAppFolder(folder);
    $('#custom-app-folders').append(folderRow);
}

function showParticipant(participant) {
    var participantRow = new ParticipantRow(participant);
    $('#participants').append(participantRow);
    if (participant.player !== null) {
        participant.player.participant = participant;
        setParticipantPlayer(participant.id, participant.player, participantRow);
    }

    $('#deleteParticipantSelect').prepend($('<option>', {
        value: participant.id,
        text: participant.id
    }));

    $('#deleteParticipantSelect').val(participant.id);
}

function showClients(data) {
    $('#clients').empty();
    if (data !== undefined) {
        console.log('show clients (' + data.length + ')');
        for (var i in data) {
            var obj = data[i];
            showClient(obj);
        }
    }
}

function showClient(obj) {
    var row = new ClientRow(obj);
    $('#clients').append(row);
}

function StageRow(stage) {
    var div = $('<tr>');
    var name = $('<td>').text(stage.name);
    var wait = $('<td>').text(stage.waitForAll);
    var duration = $('<td>').text(stage.duration);
    div.append(name);
    div.append(wait);
    div.append(duration);
    return div;
}

function clickViewApp(event) {
    event.stopPropagation();
    viewApp(event.data.id, event.data.name);
}

function AppInfoRow(id, appInfo) {
    var div = $('<tr>');
    div.append($('<td>').text(id));
    var aId = id;
    var aName = appInfo.title;
    div.click({id: aId, name: aName}, server.createSessionAndAddApp)
    div.append($('<td>').text(appInfo.numPeriods));
    if (appInfo.groupSize === null) {
        appInfo.groupSize = '';
    }
    div.append($('<td>').text(appInfo.groupSize));
    return div;
}

function PredefQueue(id, queue) {
    var div = $('<tr>');
    div.append($('<td>').text(id));
    var apps = $('<td>');
    for (var i=0; i< queue.folders.length; i++) {
        var appId = queue.folders[i];
        var appExists = false;
        for (j in jt.data.ag.apps) {
            if (j === appId) {
                appExists = true;
            }
        }
        var appDiv = $('<div>').text((i+1) + '. ' + appId);
        appDiv.addClass('predefqueue-app');
        if (appExists) {
            appDiv.addClass('predefqueue-app-exists');
        } else {
            appDiv.addClass('predefqueue-app-notexists');
        }
        apps.append(appDiv);
    }
    div.append(apps);
    var actions = $('<td>');
    div.append(actions);
    var aId = id;
    var aName = queue.title;
    var runBtn = $('<a>')
        .click({id: aId, name: aName}, setQueueAndStart)
        .text("set as queue and start")
        .addClass('btn')
        .addClass('btn-sm')
        .addClass('btn-primary')
        .attr('href', '#')
        .attr('role', 'button');
    actions.append(runBtn);
    var setBtn = $('<a>')
        .click({id: aId, name: aName}, setQueue)
        .text("set as queue")
        .addClass('btn')
        .addClass('btn-sm')
        .addClass('btn-secondary')
        .attr('href', '#')
        .attr('role', 'button');
    actions.append(setBtn);
    var addBtn = $('<a>')
        .click({id: aId, name: aName}, addQueue)
        .text("add to queue")
        .addClass('btn')
        .addClass('btn-sm')
        .addClass('btn-secondary')
        .attr('href', '#')
        .attr('role', 'button');
    actions.append(addBtn);
    return div;
}

function SessionDiv(session) {
    var card = $('<div>').addClass('card').addClass('text-white').addClass('mb-2').addClass('mr-2');
    var cardblock = $('<div>').addClass('card-body');
    card.append(cardblock);
    if (session !== undefined) {
        if (session.active === true) {
            card.addClass('bg-primary');
        } else {
            card.addClass('bg-warning');
        }
        cardblock.append($('<h6>').text(session.name).addClass('card-title'));
        cardblock.append($('<div>').text('Active: ' + session.active));
        cardblock.append($('<div>').text('Apps: ' + session.appSequence));
        cardblock.append($('<div>').text('Participants: ' + session.numParticipants));
        var actions = $('<span>');
        cardblock.append(actions);
        var aId = session.name;
        var runBtn = $('<a>')
        .click({id: aId, name: aId}, server.openSession)
        .text("open")
        .addClass('btn')
        .addClass('btn-sm')
        .addClass('btn-secondary')
        .attr('href', '#')
        .attr('role', 'button');
        actions.append(runBtn);
        var delBtn = $('<a class="btn btn-sm btn-secondary" href="#" role="button">')
        .click({id: aId, name: aId}, server.deleteSession)
        .text("delete")
        actions.append(delBtn);
    }
    return card;
}

function setQueue(event) {
    event.stopPropagation();
    console.log('set session queue: ' + event.data.id + ', name = ' + event.data.name);
    server.setQueue(event.data.id);
}

function setQueueAndStart(event) {
    event.stopPropagation();
    console.log('set session queue and start: ' + event.data.id + ', name = ' + event.data.name);
    server.setQueueAndStart(event.data.id);
}

function addQueue(event) {
    event.stopPropagation();
    console.log('add queue to session: ' + event.data.id + ', name = ' + event.data.name);
    server.addQueue(event.data.id);
}

function addAppToSessionAndStart(event) {
    event.stopPropagation();
    console.log('add app to session and start: ' + event.data.id + ', name = ' + event.data.name);
    server.addAppToSessionAndStart(event.data.id);
    setPage('participants');
}

function addAppToSession(event) {
    event.stopPropagation();
    console.log('add app to session: ' + event.data.id + ', name = ' + event.data.name);
    server.addAppToSession({id: event.data.id, sId: data.session.id});
}

function addSelectedAppToQueue() {
    var id = $('#addAppToQueueSelect').val();
    server.sessionAddApp(id);
}

function SessionAppRow(app, i) {
    var div = $('<tr>');
    try {
        div.append($('<td>').text(app.id));
        div.append($('<td>').text(app.numPeriods));
        // div.append($('<td>').text(app.groupSize));
        // div.append($('<td>').text(app.numGroups));

        var aId = app.id;
        var sId = data.session.id;
        var delBtn = $('<button class="btn btn-sm btn-secondary">')
        .click({aId: aId, i: i, sId: sId}, server.sessionDeleteApp)
        .text("delete");
        div.append($('<td>').append(delBtn));
    } catch (err) {
    }
    return div;
}

function showAppInfos(appInfos) {
    $('#appInfos').empty();
    $('#addAppToQueueSelect').empty();
    for (var a in appInfos) {
        $('#appInfos').append(AppInfoRow(a, appInfos[a]));
        $('#addAppToQueueSelect').append($('<option>', {
            value: a,
            text: a
        }));
    }
}

function showPredefQueues(queues) {
    $('#predefQueues').empty();
    for (var a in queues) {
        queues[a].id = a;
        $('#predefQueues').append(PredefQueue(a, queues[a]));
    }
}

function showSessions() {
    $('#active-sessions').empty();
    $('#inactive-sessions').empty();
    $('#view-sessions-list').empty();
    for (var i=0; i<jt.data.sessions.length; i++) {
        showSessionRow(jt.data.sessions[i]);
    }

}

function showSessionInView(session) {
}

function showSessionRow(session) {
    $('#view-sessions-list').prepend(SessionDiv(session));
    if (session.active === true) {
        $('#active-sessions').prepend(SessionDiv(session));
    } else {
        $('#inactive-sessions').prepend(SessionDiv(session));
    }
}

function updateSessionApps() {
    $('#session-apps-table').empty();
    if (jt.data.session !== null && jt.data.session !== undefined) {
        for (var a in jt.data.session.apps) {
            var app = jt.data.session.apps[a];
            $('#session-apps-table').append(SessionAppRow(app, a));
        }
    }
}

function showStages(stages) {
    $('#stages').empty();
    for (var s in stages) {
        var stageRow = new StageRow(stages[s]);
        $('#stages').append(stageRow);
    }
}

function showSessionAppName(an) {
    $('#sessionAppName').text(an);
}

function updateSessionCanPlay(session) {
    if (session.isRunning) {
        $('#sessionResumeBtn').addClass('disabled');
        $('#sessionPauseBtn').removeClass('disabled');
        $('#session-canPlay').text('running');
    } else {
        $('#sessionResumeBtn').removeClass('disabled');
        $('#sessionPauseBtn').addClass('disabled');
        $('#session-canPlay').text('paused');
    }
}

function updateSessionActive(session) {
    if (session.active) {
        $('#sessionSetActiveBtn').addClass('disabled');
        $('#sessionSetInactiveBtn').removeClass('disabled');
        $('#session-status').text('active');
    } else {
        $('#sessionSetActiveBtn').removeClass('disabled');
        $('#sessionSetInactiveBtn').addClass('disabled');
        $('#session-status').text('inactive');
    }
}

function viewCurApp() {
    viewApp(data.appId, data.appName);
}

function viewApp(id, name) {
    console.log('view app ' + id);
    $('#app-name').text(name);
    $('#app-id').text(id);
    if (data.viewedApp == null || id != data.viewedApp.id) {
        server.getApp(id);
    } else {
        showStages(data.viewedApp.stages);
        setPage('app');
    }
    data.viewedAppId = id;
}

function showPId(id) {
    $('#jt-admin-menu-login').text(id);
}

function addAppFolder() {
    var folder = $('#input-app-folder').val();
    server.addAppFolder(folder);
}

function refresh(ag) {
    console.log('refresh');

    jt.data.clockRunning = ag.clockRunning;
    jt.data.ag = ag;
    jt.data.predefinedQueues = ag.predefinedQueues;
    jt.data.appInfos = ag.apps;
    jt.data.appName = ag.appName;
    jt.data.sessions = ag.sessions;
    jt.data.rooms = ag.rooms;

    showAppInfos(ag.apps);
    showPredefQueues(ag.predefinedQueues);
    showSessions();
    showAppFolders(ag.appFolders);
    showRooms();
}

function showRooms() {
    $('#rooms-list').empty();
    for (var i in jt.data.rooms) {
        var room = jt.data.rooms[i];
        showRoom(room);
    }
}

function showRoom(room) {
    var div = $('<div>');
    div.text(room.displayName);
    div.click(function() {
        openRoom(room);
    });
    $('#rooms-list').append(div);
}

function openRoom(room) {
    setView('room');
    $('#view-room-displayName').text(room.displayName);
    $('#view-room-id').text(room.id);
    $('#view-room-secure').text(room.useSecureURLs);
    $('#view-room-roomLink').text(roomLink(room.id));
    for (var i in room.labels) {
        var label = room.labels[i];
        var labDiv = $('<div>').text(label);
        labDiv.addClass('view-room-label');
        $('#view-room-labels').append(labDiv);
    }
}

function removeClient(cId) {
    $('#client-' + cId).remove();
}

function appId(id) {
    var index = id.indexOf('app_');
    var indexPrd = id.indexOf('period_');
    if (index > -1) {
        if (indexPrd < 0) {
            return id.substring(index+'app_'.length);
        } else {
            return id.substring(index+'app_'.length, indexPrd);
        }
    }
    return null;
}

jt.connected = function() {

    // Register to listen for messages defined in msgs object.
    // https://stackoverflow.com/questions/29917977/get-event-name-in-events-callback-function-in-socket-io
    for (var i in msgs) {
        console.log('listening for message ' + i);
        (function(i) {
            jt.socket.on(i, function(d) {
                console.log('received message ' + i + ': ' + JSON.stringify(d));
                eval('msgs.' + i + "(d)");
            });
        })(i);
    }

    jt.socket.on('refresh-admin', function(ag) {
        refresh(ag);
    });

    jt.socket.on('refresh-apps', function(appInfos) {
        console.log('refresh-apps');
        jt.data.appInfos = appInfos;
        showAppInfos(appInfos);
    });

    jt.socket.on('stage-end', function(a) {
        stageEnd(a);
        console.log('stage-end');
    });

    jt.socket.on('get-app', function(a) {
        jt.data.viewedApp = a;
        viewApp(a.id, a.title);
    });

    jt.socket.on('get-room', function(a) {
        data.viewedRoom = a;
        showRoom();
    });

    jt.socket.on('add-participant', function(participant) {
        if (participant.session.id === jt.data.session.id) {
            console.log('add participant: ' + participant);
            jt.data.session.participants[participant.id] = participant;
            showParticipant(participant);
            //        viewParticipant(participant.id);
        }
    });

    jt.socket.on('add-client', function(client) {
        if (client.session.id === jt.data.session.id) {
            console.log('add client: ' + client);
            jt.data.session.clients.push(client);
            showClient(client);
            var participant = findByIdWOJQ(jt.data.session.participants, client.pId);
            if (participant !== null) {
                participant.numClients++;
                $('.participant-' + client.pId + '-numClients').text(participant.numClients);
            }
        }
    });

    jt.socket.on('remove-client', function(client) {
        console.log('remove client: ' + client);
        deleteById(jt.data.session.clients, client.id);
        removeClient(client.id);
        var participant = findByIdWOJQ(jt.data.session.participants, client.pId);
        if (participant != null) {
            participant.numClients--;
            $('.participant-' + client.pId + '-numClients').text(participant.numClients);
        }
    });

// TODO: move all message functionality here
    jt.socket.on('messages', function(msgs) {
        for (m in msgs) {
            var msg = msgs[m];
            // eval(msg.type + "(msg.data)");
            switch (msg.type) {
                case 'set-session-app-status':
                    jt.data.session.appSequence[msg.data.index].status = msg.data.status;
                    showSessionAppSequence();
                    break;
                case 'clock-start':
                    startClock(msg.data.endTime);
                    break;
                case 'refresh-admin':
                    refresh(msg.data);
                    break;
            }
        }
    });

    var interfaceMode = localStorage.getItem('interfaceMode');
    if (interfaceMode === null) {
        interfaceMode = 'basic';
    }
    jt.setInterfaceMode(interfaceMode);

  var sId = localStorage.getItem("sessionId");
  if (sId !== null) {
      server.openSessionId(sId);
  } else {
      server.sessionCreate();
  }

}

jt.setInterfaceMode = function(mode) {
    jt.interfaceMode = mode;
    localStorage.setItem('interfaceMode', mode);
    if (mode === 'basic') {
        $('#admin-interface-basic').prop('checked', true);
    }
    else if (mode === 'advanced') {
        $('#admin-interface-advanced').prop('checked', true);
    }
    $('[admin-interface][admin-interface="' + mode + '"]').show();
    $('[admin-interface][admin-interface!="' + mode + '"]').hide();
}

closeViews = function() {
    var views = $('.participant-view');
    views.each(function() {
        this.remove();
    });
}

jt.socketConnected = function() {
    server.refreshAdmin();
}

updateAllowNewParts = function() {
    $('#allowNewParts')[0].checked = jt.data.session.allowNewParts;
}
