const fs        = require('fs-extra');
const path      = require('path');
const Utils     = require('./Utils.js');

/**
 * A room for running sessions.
*/
class Room {

    constructor(id) {
        this.id             = id;
        this.displayName    = id;
        this.useSecureURLs  = true;
        this.labels         = [];
    }

    static load(folder, id) {
        var room = new Room(id);
        var fn = path.join(folder, 'room.json');
        if (fs.existsSync(fn)) {
            var json = Utils.readJSON(fn);
            if (json.displayName !== undefined) {
                room.displayName = json.displayName;
            }
            if (json.useSecureURLs !== undefined) {
                room.useSecureURLs = json.useSecureURLs;
            }
        }

        // Read labels
        var labelsFN = path.join(folder, 'labels.txt');
        if (fs.existsSync(labelsFN)) {
            var all = fs.readFileSync(labelsFN).toString();
            var lines = all.split('\n');
            for (var i=0; i<lines.length; i++) {
                try {
                    if (lines[i].length > 0) {
                        room.labels.push(lines[i]);
                    }
                } catch (err) {
                    console.log(err);
                }
            }
        }

        return room;
    }

}

var exports = module.exports = {};
exports.new = Room;
exports.load = Room.load;
