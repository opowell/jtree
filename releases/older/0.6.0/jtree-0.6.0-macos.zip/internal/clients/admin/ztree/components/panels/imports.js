document.write('<script src="/admin/ztree/components/panels/TreatmentPanel.js"></script>');
