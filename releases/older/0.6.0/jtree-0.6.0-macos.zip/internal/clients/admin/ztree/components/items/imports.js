document.write('<script src="/admin/ztree/components/items/Button.js"></script>');
document.write('<script src="/admin/ztree/components/items/Input.js"></script>');
document.write('<script src="/admin/ztree/components/items/RadioSelect.js"></script>');
