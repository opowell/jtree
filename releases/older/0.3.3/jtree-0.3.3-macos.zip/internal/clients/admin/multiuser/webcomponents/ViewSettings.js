class ViewSettings extends HTMLElement {
    connectedCallback() {
      this.innerHTML = `
      <div id='view-settings' class='view hidden'>
          <h2>Settings</h2>

          <div>Located in jtree.path/internal/settings.js</div>

          <h6 class='mt-3 mb-2'>Queues menu</h6>
          <small class="form-text text-muted">By default, Queues are hidden until one has been created.</small>
          <div class="form-check mt-3">
            <input class="form-check-input" type="radio" name="settings-queues-menu" id="queues-mode-hide" value="basic" onchange='jt.setQueuesMode("hide");'>
            <label class="form-check-label" for="queues-mode-hide">
                Hide
            </label>
          </div>
          <div class="form-check mt-3">
            <input class="form-check-input" type="radio" name="settings-queues-menu" id="queues-mode-show" value="basic" onchange='jt.setQueuesMode("show");'>
            <label class="form-check-label" for="queues-mode-show">
                Show
            </label>
          </div>

          <h6 class='mt-3 mb-2'>Interface mode</h6>
          <div class="form-check mt-3">
            <input class="form-check-input" type="radio" name="admin-interface" id="admin-interface-basic" value="basic" onchange='jt.setInterfaceMode("basic");'>
            <label class="form-check-label" for="admin-interface-basic">
                Single user
            </label>
            <small class="form-text text-muted">The default configuration.</small>
          </div>
          <div class="form-check mt-3">
            <input class="form-check-input" type="radio" name="admin-interface" id="admin-interface-advanced" value="advanced" onchange='jt.setInterfaceMode("advanced");'>
            <label class="form-check-label" for="admin-interface-advanced">
                Multiple users
            </label>
            <small class="form-text text-muted">For use on shared servers and lab facilities. Allows Rooms and/or Users.</small>
          </div>

          <h6 class='mt-3 mb-2'>Content folders</h6>
          <div>jtree.path/apps</div>
          <div>jtree.path/queues</div>
          <div>jtree.path/sessions</div>

      </div>
      `;
    }
}

jt.setInterfaceMode = function(mode) {
    jt.interfaceMode = mode;
    localStorage.setItem('interfaceMode', mode);
    if (mode === 'basic') {
        $('#admin-interface-basic').prop('checked', true);
    }
    else if (mode === 'advanced') {
        $('#admin-interface-advanced').prop('checked', true);
    }
    $('[admin-interface][admin-interface="' + mode + '"]').show();
    $('[admin-interface][admin-interface!="' + mode + '"]').hide();
}

jt.setQueuesMode = function(mode) {
    jt.queuesMode = mode;
    localStorage.setItem('queuesMode', mode);
    if (mode === 'show') {
        $('#queues-mode-show').prop('checked', true);
    }
    else if (mode === 'hide') {
        $('#queues-mode-hide').prop('checked', true);
    }
    $('[queues-mode][queues-mode="' + mode + '"]').show();
    $('[queues-mode][queues-mode!="' + mode + '"]').hide();
}

window.customElements.define('view-settings', ViewSettings);
