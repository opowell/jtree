class ClientHTMLEditorModal extends HTMLElement {
    connectedCallback() {
      this.innerHTML = `
      <div class="modal fullPageModal" tabindex="-1" role="dialog">
          <div style='max-width: 100%; max-height: 100%; margin: 0px' class="modal-dialog" role="document">
              <div class="modal-content" style="border-width: 0px; border-radius: 0px;">
                  <div class="modal-header">
                      <h5 class="modal-title">Edit client.html</h5>
                      <button type="button" class="btn btn-sm btn-primary" onclick='jt.appSaveClientHTML();'>Save</button>
                      <button type="button" class="close" data-dismiss="modal">
                          <span>&times;</span>
                      </button>
                  </div>
                  <div class="modal-body" style="padding: 0rem;">
                      <div id='edit-app-clienthtml' style='height: 90vh; width: 100%;'></div>
                  </div>
              </div>
          </div>
      </div>
      `;
    }


}

window.customElements.define('clienthtmleditor-modal', ClientHTMLEditorModal);
