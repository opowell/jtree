class ViewApp extends HTMLElement {
    connectedCallback() {
      this.innerHTML = `
      <div id='view-app' class='view hidden'>
          <h2 id='view-app-displayName'></h2>

          <div class="view-buttons btn-group">
                <button class="btn btn-outline-primary btn-sm" onclick='jt.startSessionWithApp()'>
                    <i class="fa fa-play"></i>&nbsp;&nbsp;Start session
                </button>
              <button class="btn btn-outline-secondary btn-sm" onclick='jt.deleteApp()'>
                  <i class="fa fa-trash"></i>&nbsp;&nbsp;Delete
              </button>
          </div>

          <!-- APP TABS -->
          <ul class="nav nav-tabs">
            <li class="nav-item">
              <div id='tab-app-view' class="nav-link subview-tab app-tabBtn" onclick='jt.setAppView("view");'>
                  <i class="fa fa-info"></i>&nbsp;&nbsp;Info
              </div>
            </li>
            <li class="nav-item">
              <div id='tab-app-preview' class="nav-link subview-tab app-tabBtn" onclick='jt.setAppView("preview");'>
                  <i class="fa fa-eye"></i>&nbsp;&nbsp;Preview
              </div>
            </li>
          </ul>

          <!-- APP - INFO -->
          <div id='view-app-view' class='subview app-tab hidden'>
              <div style='display: grid; grid-template-columns: 7rem 1fr; grid-column-gap: 0.3em;'>
                    <div class="col-sm-2 col-form-label">Id</div>
                    <div id='view-app-id' class='col-sm-10 col-form-label'></div>

                  <div class="col-sm-2 col-form-label">
                      app.js
                      <button class="btn btn-outline-primary btn-sm" onclick='$("#editAppJSModal > div").modal("show");'>
                          <i class="fa fa-edit"></i>
                      </button>
                  </div>
                  <pre class='col-sm-10 col-form-label'><code id='view-app-appjs' class='javascript'></code></pre>

                  <div class="col-sm-2 col-form-label">
                      client.html
                      <button class="btn btn-outline-primary btn-sm" onclick='$("#editClientHTMLModal > div").modal("show");'>
                          <i class="fa fa-edit"></i>
                      </button>
                  </div>
                  <pre class='col-sm-10 col-form-label'><code id='view-app-clienthtml' class='html'></code></pre>

          </div>

          </div>

          <!-- APP - EDIT -->
          <div id='view-app-edit' class='subview app-tab hidden'>
              <div class="btn-group">
                  <button type="submit" class="btn btn-sm btn-outline-primary" onclick='jt.saveAppAndView();'>
                      <i class="fa fa-save"></i>&nbsp;Save and view
                  </button>
                  <button type="submit" class="btn btn-outline-secondary btn-sm" onclick='jt.saveApp();'>
                      <i class="fa fa-save"></i>&nbsp;Save
                  </button>
                  <button type="submit" class="btn btn-outline-secondary btn-sm" onclick='setView("app")'>
                      <i class="fa fa-times"></i>&nbsp;Cancel
                  </button>
              </div>

              <div class="form-group row">
                  <label for="edit-app-id" class="col-sm-2 col-form-label">Id</label>
                  <div class="col-sm-10">
                      <input type="text" style='max-width: 20rem;' class="form-control" id="edit-app-id" placeholder="Id">
                  </div>
              </div>

              // <div class="form-group row">
              //     <div class="col-sm-2 col-form-label">client.html</div>
              //     <div class='col-sm-10 col-form-label' id='edit-app-clienthtml' style='height: 30rem;'></div>
              // </div>

          </div>

          <div id='view-app-preview' class='subview app-tab hidden' style='display: grid; grid-template-columns: 7rem 1fr; grid-column-gap: 0.3em;'>

              <div class="col-sm-2 col-form-label">Options</div>
              <div class='col-sm-10 col-form-label' id='view-app-options'></div>

              <div class="col-sm-2 col-form-label">#####</div>
              <div class='col-sm-10 col-form-label'>Preview is based on values given above for the app options.</div>

              <div class="col-sm-2 col-form-label">Description</div>
              <div class='col-sm-10 col-form-label' id='view-app-description'></div>

              <div class="col-sm-2 col-form-label">Stages</div>
              <div class='col-sm-10 col-form-label' id='view-app-stages'></div>

              <div class="col-sm-2 col-form-label">Periods</div>
              <div class='col-sm-10 col-form-label' id='view-app-periods'></div>

              <div class="col-sm-2 col-form-label">client preview</div>
              <div class='col-sm-10 col-form-label' >
                  <iframe id='view-app-clientpreview' style='width: 100%; height: 40rem;'>
                  </iframe>
              </div>
          </div>
      </div>
      `;
    }
}

jt.openApp = function(appId) {
    var app = jt.app(appId);
    setView('app');

    if (app.title === undefined) {
        $('#view-app-displayName').text(app.id);
    } else {
        $('#view-app-displayName').text(app.title);
    }

    $('#edit-app-id').val(app.id);
    $('#view-app-id').text(app.id);
    $('#view-app-description').text(app.description);
    $('#view-app-appjs').text(app.appjs);
    $('#view-app-clienthtml').text(app.clientHTML);

    var editor = ace.edit("edit-app-appjs");
    editor.setValue(app.appjs, -1);

    var editorCH = ace.edit("edit-app-clienthtml");
    editorCH.setValue(app.clientHTML, -1);

    hljs.highlightBlock($('#view-app-appjs')[0]);
    hljs.highlightBlock($('#view-app-clienthtml')[0]);

    try {
        $('#view-app-clientpreview').contents().find('html').html(app.clientHTML);
    } catch (err) {

    }

    $('#view-app-stages').text(app.stages.length + ': ' + app.stages);
    $('#view-app-periods').text(app.numPeriods);

    $('#view-app-options').empty();
    for (var i in app.options) {
        var option = app.options[i];
        var div = AppOptionDiv(option);
        $('#view-app-options').append(div);
    }
}

jt.deleteApp = function() {
    var appId = $('#view-app-id').text();
    jt.confirm(
        'Are you sure you want to delete App ' + appId + '?',
        function() {
            jt.socket.emit('deleteApp', appId);
        }
    );
}

jt.saveApp = function() {
    var app = {};
    app.origId = $('#view-app-id').text();
    app.id = $('#edit-app-id').val();
    var editor = ace.edit("edit-app-appjs");
    app.appjs = editor.getValue();

    var editorCH = ace.edit("edit-app-clienthtml");
    app.clientHTML = editorCH.getValue();

    jt.socket.emit('saveApp', app);

}

jt.saveAppAndView = function() {
    jt.saveApp();
    setView('app');
}

window.customElements.define('view-app', ViewApp);
