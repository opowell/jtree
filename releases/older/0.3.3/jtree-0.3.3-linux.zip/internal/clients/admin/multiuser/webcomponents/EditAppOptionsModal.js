class EditAppOptionsModal extends HTMLElement {

    connectedCallback() {
      this.innerHTML = `
      <div class="modal" id="editAppOptionsModal" tabindex="-1" role="dialog">
          <div class="modal-dialog" role="document" style='max-width: 90%;'>
              <div class="modal-content">
                  <div class="modal-header">
                      <h5 class="modal-title">Edit App Options</h5>
                      <button type="button" class="close" data-dismiss="modal">
                          <span>&times;</span>
                      </button>
                  </div>
                  <div class="modal-body">
                      <table class='table table-hover'>
                          <thead>
                              <tr>
                                  <th>name</th>
                                  <th>value</th>
                                  <th>description</th>
                              </tr>
                          </thead>
                          <tbody id='editAppOptionsModal-options'>
                          </tbody>
                      </table>
                  </div>
                  <div class="modal-footer">
                      <button type="button" id="editAppOptionsSaveBtn" class="btn btn-outline-primary">Save</button>
                      <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Cancel</button>
                  </div>
              </div>
          </div>
      </div>
      `;
    }
}

jt.setEditAppOptionsData = function(app, options, onSaveFunc) {
    $('#editAppOptionsModal .modal-title').text('Edit App Options: ' + app.id);
    $('#editAppOptionsModal-options').empty();
    $('#editAppOptionsModal').data('app', app);
    $('#editAppOptionsSaveBtn').attr('onclick', onSaveFunc);
    for (var i in app.options) {
        var option = app.options[i];
        var div = AppOptionRow(option, app, options);
        $('#editAppOptionsModal-options').append(div);
    }
}

AppOptionRow = function(option, app, options) {
    var selected = undefined;
    if (app[option.name] !== undefined) {
        selected = app[option.name];
    }
    if (option.defaultVal !== undefined) {
        selected = option.defaultVal;
    }
    if (options !== undefined && options[option.name] !== undefined) {
        selected = options[option.name];
    }

    var div = $('<tr>');
    var nameEl = $('<td>').text(option.name);
    div.append(nameEl);
    var tdSel = $('<td class="option-input">');
    div.append(tdSel);
    switch (option.type) {
        case 'select':
        var select = $('<select class="form-control view-app-option" app-option-name="' + option.name + '" id="view-app-option-' + option.name + '">');
        tdSel.append(select);
        for (var j in option.values) {
            var optEl = $('<option value="' + option.values[j] + '">' + option.values[j] + '</option>');
            if (selected !== undefined && selected == option.values[j]) {
                optEl.prop('selected', true);
            }
            select.append(optEl);
        }
        break;
        case 'text':
            var input = $('<input type="text" class="form-control" app-option-name="' + option.name + '" id="view-app-option-' + option.name + '">');
            input.val(option.defaultVal);
            tdSel.append(input);
            break;
        case 'number':
            var tagText = '<input type="number" class="form-control"';
            if (option.min !== null) {
                tagText += ' min=' + option.min;
            }
            if (option.max !== null) {
                tagText += ' max=' + option.max;
            }

            if (option.step !== null) {
                tagText += ' step=' + option.step;
            }
            if (selected !== null && selected !== undefined) {
                tagText += ' value=' + selected;
            } else {
                tagText += ' value=' + option.defaultVal;
            }
            var input = $(tagText + ' class="view-app-option form-control" app-option-name="' + option.name + '" id="view-app-option-' + option.name + '">');
            tdSel.append(input);
            break;
    }
    var description = option.description;
    if (description === undefined) {
        description = 'None given.';
    }
    div.append($('<td>').text(description));
    return div;

}

window.customElements.define('editappoptions-modal', EditAppOptionsModal);
