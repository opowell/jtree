// Add administrators.
settings.admins['A1'] = {id: 'A1', pwd: 'adminPWD'};
settings.admins['A2'] = {id: 'A2', pwd: 'adminPWD'};
settings.admins['AdminNoPwd'] = {id: 'AdminNoPwd'};

// Add predefined queues.
settings.predefinedQueues['manec20'] = {
    folders: ['enter-second-id', 'dutch-auction', 'display-profit']
};

//settings.adminUI = 'clients/adminWindow';
settings.logToConsole = false;
