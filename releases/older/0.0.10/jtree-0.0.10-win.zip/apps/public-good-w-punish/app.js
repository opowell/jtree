app.numPeriods  = 3;
app.groupSize   = 4;
app.endowment   = 20;
app.punMult     = 2;
app.prodMult    = 2;

var decideStage = app.newStage('decide');

var punishStage = app.newStage('punish');
punishStage.updateObject = 'group'; // To show data from other players in group.
punishStage.waitForGroup = true;

var resultsStage = app.newStage('results');
resultsStage.waitForGroup = true;
resultsStage.updateObject = 'group'; // To show data from other players in group.
resultsStage.groupPlay = function(group) { // when a group starts this stage
    group.contributions = Utils.sum(group.players, 'contribution');
    group.production = group.contributions * app.prodMult;
    group.prodPerPlayer = group.production / group.players.length;

    for (let i=0; i<group.players.length; i++) { // i = 0, 1, 2, 3
        group.players[i].sentPuns = 0;
        group.players[i].receivedPuns = 0;
    }

    for (let i=0; i<group.players.length; i++) { // i = 0, 1, 2, 3
        var player = group.players[i];
        player.points = app.endowment - player.contribution + group.prodPerPlayer;
        let id = player.idInGroup;
        // Player i's punishment of other group members.
        for (let j=0; j<group.players.length; j++) {
            if (i !== j) {
                let punishment = group.players[j]['pun' + id];
                player.points = player.points - punishment*app.punMult;
                player.receivedPuns += punishment;
                group.players[j].points = group.players[j].points - punishment;
                group.players[j].sentPuns += punishment;
            }
        }
    }
}
