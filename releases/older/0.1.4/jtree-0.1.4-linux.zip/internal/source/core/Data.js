const fs        = require('fs-extra');
const Utils     = require('../Utils.js');
const path      = require('path');
const Session   = require('../Session.js');
const App       = require('../App.js');
const Room      = require('../Room.js');

/** The data object. */
class Data {

    /**
     * FUNCTIONALITY
     * - initialize fields
     * - commence storing time information {@link Data#storeTimeInfo}.
     * @param  {Object} jt The server.
     */
    constructor(jt) {

        /**
        * The server.
         * @type Object
         */
        this.jt = jt;

        /**
         * A dummy session for loading apps, {@link Data#createSession}.
         * @type Session
         */
        this.dummySession   = this.createSession(false, false); // for loading code only.

        /**
         * The last time the server was on, {@link Data#loadLastTimeOn}.
         * @type number
         */
        this.lastTimeOn     = this.loadLastTimeOn();

        /**
         * The list of available apps, loaded from the contents of the {@link Settings#appsFolder} folder.
         * @type Object
         */
        this.apps = this.loadApps();

        /**
         * Available [Sessions]{@link Session}, loaded from the contents of the 'sessions' folder.
         * Sorted in ascending order according to time created.
         * @type Array of {@link Session}.
         */
        this.sessions = this.loadSessions();

        this.rooms = this.loadRooms();

        this.storeTimeInfo();
    }

    /**
     * Set a timeout to write the time info {@link Data#storeTimeInfo}. Timeout length is {@link Settings#autoSaveFreq} milliseconds.
     *
     * CALLED FROM
     * - {@link Data#storeTimeInfo}
     *
     */
    callStoreTimeInfoFunc() {
        setTimeout(this.storeTimeInfo.bind(this), this.jt.settings.autoSaveFreq);
    }

    /**
     * getMostRecentActiveSession -
     *
     * CALLED FROM:
     * - {@link StaticServer.sendClientPage}.
     *
     * @return {Session|null}  The session, or null if none exists.
     */
    getMostRecentActiveSession() {
        for (var i=this.sessions.length-1; i>=0; i--) {
            if (this.sessions[i].active === true) {
                return this.sessions[i];
            }
        }
        return null;
    }

    /**
     * FUNCTIONALITY
     * write current time to disk
     * set timeout for next write {@link Data#callStoreTimeInfoFunc}.
     *
     * CALLED FROM:
     * - [Data()]{@link Data}
     * - {@link Data#callStoreTimeInfoFunc}
     *
     */
    storeTimeInfo() {
        var fn = path.join(this.jt.path, this.jt.settings.serverTimeInfoFilename);
        var now = Date.now();
        fs.writeJSON(fn, now, this.callStoreTimeInfoFunc.bind(this));
    }

    app(id, session) {
        if (this.jt.settings.reloadApps) {
            return this.loadAppMetaData(id, session);
        } else {
            return this.apps[id];
        }
    }

    loadApp(id, session, folder) {
        var app = null;
        if (folder === null) {
            folder = this.apps[id].fn;
        }
        var isFolder = Utils.isDirectory(folder);
        var pathToCheck = path.join(folder, 'app.js');
        if (isFolder && fs.existsSync(pathToCheck)) {
            var app = new App.new(session, id);
            try {
                eval(fs.readFileSync(pathToCheck) + '');
            } catch (err) {
                console.log('Error loading app: ' + folder);
                console.log(err.stack);
            }
            app.folder = folder;
        }
        return app;
    }

    loadAppMetaData(id, folder) {
        var metaData = null;
        var app = this.loadApp(id, this.dummySession, folder);
        if (app !== null) {
            metaData = app.metaData();
            metaData.fn = folder;
        }
        return metaData;
    }

    loadAppDir(dir, out) {
        if (Utils.isDirectory(dir)) {
            var appDirContents = fs.readdirSync(dir);
            for (var i in appDirContents) {
                var id = appDirContents[i];
                let md = this.loadAppMetaData(id, path.join(dir, id));
                if (md !== null) {
                    md.id = id;
                    out[id] = md;
                }
            }
        }
    }

    saveRoom(room) {
        this.deleteRoom(room.originalId);
        var newRoom = new Room.new(room.id);
        newRoom.displayName     = room.displayName;
        newRoom.labels          = room.labels;
        newRoom.useSecureURLs   = room.useSecureURLs;
        this.createRoomFromRoom(newRoom);
    }

    deleteRoom(id) {
        try {
            fs.removeSync(this.roomPath(id));
            for (var i in this.rooms) {
                if (this.rooms[i].id === id) {
                    this.rooms.splice(i, 1);
                    break;
                }
            }
        } catch (err) {
            
        }
    }

    loadApps() {
        var out = {};
        for (var i in this.jt.settings.appFolders) {
            var folder = this.jt.settings.appFolders[i];
            this.loadAppDir(path.join(this.jt.path, folder), out);
        }
        return out;
    }

    /**
     * loadSessions - description
     *
     * CALLED FROM:
     * - {@link Data.constructor}.
     *
     * @return {type}  Array of sessions.
     */
    loadSessions() {
        var out = [];

        const sessPath = path.join(this.jt.path, this.jt.settings.sessionsFolder);
        fs.ensureDirSync(sessPath);

        var dirContents = fs.readdirSync(sessPath)
        for (var i in dirContents) {
            var folder = dirContents[i];
            var session = this.loadSession(folder);
            if (session !== null) {
                out.push(session);
            }
        }
        return out;
    }

    roomPath(id) {
        return path.join(this.roomsPath(), id);
    }

    roomsPath() {
        return path.join(this.jt.path, this.jt.settings.roomsPath);
    }

    room(id) {
        return Utils.findByIdWOJQ(this.rooms, id);
    }

    loadRooms() {
        var out = [];
        var fullPath = this.roomsPath();

        if (Utils.isDirectory(fullPath)) {
            var dirContents = fs.readdirSync(fullPath);
            for (var i in dirContents) {
                try {
                    var id = dirContents[i];
                    var room = Room.load(this.roomPath(id), id);
                    out.push(room);
                } catch (err) {
                    console.log(err);
                }
            }
        }

        return out;
    }

    createRoom(id) {
        // If already exists, return null.
        if (fs.existsSync(this.roomPath(id))) {
            return null;
        }

        var room = new Room.new(id);
        this.createRoomFromRoom(room);
        return room;
    }

    createRoomFromRoom(room) {
        try {
            fs.mkdirSync(this.roomPath(room.id));
        } catch (err) {}

        try {
            var config = {};
            config.displayName = room.displayName;
            config.useSecureURLs = room.useSecureURLs;
            fs.writeJSONSync(path.join(this.roomPath(room.id), 'room.json'), config);
        } catch (err) {}

        try {
            for (var i in room.labels) {
                var label = room.labels[i].trim();
                // After removing leading and trailing white space, must have length > 0
                if (label.length > 0) {
                    fs.appendFileSync(path.join(this.roomPath(room.id), 'labels.txt'), label + '\n');
                }
            }
        } catch (err) {}

        try {
            room.genHashes();
        } catch (err) {}

        this.rooms.push(room);
    }

    loadSession(folder) {
        var out = null;
        try {
            var pathToFolder = path.join(this.jt.path, this.jt.settings.sessionsFolder + '/' + folder + '/');
            this.jt.log('loading session: ' + folder);
            if (folder !== null && fs.lstatSync(pathToFolder).isDirectory()) {
                out = Session.load(this.jt, folder, this);
            }
        } catch (err) {
            console.log('error loading session WS: ' + folder);
    //        console.log(err);
        }
        return out;
    }

    loadLastTimeOn() {
        var out = Date.now();
        try {
            out = fs.readJSONSync(this.js.settings.serverTimeInfoFilename);
        } catch (err) {
        }
        this.jt.log("last time on: " + out);
        return out;
    }

    getActiveSession(sessionId) {
        var session = null;
        if (sessionId == null || sessionId == undefined) {
            // return first active session
            for (var i in this.sessions) {
                if (this.sessions[i].active === true) {
                    session = this.sessions[i];
                    break;
                }
            }
        } else {
            session = this.getSession(sessionId);
        }
        return session;
    }

    getSession(sessionId) {
        return Utils.findByIdWOJQ(this.sessions, sessionId);
    }

    /**
     * createSession - description
     *
     * CALLED FROM:
     * - {@link Data#constructor}.
     *
     * @param  {type} save   description
     * @param  {type} active description
     * @return {Session}        description
     */
    createSession(save, active) {
        var sess = new Session.new(this.jt, null);
        if (save) {
            Utils.createFolder(sess.getOutputDir(), this.jt);
//            var line = 'participantId, clientId, playerId, msgName, data \n';
//            fs.appendFileSync(sess.getOutputDir() + '/messages.csv', line);
        }

        if (active === true) {
            sess.setActive(true);
        }

        if (save) {
            sess.save();
            this.jt.socketServer.emitToAdmins('addSession', sess.shell());
        }

        return sess;
    }

    // addAppFolder(folder) {
    //     settings.appFolders.push(folder);
    //     jt.loadAppDir(folder);
    //     jt.storeSettingAppFolders();
    // }

    // storeSettingAppFolders() {
    //     this.jt.writeJSON(path.join(process.cwd(), 'apps/customFolders.json'), this.jt.settings.appFolders);
    // }

    getAdmin(id, pwd) {
        if (id === null || id === 'null') {
            return null;
        }
        var admin = this.jt.settings.admins[id];
        if (admin !== null && admin !== undefined) {
            // If password required and does not match, then do not log in.
            if (admin.pwd !== null && admin.pwd !== pwd) {
                admin = null;
            }
        }
        return admin;
    }

    session(id) {
        return Utils.findByIdWOJQ(this.sessions, id);
    }

}

var exports = module.exports = {};
exports.new = Data;
