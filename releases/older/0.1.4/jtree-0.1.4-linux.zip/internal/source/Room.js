const fs        = require('fs-extra');
const path      = require('path');
const Utils     = require('./Utils.js');
const hash      = require('object-hash');


/**
 * A room for running sessions.
*/
class Room {

    constructor(id) {
        this.id             = id;
        this.displayName    = id;
        this.useSecureURLs  = true;
        this.labels         = [];
        this.hashes         = [];
    }

    static load(folder, id) {
        var room = new Room(id);

        // Read fields, if any.
        var fn = path.join(folder, 'room.json');
        if (fs.existsSync(fn)) {
            var json = Utils.readJSON(fn);
            if (json.displayName !== undefined) {
                room.displayName = json.displayName;
            }
            if (json.useSecureURLs !== undefined) {
                room.useSecureURLs = json.useSecureURLs;
            }
        }

        // Read labels, if any.
        var labelsFN = path.join(folder, 'labels.txt');
        if (fs.existsSync(labelsFN)) {
            var all = fs.readFileSync(labelsFN).toString();
            var lines = all.split('\n');
            for (var i=0; i<lines.length; i++) {
                try {
                    if (lines[i].length > 0) {
                        room.labels.push(lines[i]);
                        if (room.useSecureURLs) {
                            room.hashes.push(hash(lines[i]));
                        }
                    }
                } catch (err) {
                    console.log(err);
                }
            }
        }

        return room;
    }

    genHashes() {
        if (this.useSecureURLs) {
            for (var i in this.labels) {
                this.hashes.push(hash(this.labels[i]));
            }
        }
    }

}

var exports = module.exports = {};
exports.new = Room;
exports.load = Room.load;
