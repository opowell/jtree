// @flow

const Timer = require('./Timer.js');
const Utils     = require('./Utils.js');

/**
 * A stage of an {@link App}.
 */
class Stage {

    // name: string;
    // id: string;
    // duration: number;

    /**
     * constructor - description
     *
     * @param  {type} name description
     * @param  {type} app  description
     * @return {type}      description
     */
    // constructor(name: string, app: App) {
    constructor(name, app) {

        // for display only, should be unique.
        this.name       = name;
        this.id = this.name;

        // the app of this stage.
        this.app        = app;

        // timeout duration in seconds
        // if <= 0, then no timeout for this stage.
        this.duration 	= 0;

        /**
         * wait for all players in group before starting this stage.
         */
        this.waitForGroup = true;

        // when starting stage for a player, send 'player' object or not.
        // fields determined by player.outputFields.
        this.onPlaySendPlayer = true;

        // how far up the tree should be sent on update.
        // possible values: 'player', 'group'
        this.updateObject = 'player';

        // 'outputHide' fields are not included in output
        this.outputHide = [];
        // 'outputHideAuto' fields are not included in output.
        this.outputHideAuto = ['app', 'outputHide', 'outputHideAuto', 'content'];

        this.content = null;
    }

    /**
     * indexInApp - description
     *
     * @return {type}  description
     */
    indexInApp() {
        for (var i in this.app.stages) {
            if (this.app.stages[i] === this) {
                return parseInt(i);
            }
        }
        return -1;
    }

    /**
     * playerCanGroupProceedToNextStage - description
     *
     * @param  {type} player description
     * @return {type}        description
     */
    playerCanGroupProceedToNextStage(player) {
        // PROCEED GROUP
        var players = player.otherPlayersInGroup();
        for (var p in players) {
            var otherPlyr = players[p];
            if (!otherPlyr.atLeastFinishedStage(this, player.period())) {
                return false;
            }
        }
        return true;
    }

    canGroupPlay(group) {
        if (!this.waitForGroup) {
            return true;
        }
        // PROCEED GROUP
        var proceed = true;
        var players = group.players;
        for (var p in players) {
            var otherPlyr = players[p];
            if (otherPlyr.stageIndex < this.indexInApp() - 1) {
                proceed = false;
                break;
            }
            if (otherPlyr.status !== 'waiting') {
                proceed = false;
                break;
            }
        }
        return proceed;
    }

    groupPlayDefault(group) {

        if (this.duration > 0) {
            var stage = this;
            group.stageTimer = new Timer.new(
                function() {
                    stage.groupEnd(group);
                },
                this.duration*1000,
                this.indexInApp());
        }

        try {
            this.groupPlay(group);
            group.save();
        } catch (err) {
            console.log(err + '\n' + err.stack);
        }
        // if (this.waitForGroup) {
        //     this.app.groupMoveToNextStage(group);
        // }
    }

    groupEnd(group) {
        group.clearStageTimer();
        for (var p in group.players) {
            var player = group.players[p];
            this.playerEnd(player);
        }
    }


    /**
     * playerEnd - End this stage for the given player.
     *
     * If player is not in this stage, do nothing.
     * 1. Update the player's status.
     * 2. If player has no next stage, send update.
     * 3. If next stage has to wait for group
     * -- Check whether group can proceed.
     * -- If group can proceed, call {@link Stage.groupPlayDefault} and {@link App.groupMoveToNextStage}.
     * 4. Else move player to next stage, using {@link App.playerMoveToNextStage}.
     *
     * @param  {type} player description
     */
    playerEnd(player) {

        // If player is not at this stage, do nothing.
        if (player.stageIndex !== this.indexInApp()) {
            return;
        }

        // If participant is no longer in this period, or already waiting, do nothing.
        if (player.period().id !== player.participant.player.period().id || player.status === 'waiting') {
            return;
        }

        // Set the player's status to waiting.
        player.status = 'waiting';

        // If all other players in group are finished this stage,
        // then move group to next stage. If next stage has 'waitForGroup=true',
        // then all players are also moved to next stage. Otherwise, all other players
        // should already be in next stage, so just move this player ahead.
        var canGroupProceed = this.playerCanGroupProceedToNextStage(player);
        if (canGroupProceed) {
            var nextStage = this.app.nextStageForGroup(player.group);
            this.app.groupMoveToNextStage(player.group);
            if (nextStage !== null && !nextStage.waitForGroup) {
                this.app.playerMoveToNextStage(player);
            } else {
                player.emitUpdate2();
            }
        }

        // Otherwise just advance this player, if possible.
        else {
            // Player cannot advance, continue waiting and refresh clients.
            var nextStage = player.nextStage();
            if (nextStage === null || nextStage.waitForGroup) {
                player.emitUpdate2(); // notifies admins
            }
            // Player can advance, move to next stage.
            else {
                this.app.playerMoveToNextStage(player);
            }
        }
    }

    /**
    *  Called before the first player plays this stage.
    */
    groupPlay(group) {
    }

    canPlayerParticipate(player) {
        return true;
    }

    /**
     * playerPlayDefault - description
     *
     * CALLED FROM
     * {@link App#playerMoveToNextStage}
     *
     * @param  {type} player description
     * @return {type}        description
     */
    playerPlayDefault(player) {
        if (this.canPlayerParticipate(player)) {
            player.status = 'active';
            try {
                this.playerPlay(player);
                player.save();
            } catch(err) {
                console.log(err + '\n' + err.stack);
            }
            //player.sendUpdate(player.roomId());
            if (this.onPlaySendPlayer) {
                player.emitUpdate2();
            }
            if (!this.waitForGroup && this.duration > 0) {
                player.stageTimer = setTimeout(function () {this.playerEnd(player);}, this.duration*1000);
            }
        } else {
            this.playerEnd(player);
        }
    }

    getContent() {
        if (this.content == null) {
            this.content = getStageContents(this.app.id, this.id)
        }
        return this.content;
    }

    /**
     * Called when this player plays this stage.
     **/
    playerPlay(player) {
        // Overwrite in App.
    }

    /**
     * session - description
     *
     * @return {type}  description
     */
    session() {
        return this.app.session;
    }

    outputFields() {
        var fields = [];
        for (var prop in this) {
            if (
                !Utils.isFunction(this[prop]) &&
                !this.outputHide.includes(prop) &&
                !this.outputHideAuto.includes(prop)
            )
            fields.push(prop);
        }
        return fields;
    }

    shellWithParent() {
        var out = {};
        var fields = this.outputFields();
        for (var f in fields) {
            var field = fields[f];
            out[field] = this[field];
        }
        out['app.index'] = this.app.indexInSession();
        out.app = this.app.shell();
        return out;
    }

    /**
     * CALLED FROM:
     * - {@link Stage#save}
     * - {@link App#shellWithChildren}
     *
     * @return {type}  description
     */
    shell() {
        var out = {};
        var fields = this.outputFields();
        for (var f in fields) {
            var field = fields[f];
            out[field] = this[field];
        }
        out['app.index'] = this.app.indexInSession();
        return out;
    }

    getOutputDir() {
        return this.app.getOutputFN() + '/stages/';
    }

    /**
     * CALLED FROM:
     * - {@link App#saveSelfAndChildren}
     *
     * @return {type}  description
     */
    save() {
        try {
            this.session().jt.log('Stage.save: ' + this.id);
            var toSave = this.shell();
    //        Utils.writeJSON(this.getOutputDir() + this.indexInApp() + '_' + this.id + '.json', toSave);
            this.session().saveDataFS(toSave, 'STAGE');
        } catch (err) {
            console.log('Error saving stage ' + this.id + ': ' + err);
        }
    }

}

var exports = module.exports = {};
exports.new = Stage;
exports.load = Stage.load;
