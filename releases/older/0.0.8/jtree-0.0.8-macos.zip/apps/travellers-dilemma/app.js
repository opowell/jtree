app.numPeriods  = 3;
app.groupSize   = 2;
app.lowerBound  = 10;
app.upperBound  = 50;

var decideStage = app.newStage('decide');
decideStage.waitForGroup = false;

var resultsStage = app.newStage('results');
resultsStage.duration = 30; // in seconds
resultsStage.groupPlay = function(group) { // when a group starts this stage
    group.lowestNumber = null;
    // Find out winning number.
    for (var i in group.players) { // i = 0, 1, 2, 3
        var player = group.players[i];
        if (group.lowestNumber === null || player.number < group.lowestNumber) {
            group.lowestNumber = player.number;
        }
    }
    // Assign points
    for (var i in group.players) {
        var player = group.players[i];
        if (player.number <= group.lowestNumber) {
            player.points = 1;
        } else {
            player.points = 0;
        }
    }
}
