const fs        = require('fs-extra');
const path      = require('path');
const jsonfile  = require('jsonfile');

/**
 * Set of utility functions.
 * */
class Utils {

    /**
    * isDirectory - description
    *
    * @param  {type} pathToCheck description
    * @return {type}             description
    */
    static isDirectory(pathToCheck) {
        if (fs.existsSync(pathToCheck)) {
            return fs.lstatSync(pathToCheck).isDirectory();
        } else {
            return false;
        }
    }

    /**
     * CALLED FROM:
     * - {@link Session#addApp}
     *
     * @param  {type} sourceDir description
     * @param  {type} destDir description
     * @return {type}           description
     */
    static copyFiles(sourceDir, destDir, jt) {
        this.createFolder(destDir, jt);
        try {
          fs.copySync(sourceDir, destDir);
        } catch (err) {
          console.error(err);
        }
    }

    static shells(list) {
        var out = [];
        for (var p in list) {
            out.push(list[p].shell());
        }
        return out;
    }

    static readJS(file) {
        // Empty white space to force conversion to UTF-8.
        return fs.readFileSync(file) + '';
    }

    /**
    *
    * @param  {type} file description
    * @return {type}      description
    */
    static readJSON(file) {
        try {
            return jsonfile.readFileSync(file);
        } catch(err) {
            return null;
        }
    }

    static getHeaders(fields, skipFields, headers) {
        for (var f in fields) {
            var prop = fields[f];
            if (!skipFields.includes(prop) && !headers.includes(prop)) {
                headers.push(prop);
            }
        }
    }

    /**
    * Is the given object a function?
    *
    * @param  {type} obj The object to check.
    * @return {boolean}     true if the object is a function, false otherwise.
    */
    static isFunction(obj) {
        return typeof obj == 'function';
    }

    /**
    * This function generates random integer between two numbers low (inclusive) and high (exclusive) ([low, high))<br>
    * Reference: <a target='_blank' href='https://blog.tompawlak.org/generate-random-values-nodejs-javascript'>https://blog.tompawlak.org/generate-random-values-nodejs-javascript</a>
    * @param  {type} low  the lower bound.
    * @param  {type} high the upper bound.
    * @return {number}      A random number from [low, high).
    */
    static randomInt(low, high) {
        return Math.floor(Math.random() * (high - low) + low);
    }

    /**
     * randomEl - description
     *
     * @param  {type} array description
     * @return {type}       description
     */
    static randomEl(array) {
        var i = Utils.randomInt(0, array.length);
        return array[i];
    }

    /**
    *  sum - description
    *
    * @param  {type} items description
    * @param  {type} prop  description
    * @return {type}       description
    */
    static sum(items, prop) {
        return items.reduce( function(a, b){
            return a + b[prop];
        }, 0);
    };

    //

    /**
    * Returns date in YYYYMMDD-HHmmss-SSS
    * Reference: https://stackoverflow.com/questions/42862729/convert-date-object-in-dd-mm-yyyy-hhmmss-format
    *
    * @return {type}  The formatted date.
    */
    static getDate() {
        var date = new Date(),
        year = date.getFullYear(),
        month = (date.getMonth() + 1).toString(),
        formattedMonth = (month.length === 1) ? ("0" + month) : month,
        day = date.getDate().toString(),
        formattedDay = (day.length === 1) ? ("0" + day) : day,
        hour = date.getHours().toString(),
        formattedHour = (hour.length === 1) ? ("0" + hour) : hour,
        minute = date.getMinutes().toString(),
        formattedMinute = (minute.length === 1) ? ("0" + minute) : minute,
        second = date.getSeconds().toString(),
        formattedSecond = (second.length === 1) ? ("0" + second) : second,
        ms = date.getMilliseconds().toString();
        var formattedMS = ms;
        if (ms.length === 1) {
            formattedMS = '00' + ms;
        } else if (ms.length === 2) {
            formattedMS = '0' + ms;
        }
        return year + formattedMonth + formattedDay + "-" +  formattedHour + formattedMinute + formattedSecond + '-' + formattedMS;
    }

    static getStageContents(app, stage) {
        var fn = path.join(app.session.jt.path, 'apps/' + app + '/' + stage + '.html')
        var html = fs.readFileSync(fn, 'utf8');
        return html;
    }

    static outputFields(self) {
        var fields = [];
        for (var prop in self) {
            if (
                !isFunction(self[prop]) &&
                !self.outputHide.includes(prop) &&
                !self.outputHideAuto.includes(prop)
            )
            fields.push(prop);
        }
        return fields;
    }

    // http://stackoverflow.com/questions/7364150/find-object-by-id-in-an-array-of-javascript-objects
    static findById(array, id) {
        if (array === null || array === undefined) {
            return null;
        }
        var out = $.grep(array, function(e) {
            return e !== undefined && e.id === id;
        });
        if (out.length > 0) {
            return out[0];
        }
        else {
            return null;
        }
    }

    // Find by ID without JQuery ($)
    static findByIdWOJQ(array, id) {
        for (let i in array) {
            if (array[i] !== undefined && array[i].id === id) {
                return array[i];
            }
        }
        return null;
    }

    // http://stackoverflow.com/questions/5767325/how-to-remove-a-particular-element-from-an-array-in-javascript
    static deleteById(array, id) {
        for (var i = array.length-1; i>=0; i--) {
            if(array[i].id === id) {
                array.splice(i, 1);
            }
        }
    }

    /**
     * var createFolder - description
     *
     * @param  {type} folder description
     * @return {type}        description
     */
    static createFolder(folder, jt) {
        if (!fs.existsSync(path.join(jt.path, folder))){
            fs.mkdirSync(path.join(jt.path, folder));
        }
    }

    static objLength(obj) {
        return Object.keys(obj).length;
    }

    static createFolderAsync(folder) {
        if (!fs.exists(folder)){
            fs.mkdir(folder, function() {});
        }
    }

    static createFile(fn) {
        fs.closeSync(fs.openSync(fn, 'w'));
    }

    static parseFloatRec(data) {
        var floatVal = parseFloat(data, 10);
        if (!isNaN(floatVal)) {
            data = floatVal;
        } else if (typeof data === 'object') {
            for (var i in data) {
                data[i] = Utils.parseFloatRec(data[i]);
            }
        }
        return data;
    }

    static decomposeId(id) {
        var out = {};
        var sesI = id.indexOf('session_');
        var sesInd = sesI + 'session_'.length;
        var appI = id.indexOf('_app_');
        if (appI === -1) {
            out.sessionId = id.substring(sesInd);
        } else {
            out.sessionId = id.substring(sesInd, appI);
            var appInd = appI + '_app_'.length;
            var prdI = id.indexOf('_period_');
            if (prdI === -1) {
                out.appId = id.substring(appInd);
            } else {
                out.appId = id.substring(appInd, prdI);
                var prdInd = prdI + '_period_'.length;
                var grpI = id.indexOf('_group_');
                if (grpI === -1) {
                    out.periodId = parseInt(id.substring(prdInd));
                } else {
                    out.periodId = parseInt(id.substring(prdInd, grpI));
                    var grpInd = grpI + '_group_'.length;
                    var plyI = id.indexOf('_player_');
                    if (plyI === -1) {
                        out.groupId = parseInt(id.substring(grpInd));
                    } else {
                        out.groupId = parseInt(id.substring(grpInd, plyI));
                        var plyInd = plyI + '_player_'.length;
                        out.playerId = id.substring(plyInd);
                    }
                }
            }
        }
        return out;
    }

    /**
     * loadContext - loads an object based on an id.
     * TODO: Add check for participant
     *
     * @param  {type} session description
     * @param  {type} id      description
     * @return {type}         description
     */
    static loadContext(session, id) {
        var ids = Utils.decomposeId(id);
        var out = null;
        if (ids.appId === null || ids.appId === undefined) {
            return session;
        } else {
            if (ids.periodId === null || ids.periodId === undefined) {
                return Utils.findByIdWOJQ(session.apps, ids.appId);
            } else {
                var app = Utils.findByIdWOJQ(session.apps, ids.appId);
                if (ids.groupId === null || ids.groupId === undefined) {
                    return Utils.findByIdWOJQ(app.periods, ids.periodId);
                } else {
                    var period = Utils.findByIdWOJQ(app.periods, ids.periodId);
                    if (ids.playerId === null || ids.playerId === undefined) {
                        return Utils.findByIdWOJQ(period.groups, ids.groupId);
                    } else {
                        var group = Utils.findByIdWOJQ(period.groups, ids.groupId);
                        return Utils.findByIdWOJQ(group.players, ids.playerId);
                    }
                }
            }
        }
    }
}

module.exports = Utils;
