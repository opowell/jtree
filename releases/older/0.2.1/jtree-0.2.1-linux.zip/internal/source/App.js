const Stage     = require('./Stage.js');
const Period    = require('./Period.js');
const Utils     = require('./Utils.js');
const fs        = require('fs-extra');
const path      = require('path');

/** Class that represents an app. */
class App {

    /**
     * Creates an App.
     *
     * @param  {Session} session description
     * @param  {string} id      description
     */
    // constructor(session: Session, id: string) {
    constructor(session, id) {

        /**
         * The unique identifier of this App.
         */
        this.id = id;

        /**
         * The Session that this App belongs to.
         * @type {Session}
         */
        this.session = session;


        /**
         * The stages of this app.
         * @type Array
         */
        this.stages = [];

        this.options = [];

        this.optionValues = {};

        /**
         * The number of periods in this App.
         * @type number
         */
        this.numPeriods = 1;

        /**
         * How do load stage contents. One of:
         * 'name': single client.html page with stages denoted by jt-stage attributes.
         * 'contents': each stage has a corresponding <stageName>.html file.
         * 'auto': if a client.html file exists, it is sent. otherwise, try to send a <stageName>.html file.
         */
        this.stageSwitchType = 'auto';

        /**
         * The periods of this app.
         */
        this.periods = [];

        /**
         * Whether or not to wait for all participants before starting the app.
         * @type boolean
         * @default true
         */
        this.waitForAll = true;

        /**
         * The matching type to be used for groups in this App.
         * @type string
         * @default 'STRANGER'
         */
        this.groupMatchingType = 'STRANGER';

        /**
         * Messages to listen for from clients.
         * @type Object
         */
        this.messages = {};

        /**
         * If defined, subjects are assigned randomly to groups of this size takes precedence over numGroups.
         */
         this.groupSize = undefined;

         // TODO: fix commenting

        /**
         * if defined, subjects are split evenly into this number of groups
         * overridden by groupSize.
         */
        this.numGroups = undefined;

        this.outputHideAuto = ['this', 'session', 'stages', 'stageSwitchType', 'outputHideAuto', 'outputHide', 'periods', 'messages', 'type', 'folder', 'options'];

        this.outputHide = [];

        this.finished = false;
    }

    /*
     * @static Load an app from json.
     *
     * CALLED FROM:
     * - {@link Session#load}
     *
     * @param  {Object} json    A json object containing the properties of the app.
     * @param  {Session} session The session this app belongs to.
     * @return {App}         A new app initialized with the data in json.
     */
    static load(json, session) {
        var index = json.sessionIndex;
        var app = new App(session, json.id);

        // Run app code.
        var folder = path.join(session.jt.path, session.getOutputDir() + '/' + index + '_' + json.id);
        var appCode = Utils.readJS(folder + '/app.js');
        eval(appCode);

        // If there is already an app in place, save its stages and periods??
        if (session.apps.length > index-1) {
            var curApp = session.apps[index-1];
            // app.stages = curApp.stages;
            app.periods = curApp.periods;
        }

        for (var j in json) {
            app[j] = json[j];
        }

        session.apps[index-1] = app;
    }

    /*
     * Overwrite to add custom functionality for when a {@link Client} starts this app.
     *
     * Called from:
     * - {@link App#addClientDefault}.
     *
     * @param  {Client} client The client who is connecting to this app.
     */
    addClient(client) {
        // Overwrite.
    }

    /*
    * Called when a {@link Client} connected to a {@link Participant} starts this app.
    *
    * - client subscribes to this App's channel.
    * - client registers custom messages it may send.
    * - client registers automatic stage submission messages it may send.
    * - load custom behaviour [this.addClient]{@link App#addClient}.
    *
    * Called from:
    * - {@link App#participantBegin}
    *
    * @param  {Client} client The client who is connecting to this app.
    */
    addClientDefault(client) {
        client.socket.join(this.roomId());

        for (var i in this.messages) {
            var msg = this.messages[i];
            client.register(i, msg);
        }

        // Register for automatic stage messages.
        var app = this;
        for (var s in this.stages) {
            var stageName = this.stages[s].name;
            client[stageName] = function(data) {
                data = Utils.parseFloatRec(data);
                this.session.jt.log('Server received auto-stage submission: ' + JSON.stringify(data));
                if (client.player() === null) {
                    return false;
                }
                // TODO: Not parsing strings properly.
                for (var property in data) {
                    var value = data[property];

                    if (value === 'true') {
                        value = true;
                    } else if (value === 'false') {
                        value = false;
                    } else if (!isNaN(value)) {
                        value = parseFloat(value);
                    }

                    if (data.hasOwnProperty(property)) {
                        if (property.startsWith('player.')) {
                            var fieldName = property.substring('player.'.length);
                            client.player()[fieldName] = value;
                        } else if (property.startsWith('group.')) {
                            var fieldName = property.substring('group.'.length);
                            client.group()[fieldName] = value;
                        } else if (property.startsWith('participant.')) {
                            var fieldName = property.substring('participant.'.length);
                            client.participant[fieldName] = value;
                        } else if (property.startsWith('period.')) {
                            var fieldName = property.substring('period.'.length);
                            client.period()[fieldName] = value;
                        } else if (property.startsWith('app.')) {
                            var fieldName = property.substring('app.'.length);
                            client.app()[fieldName] = value;
                        }
                    }
                }
                client.player().attemptToEndStage();
            };
            client.on(stageName, function(data) { // stage messages are sent by default when submit button is clicked.
                app.session.pushMessage(client, data.data, data.data.fnName);
            });
        }

        // Load custom code, overwrite default stage submission behavior.
        try {
            this.addClient(client);
        } catch(err) {
            console.log(err);
        }

    }

    /*
     * Get next stage for player in their current period. Return null if already at last stage of period.
     *
     * DUE TO:
     * Stage.playerEnd
     */
    getNextStageForPlayer(player) {
        var stageInd = player.stageIndex;

        // If not in the last stage, return next stage.
        if (stageInd < this.stages.length-1) {
            return this.stages[stageInd+1];
        } else {
            return null;
        }

    }

    getGroupIdsForPeriod(period) {
        var participants = this.session.participants;
        var numGroups = period.numGroups();
        var pIds = [];
        for (var p in participants) {
            pIds.push(p);
        }
        // Group IDs
        const gIds = [];
        for (var g=0; g<numGroups; g++) {
            gIds.push([]);
        }
        // Calculate number of elements per group
        var m = Math.floor((pIds.length-1) / numGroups) + 1;

        if (this.groupMatchingType === 'PARTNER_1122') {
            for (var g=0; g<numGroups; g++) {
                for (var i=0; i<m; i++) {
                    gIds[g].push(pIds[0]);
                    pIds.splice(0, 1);
                }
            }
        } else if (this.groupMatchingType === 'PARTNER_1212') {
            for (var i=0; i<m; i++) {
                for (var g=0; g<numGroups; g++) {
                    gIds[g].push(pIds[0]);
                    pIds.splice(0, 1);
                }
            }
        } else if (this.groupMatchingType === 'PARTNER_RANDOM') {
            if (period.id === 1) {
                period.getStrangerMatching(numGroups, pIds, gIds, m);
            } else {
                var prevPeriod = period.prevPeriod();
                gIds = prevPeriod.groupIds();
            }
        } else if (this.groupMatchingType === 'STRANGER') {
            period.getStrangerMatching(numGroups, pIds, gIds, m);
        }
        return gIds;
    }

    /*
     * Ends this App.
     *
     * - Create headers for this app, periods, groups, group tables, players and participants.
     * - Create output.
     * - Write output to this session's csv file.
     *
     * CALLED FROM
     * - {@link App#tryToEndApp}
     */
    end() {

        this.finished = true;

        // Create headers
        var appsHeaders = [];
        var appsSkip = ['id'];
        var appFields = this.outputFields();
        Utils.getHeaders(appFields, appsSkip, appsHeaders);

        var periodHeaders = [];
        var groupHeaders = [];
        var playerHeaders = [];
        var periodSkip = ['id'];
        var groupSkip = ['id', 'allPlayersCreated'];
        var playerSkip = ['status', 'stageIndex', 'id', 'participantId'];
        var groupTables = [];
        var groupTableHeaders = {};
        for (var i=0; i<this.periods.length; i++) {
            var period = this.periods[i];
            var periodFields = period.outputFields();
            Utils.getHeaders(periodFields, periodSkip, periodHeaders);
            for (var j=0; j<period.groups.length; j++) {
                var group = period.groups[j];
                for (var k=0; k<group.tables.length; k++) {
                    var tableId = group.tables[k];
                    if (!groupTables.includes(tableId)) {
                        groupTables.push(tableId);
                        groupTableHeaders[tableId] = [];
                    }
                    var tableHeaders = groupTableHeaders[tableId];
                    var tableFields = group[tableId].outputFields();
                    Utils.getHeaders(tableFields, [], tableHeaders);
                }
                var groupFields = group.outputFields();
                Utils.getHeaders(groupFields, groupSkip, groupHeaders);
                for (var k=0; k<group.players.length; k++) {
                    var player = group.players[k];
                    var fieldsToOutput = player.outputFields();
                    Utils.getHeaders(fieldsToOutput, playerSkip, playerHeaders);
                }
            }
        }
        var participantHeaders = [];
        var participantSkip = ['id', 'points', 'periodIndex', 'appIndex'];
        for (var i in this.participants) {
            var participant = this.participants[i];
            var participantFields = participant.outputFields();
            Utils.getHeaders(participantFields, participantSkip, participantHeaders);
        }

        // Create data
        var appsText = [];
        appsText.push('id,' + appsHeaders.join(','));
        var newLine = this.id + ',';
        for (var h=0; h<appsHeaders.length; h++) {
            var header = appsHeaders[h];
            if (this[header] !== undefined) {
                newLine += JSON.stringify(this[header]);
            }
            if (h<appsHeaders.length-1) {
                newLine += ',';
            }
        }
        appsText.push(newLine);

        var periodText = [];
        var groupText = [];
        var playerText = [];
        groupText.push('period.id,group.id,' + groupHeaders.join(','));
        playerText.push('period.id,group.id,participant.id,' + playerHeaders.join(','));
        for (var i=0; i<this.periods.length; i++) {
            var period = this.periods[i];
            var newLine = period.id + ',';
            newLine = this.appendValues(newLine, periodHeaders, period);
            periodText.push(newLine);
            for (var j=0; j<period.groups.length; j++) {
                var group = period.groups[j];
                var newLine = period.id + ',' + group.id + ',';
                newLine = this.appendValues(newLine, groupHeaders, group);
                groupText.push(newLine);
                for (var k=0; k<group.players.length; k++) {
                    var player = group.players[k];
                    var participant = player.participant;
                    var newLine = period.id + ',' + group.id + ',' + participant.id + ',';
                    newLine = this.appendValues(newLine, playerHeaders, player);
                    playerText.push(newLine);
                }
            }
        }
        var participantText = [];
        var participantHeadersText = 'id,points';
        if (participantHeaders.length > 0) {
            participantHeadersText += ',' + participantHeaders.join(',');
        }
        participantText.push(participantHeadersText);
        for (var i in this.session.participants) {
            var participant = this.session.participants[i];
            var newLine = participant.id + ',' + participant.points()
            if (participantHeaders.length > 0) {
                newLine += ',';
            }
            for (var h=0; h<participantHeaders.length; h++) {
                var header = participantHeaders[h];
                if (participant[header] !== undefined) {
                    newLine += participant[header];
                }
                if (h<participantHeaders.length-1) {
                    newLine += ',';
                }
            }
            participantText.push(newLine);
        }

        // WRITE OUTPUT
        fs.appendFileSync(this.session.csvFN(), 'APP ' + this.indexInSession() + '_' + this.id + '\n');
        fs.appendFileSync(this.session.csvFN(), appsText.join('\n') + '\n');
        if (periodHeaders.length > 0) {
            fs.appendFileSync(this.session.csvFN(), 'PERIODS\n');
            fs.appendFileSync(this.session.csvFN(), periodText.join('\n') + '\n');
        }
        if (groupHeaders.length > 0) {
            fs.appendFileSync(this.session.csvFN(), 'GROUPS\n');
            fs.appendFileSync(this.session.csvFN(), groupText.join('\n') + '\n');
        }

        for (var t=0; t<groupTables.length; t++) {
            var groupTableText = [];
            var table = groupTables[t];
            var tableHeaders = groupTableHeaders[table];
            groupTableText.push('period.id,group.id,id,' + tableHeaders.join(','));
            for (var i=0; i<this.periods.length; i++) {
                var period = this.periods[i];
                for (var j=0; j<period.groups.length; j++) {
                    var group = period.groups[j];
                    var tabRows = group[table].rows;
                    for (var r=0; r<tabRows.length; r++) {
                        var row = tabRows[r];
                        var newLine = period.id + ',' + group.id + ',' + row.id + ',';
                        newLine = this.appendValues(newLine, tableHeaders, row);
                        groupTableText.push(newLine);
                    }
                }
            }
            fs.appendFileSync(this.session.csvFN(), groupTables[t].toUpperCase() + '\n');
            fs.appendFileSync(this.session.csvFN(), groupTableText.join('\n') + '\n');
        }

        if (playerHeaders.length > 0) {
            fs.appendFileSync(this.session.csvFN(), 'PLAYERS\n');
            fs.appendFileSync(this.session.csvFN(), playerText.join('\n') + '\n');
        }

        fs.appendFileSync(this.session.csvFN(), 'PARTICIPANTS\n');
        fs.appendFileSync(this.session.csvFN(), participantText.join('\n') + '\n');

    }

    /*
     * @return {string}  Session path + {@link App#indexInSession} + '_' + app.id
     */
    getOutputFN() {
        return this.session.getOutputDir() + '/' + this.indexInSession() + '_' + this.id;
    }

    /*
     * - clear group's timer.
     * - if next stage exists, let the group play it.
     * - for each player in the group, call {@link App#playerMoveToNextStage}.
     *
     * @param  {Group} group
     */
    groupMoveToNextStage(group) {
        group.clearStageTimer();
        var nextStage = this.nextStageForGroup(group);

        // If not at last stage of session, mvoe group to next stage.
        if (nextStage !== null) {
            nextStage.groupPlayDefault(group);
        }

        if (nextStage === null || nextStage.waitForGroup) {
            for (var p in group.players) {
                this.playerMoveToNextStage(group.players[p]);
            }
        }
    }

    /**
     * @return {number} The index of this app in its session's list of apps (first position = 1).
     */
    indexInSession() {
        for (var i in this.session.apps) {
            if (this.session.apps[i] === this) {
                return parseInt(i)+1;
            }
        }
        return -1;
    }

    /*
     * Creates a new period with the given id + 1, saves it and adds it to this App's periods.
     *
     * Called from:
     * - {@link App.participantBeginPeriod}
     *
     * @param  {number} prd The index to assign to the new period.
     */
    initPeriod(prd) {
        var period = new Period.new(prd + 1, this);
        period.save();
        this.periods.push(period);
    }

    /*
     * metaData - description
     *
     * @return {type}  description
     */
    metaData() {
        var metaData = {};
        metaData.numPeriods = this.numPeriods;
        metaData.groupSize = this.groupSize;
        metaData.id = this.id;
        metaData.title = this.title;
        metaData.description = this.description;

        var folder = path.join(this.session.jt.path, this.session.jt.settings.appFolders[0] + '/' + this.id);
        try {
            metaData.appjs = Utils.readJS(folder + '/app.js');
        } catch (err) {
            metaData.appjs = '';
        }

        try {
            metaData.clientHTML = Utils.readJS(folder + '/client.html');
        } catch (err) {
            metaData.clientHTML = '';
        }

        var app = new App(null, this.id);

        metaData.stages = [];
        try {
            eval(metaData.appjs);
            for (var i in app.stages) {
                metaData.stages.push(app.stages[i].id);
            }
            metaData.numPeriods = app.numPeriods;
            metaData.options = app.options;
        } catch (err) {
            metaData.stages.push('unknown');
            metaData.numPeriods = 'unknown';
        }

        return metaData;
    }

    addNumberOption(name, defaultVal, min, max, step) {
        // Add to list of options.
        this.options.push({type: 'number', name: name, min: min, max: max, step: step, defaultVal: defaultVal});

        // Add value, if does not already exist.
        if (this[name] === undefined) {
            this[name] = defaultVal;
        }

        // Value already exists, coerce if possible into one of the original option values.
        else {
            this.setOptionValue(name, this[name]);
        }
    }

    addSelectOption(optionName, optionVals) {

        // Add to list of options.
        this.options.push({type: 'select', name: optionName, values: optionVals});

        // Add value, if does not already exist.
        if (this[optionName] === undefined) {
            this[optionName] = optionVals[0];
        }

        // Value already exists, coerce if possible into one of the original option values.
        else {
            this.setOptionValue(optionName, this[optionName]);
        }
    }

    reload() {
        var app = new App(this.session, this.id);
        var folder = path.join(this.session.jt.path, this.session.getOutputDir() + '/' + this.indexInSession() + '_' + this.id);
        app.optionValues = this.optionValues;
        for (var opt in app.optionValues) {
            app[opt] = app.optionValues[opt];
        }
        var appCode = Utils.readJS(folder + '/app.js');
        eval(appCode);
        return app;
    }

    setOptionValue(name, value) {
        this.optionValues[name] = value;
        var correctedValue = value;
        for (var opt in this.options) {
            var option = this.options[opt];
            if (option.name === name) {
                if (option.type === 'select') {
                    for (var i in option.values) {
                        if (option.values[i] == value) { // allow for coercion
                            correctedValue = option.values[i];
                            break;
                        }
                    }
                } else if (option.type === 'number') {
                    correctedValue = value - 0; // coerce to number
                    break;
                }
            }
        }
        this[name] = correctedValue;
    }

    /**
     * Creates a new {@link Stage} and adds it to the App.
     *
     * @param  {string} id The identifier of the stage.
     * @return {Stage} The new stage.
     */
    newStage(id) {
        var stage = new Stage.new(id, this, this.stages.length);
        this.stages.push(stage);
        return stage;
    }

    /*
     * Returns the next stage for a given group in a given stage.
     * 1. If stage is not the last stage of this app, return the next stage of this app.
     * 2. If period is not the last period of this app, return the first stage of this app.
     * 3. If app is not the last app of this session, return the first stage of the next app.
     * 4. Otherwise, return null.
     *
     * TODO? Does the next stage have Stage.waitForGroup == true?
     *
     * CALLED FROM
     * - {@link Stage#playerEnd}
     * - {@link App#groupMoveToNextStage}
     *
     * @param  {Group} group The group
     * @return {(null|Stage)} The next stage for this group, or null.
     */
    nextStageForGroup(group) {
        var slowestPlayers = group.slowestPlayers();
        return slowestPlayers[0].nextStage();
    }

    /*
     * Called when a player finishes a stage.
     * By default, check whether everyone in group is finished.
     * If yes, then advance to next stage ([this.session.gotoNextStage(player.group)]{@link Session.gotoNextStage}).
     *
     * @param  {Player} player description
     */
    onPlayerFinished(player) {
        var proceed = true;
        for (var p in player.group.players) {
            var pId = player.group.players[p];
            if (this.session.player(pId).status !== 'finished') {
                proceed = false;
                break;
            }
        }
        if (proceed) {
            this.session.gotoNextStage(player.group);
        }
    }

    /*
     * The names of fields to include in an export of this object. To be included, a field must:
     * - not be a function ({@link Utils.isFunction})
     * - not be included in {@link App#outputHide}
     * - not be included in {@link App#outputHideAuto}
     *
     * @return {Array}  An array of the field names.
     */
    outputFields() {
        var fields = [];
        for (var prop in this) {
            if (
                !Utils.isFunction(this[prop]) &&
                !this.outputHide.includes(prop) &&
                !this.outputHideAuto.includes(prop)
            )
            fields.push(prop);
        }
        return fields;
    }

    /*
     * Called when a participant begins this app.
     * - For each of the [Clients]{@link Client} of this participant, call {@link App.addClientDefault}.
     * - Set the participant's periodIndex to -1.
     * - Participant notifies clients about appIndex.
     * - Move participant to next period {@link App.participantMoveToNextPeriod}.
     * - Participant notified clients about starting new app.
     *
     * @param  {Participant} participant The participant.
     */
    participantBegin(participant) {

        for (var c in participant.clients) {
            var client = participant.clients[c];
            this.addClientDefault(client);
        }

        participant.periodIndex = -1;
        participant.emit('participantSetAppIndex', {appIndex: this.indexInSession()});

        this.participantMoveToNextPeriod(participant);

        participant.emit('start-new-app'); // refresh clients.
    }

    /*
     * A participant begins its current period.
     *
     * - Participant notifies its clients of periodIndex.
     * - If current period undefined, initialize it ({@link App.initPeriod}).
     * - Participant begins period ({@link Period.participantBegin}).
     *
     * Called from:
     * - {@link App.participantMoveToNextPeriod}.
     *
     * @param  {type} participant The participant.
     */
    participantBeginPeriod(participant) {
        var prd = participant.periodIndex;
        participant.emit('participantSetPeriodIndex', {periodIndex: participant.periodIndex});

        var period = this.getPeriod(prd);
        if (period === undefined) {
            return false;
        }
        period.participantBegin(participant);
    }

    getPeriod(index) {
        if (this.periods[index] == undefined) {
            this.initPeriod(index);
        }
        return this.periods[index];
    }

    /*
     * A participant moves to its next period.
     *
     * FUNCTIONALITY
     * - If participant is currently in a period, end it ({@link Period.participantEnd}).
     * - Increment participant's period index.
     * - Save participant ({@link Participant.save}).
     * - If participant is has finished all periods in this app, move to next app ({@link Session.participantMoveToNextApp}).
     * - Otherwise, begin new period ({@link App.participantBeginPeriod}).
     *
     * CALLED FROM
     * - {@link App#playerMoveToNextStage}
     * - {@link App#participantBegin}
     *
     * @param  {type} participant description
     * @return {type}             description
     */
     participantMoveToNextPeriod(participant) {
         // If in the last period of app, move to next app.
         if (participant.periodIndex >= this.numPeriods - 1) {
             this.session.participantMoveToNextApp(participant);
         }

         // Move to the next period of this app.
         else {
             // If not in the first period, end the previous period for this participant.
             if (participant.periodIndex > -1) {
                 participant.player.period().participantEnd(participant);
             }

             // Move to next period.
             participant.periodIndex++;
             participant.save();
             this.participantBeginPeriod(participant);
         }
     }

    /*
     * A participant finishes playing this app.
     *
     * FUNCTIONALITY
     * - Participant's clients unsubscribe from messages from this app.
     * - Try to end the app ({@link App#tryToEndApp}).
     *
     * CALLED FROM
     * -
     * @param  {Participant} participant The participant.
     */
    participantEnd(participant) {
        // for (var c in participant.clients) {
        //     var client = participant.clients[c];
        //     client.socket.leave(this.roomId());
        // }
        this.tryToEndApp();
    }

    /*
     * Move the player to their next stage.
     *
     * FUNCTIONALITY
     * - if player has not finished all stages,
     * -- set player status to 'playing'
     * -- increment player's stage index.
     * -- play next stage ({@link Stage#playerPlayDefault}).
     * -- player emits update ({@link Player#emitUpdate2}).
     * - otherwise, move participant to next period ([this.participantMoveToNextPeriod(player.participant)]{@link App#participantMoveToNextPeriod}).
     *
     * CALLED FROM
     * - {@link App#groupMoveToNextStage}
     *
     * @param  {Player} player The player
     * @return {type}        description
     */
    playerMoveToNextStage(player) {
        if (player.stageIndex < this.stages.length - 1) {
            player.status = 'playing';
            player.stageIndex++;
            player.stage = this.stages[player.stageIndex];
            player.stage.playerPlayDefault(player);
//            player.emit('playerSetStageIndex', {stageIndex: player.stageIndex});
            if (this.stageSwitchType === 'name') {
                player.emitUpdate2();
            } else if (this.stageSwitchType === 'contents') {
                player.emit('reload', {});
            } else if (this.stageSwitchType === 'auto') {
                player.emitUpdate2();
            }
        } else {
            this.participantMoveToNextPeriod(player.participant);
        }
    }

    /**
     * Returns the player of the current player's participant from the previous period.
     *
     * @param  {Player} player The player.
     * @return {Player}        The previous player, if any.
     */
    previousPlayer(player) {
        var prevPeriod = player.period().prevPeriod();
        if (prevPeriod === null) {
            return null;
        } else {
            return prevPeriod.playerByParticipantId(player.id);
        }
    }

    /**
     * roomId - description
     *
     * @return {string}  {@link Session#roomId} + '_app_' + this.id
     */
    roomId() {
        return this.session.roomId() + '_app_' + this.id;
    }

    /**
     * saveSelfAndChildren - description
     *
     * CALLED FROM:
     * - {@link Session#addApp}

     * @return {type}  description
     */
    saveSelfAndChildren() {
        this.save();
        for (var i in this.stages) {
            this.stages[i].save();
        }
    }

    /**
     * Save this {@link App} to the session .gsf file.
     *
     * CALLED FROM:
     * - {@link App#saveSelfAndChildren}
     *
     */
    save() {
        try {
            this.session.jt.log('App.save: ' + this.id);
            var toSave = this.shell();
            this.session.saveDataFS(toSave, 'APP');
        } catch (err) {
            console.log('Error saving app ' + this.id + ': ' + err);
        }
    }

    /**
     * A shell of this object. Excludes parent, includes child shells.
     *
     * CALLED FROM:
     * - {@link Session#addApp}
     *
     * @return {type}  description
     */
    shellWithChildren() {
        var out = {};
        var fields = this.outputFields();
        for (var f in fields) {
            var field = fields[f];
            out[field] = this[field];
        }
        out.periods = [];
        for (var i in this.periods) {
            out.periods[i] = this.periods[i].shellWithChildren();
        }
        out.stages = [];
        for (var i in this.stages) {
            out.stages[i] = this.stages[i].shell();
        }
        out.options = this.options;
        return out;
    }

    /**
     * A shell of this object. Includes parent shell, excludes child shells.
     *
     * @return {type}  description
     */
    shellWithParent() {
        var out = {};
        var fields = this.outputFields();
        for (var f in fields) {
            var field = fields[f];
            out[field] = this[field];
        }
        out.session = this.session.shell();
        return out;
    }

    /**
     * A shell of this object. Excludes parent and children. The shell is a simplified version of an object and any of its fields.
     *
     * CALLED FROM
     * - {@link App#save}
     *
     * @return {Object}  description
     */
    shell() {
        var out = {};
        var fields = this.outputFields();
        for (var f in fields) {
            var field = fields[f];
            out[field] = this[field];
        }
        out.sessionIndex = this.indexInSession();
        return out;
    }

    /*
     * If all participants have finished the app, end the app ({@link App#end}).
     *
     * CALLED FROM
     * - {@link App#participantEnd}
     *
     * @return {type}  description
     */
    tryToEndApp() {
        if (this.finished) {
            return;
        }

        var proceed = true;
        var participants = this.session.participants;
        for (var p in participants) {
            var participant = participants[p];
            if (!participant.isFinishedApp(this)) {
                proceed = false;
                break;
            }
        }
        if (proceed) {
            this.end();
        }
    }

    // Helper method for writing to csv.
    appendValues(newLine, headers, obj) {
        for (var i=0; i<headers.length; i++) {
            var header = headers[i];
            var value = obj[header];
            if (value !== undefined && value !== null) {

                // If value is an object, change it to string.
                if (typeof value === 'object') {
                    value = JSON.stringify(obj[header]);
                }

                // If value is a string, replace any commas.
                if (typeof value === 'string') {
                    value = value.replace(/,/g, '--');
                }

                // Append the value.
                newLine += value;
            }

            if (i<headers.length-1) {
                newLine += ',';
            }
        }
        return newLine;
    }


    /**
     * Overwrite in app.js.
     *
     * @param  {type} participant description
     * @return {type}             description
     */
    participantStart(participant) {}

    getNextPeriod(participant) {
        if (participant.periodIndex >= this.numPeriods - 1) {
            return null;
        } else {
            return this.getPeriod(participant.periodIndex+1);
        }
    }

}

var exports = module.exports = {};
exports.new = App;
exports.load = App.load;
