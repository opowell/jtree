app.description = 'Fancy questionnaire, implemented using the Bootstrap package.'

// DEFINE STAGES
var questionsStage = app.newStage('questions');
