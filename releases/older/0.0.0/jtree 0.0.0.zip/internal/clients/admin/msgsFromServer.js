// INCOMING MESSAGES FROM SERVER
var msgs = {};
msgs.addSession = function(session) {
  var index = findById(jt.data.sessions, session.id);
  if (index === null) {
      jt.data.sessions.push(session);
      showSessionRow(session);
  }
}
msgs.deleteSession = function(id) {
    for (i in jt.data.sessions) {
        var session = jt.data.sessions[i];
        if (id === session.id) {
            jt.data.sessions.splice(i, 1);
            i--;
            showSessions();
        }
    }
}
msgs.openSession = function(session) {
    for (let i in participantTimers) {
        clearInterval(participantTimers[i]);
    }
    jt.data.session = session;
    localStorage.setItem('sessionId', session.id);
    if (session !== undefined) {
        $('#session-id').text(session.id);
        showPanel("#panel-session-info");
        updateSessionActive(session);
        showClients(jt.data.session.clients);
        showParticipants(jt.data.session.participants);
        closeViews();
        // viewAllParticipants();
        updateSessionApps();
    }
}
msgs.participantSetAppIndex = function(md) {
    var participant = jt.data.session.participants[md.participantId];
    participant.appIndex = md.appIndex;
    showPlayerCurApp(participant);
}
msgs.participantSetGroupId = function(md) {
    $('.participant-' + md.participantId + '-groupId').text(md.groupId);
}
msgs.participantSetPeriodIndex = function(md) {
    var participant = jt.data.session.participants[md.participantId];
    participant.periodIndex = md.periodIndex;
    $('.participant-' + md.participantId + '-periodIndex').text(participant.periodIndex+1);
}
msgs.playerSetStageIndex = function(md) {
    var participant = jt.data.session.participants[md.participantId];
    participant.player.stageIndex = md.stageIndex;
    var app = jt.data.session.apps[participant.appIndex-1];
    var stage = app.stages[participant.player.stageIndex];
    var stageText = '';
    if (stage !== undefined) {
        stageText = stage.id;
    }
    $('.participant-' + participant.id + '-stageId').text(stageText);
}
msgs.participantSetPlayer = function(md) {
    var participant = jt.data.session.participants[md.participantId];
    participant.player = md.player;
    $('.participant-' + md.participantId + '-groupId').text(participant.player.group.id);
}
msgs.playerUpdate = function(player) {
//    var decompId = decomposeId(player.roomId);
//    if (decompId.sessionId === jt.data.session.id) {
    if (player.group.period.app.session.id === jt.data.session.id) {
                var div = $('tr.participant-' + player.id);

        // Re-establish object links.
        player.participant.session = player.group.period.app.session;
        if (player.stage !== undefined) {
            player.stage.app = player.group.period.app;
        }
        player.participant.player = player;

        jt.data.session.participants[player.id] = player.participant;

        setParticipantPlayer(player.id, player, div);
//        $('.participant-' + player.id + '-periodIndex').text(decompId.periodId);
        $('.participant-' + player.id + '-periodIndex').text(player.group.period.id);
    }
}

msgs.refreshAdmin = function(ag) {
    refresh(ag);
}

msgs.sessionAddApp = function(d) {
    if (jt.data.session.id === d.sId) {
        jt.data.session.apps.push(d.app);
        updateSessionApps();
    }
    var session = findById(jt.data.sessions, d.sId);
    if (session !== null && session !== undefined) {
        session.appSequence.push(d.app.id);
        showSessions();
    }
};
msgs.sessionSetActive = function(msgData) {
    if (jt.data.session.id === msgData.sId) {
        jt.data.session.active = msgData.active;
        updateSessionActive(jt.data.session);
    }
    var session = findById(jt.data.sessions, msgData.sId);
    if (session !== null) {
        session.active = msgData.active;
        showSessions();
    }
}
msgs.sessionSetRunning = function(msgData) {
    if (jt.data.session.id === msgData.sId) {
        jt.data.session.isRunning = msgData.isRunning;
        updateSessionRunning(jt.data.session);
    }
    var session = findById(jt.data.sessions, msgData.sId);
    if (session !== null) {
        session.canPlay = msgData.canPlay;
        showSessions();
    }
}
msgs.sessionDeleteApp = function(md) {
    if (jt.data.session.id === md.sId &&
        jt.data.session.apps[md.i].id === md.aId) {
            jt.data.session.apps.splice(md.i, 1);
            updateSessionApps();
    }
}
