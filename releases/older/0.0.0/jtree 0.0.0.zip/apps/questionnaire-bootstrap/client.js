function connected() {
    $('#slider').slider({
    	formatter: function(value) {
    		return 'Current value: ' + value;
    	}
    });
    $("#slider").on("slide", function(slideEvt) {
	       $("#sliderVal").text(slideEvt.value);
    });
}
