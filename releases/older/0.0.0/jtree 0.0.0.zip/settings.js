// Add administrators.
settings.admins['A1'] = {id: 'A1', pwd: 'adminPWD'};
settings.admins['A2'] = {id: 'A2', pwd: 'adminPWD'};
settings.admins['AdminNoPwd'] = {id: 'AdminNoPwd'};

// Add predefined queues.
settings.predefinedQueues['manec20'] = {
    folders: ['enter-second-id', 'dutch-auction', 'display-profit']
};

// Server port.
settings.port = 3000;
//settings.adminUI = 'clients/adminWindow';
