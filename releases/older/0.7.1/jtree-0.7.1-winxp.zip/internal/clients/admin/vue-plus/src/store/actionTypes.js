export const HELLO_WORLD = 'HELLO_WORLD'
