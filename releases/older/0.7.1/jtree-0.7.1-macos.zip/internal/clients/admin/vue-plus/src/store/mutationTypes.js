export const HELLO = 'HELLO'
