export const helloWorld = 'helloWorld'
