//
// MAKE CHANGES TO 'sharedTemplate.js', not 'shared.js' directly!!!
//
var jt = {};

// Code used by both participant and admin.
jt.socket = null;
jt.timer = null;
jt.data = {};
jt.data.endTime = 0;
jt.data.timeLeft = 0;
jt.data.clockRunning = false;
jt.data.CLOCK_FREQUENCY = 100; // in ms

jt.serverIP = '{{{SERVER_IP}}}';
jt.serverPort = '{{{SERVER_PORT}}}';
jt.server = {};

jt.serverURL = function() {
    if (jt.serverPort === '80') {
        return jt.serverIP;
    } else {
        return jt.serverIP + ':' + jt.serverPort;
    }
}

// For Player only
jt.alwaysShowAllStages = false;

window.onload = function() {
    jt.checkIfLoaded();
}

jt.checkIfLoaded = function() {
        var pId = jt.getURLParameter('id'); // participant or admin id
        var pwd = jt.getURLParameter('pwd');
        var type = jt.getURLParameter('type'); // 'admin' == admin
        if (window.location.pathname.endsWith('admin')) {
            type = 'ADMIN';
        }
        var sId = jt.getURLParameter('sessionId'); // sessionId
        var query = {query: 'id=' + pId + '&pwd=' + pwd + '&type=' + type + '&sessionId=' + sId};
        jt.socket = io(jt.serverIP + ':' + jt.serverPort, query);
        jt.socket.on('connect', function() {
            console.log('client.socket connected socketId=' + jt.socket.id);
            jt.socketConnected();
        });

        jt.socket.on('logged-in', function(participant) {
            console.log('logged-in: ' + participant.id);
            jt.setPId(participant.id, participant.session.id);
        });

        jt.defaultConnected();
        jt.connected();

        if (jt.alwaysShowAllStages) {
            jt.showAllStages();
        }
}

// Overwrite
jt.socketConnected = function() {

}

jt.setPId = function(newPId, newSId) {
    var pId = jt.getURLParameter('id'); // participant or admin id
    var pwd = jt.getURLParameter('pwd');
    var sId = jt.getURLParameter('sessionId'); // 'admin' == admin
    var type = jt.getURLParameter('type');
    var props = '/?id=' + newPId;
    if (pwd !== null) {
        props += '&pwd=' + pwd;
    }
    if (sId !== null) {
        props += '&sessionId=' + newSId;
    }
    if (type !== null) {
        props += '&type=' + type;
    }
    var newURL = window.location.protocol + '//' + window.location.host + props;
//    if (window.location.href !== newURL) {
    if (newPId !== pId) {
        window.location.href = newURL;
    }
    jt.showPId(pId);
}

jt.getURLParameter = function(name) {
    return decodeURIComponent((new RegExp('[?|&]' + name + '=' + '([^&;]+?)(&|#|;|$)').exec(location.search) || [null, ''])[1].replace(/\+/g, '%20')) || null;
}

jt.displayTimeLeft = function(min, secs, timeLeft) {
    var duration = timeLeft + 999;
    if (duration < 0) {
        duration = 0;
    }
    var milliseconds    = parseInt((duration%1000)/100)
    var seconds         = parseInt((duration/1000)%60)
    var minutes         = parseInt((duration/(1000*60))%60)
    var hours           = parseInt((duration/(1000*60*60))%24);
    if (isNaN(minutes)) {
        debugger;
    }
    //    hours = (hours < 10) ? "0" + hours : hours;
    //    minutes = (minutes < 10) ? "0" + minutes : minutes;
    seconds = (seconds < 10) ? "0" + seconds : seconds;

    min.text(minutes);
    secs.text(seconds);
}

// Should be overwritten.
jt.defaultConnected = function() {}
jt.connected = function()        {}
jt.showPId = function(id)        {}
