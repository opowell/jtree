const express   = require('express');
const path      = require('path');
const fs        = require('fs-extra');
const Utils     = require('../Utils.js');
const ip        = require('ip');
const http      = require('http');
const replace   = require("replace");


class StaticServer {

    constructor(jt) {
        this.jt = jt;
        var expApp = express();
        var self = this;

        expApp.use('', express.static(path.join(this.jt.path, jt.settings.participantUI)));

        // expApp.use('/clients', express.static(path.join(process.cwd(), 'clients/')));
        expApp.use('/clients/admin', express.static(path.join(this.jt.path, jt.settings.adminUI)));
        expApp.use('/clients/participant', express.static(path.join(this.jt.path, jt.settings.participantUI)));
        expApp.use('/clients/shared', express.static(path.join(this.jt.path, jt.settings.sharedUI)));

        expApp.get('/', function(req, res) {
            self.sendParticipantPage(req, res);
        });

        expApp.get('/join', function(req, res) {
            self.sendParticipantPage(req, res);
        });

        expApp.get('/admin', function(req, res) {
            var id = req.query.id;
            var pwd = req.query.pwd;
            var admin = jt.data.getAdmin(id, pwd);
            if (admin == null && jt.settings.adminLoginReq === true) {
                res.sendFile(path.join(jt.path, jt.settings.adminUI + '/invalidAdminLogin.html'));
            } else {
                res.sendFile(path.join(jt.path, jt.settings.adminUI + '/admin.html'));
            }
        });

        this.port = jt.settings.port;
        this.ip = ip.address();

        this.server = http.Server(expApp);
        var self = this;
        this.server.listen(this.port, function() {
            console.log('###############################################');
            console.log('jtree ' + jt.version + ', listening on ' + self.ip + ':' + self.port);
        });

        this.generateSharedJS();

        for (var i in jt.data.apps) {
            let metaData = jt.data.apps[i];
            expApp.use('/' + metaData.id, express.static(metaData.fn));
        }
    }

    /**
     * Generates "shared.js", to be used by all clients to connect to server.
     * 1. Create a copy of 'sharedTemplate.js'.
     * 2. Overwrite the serverURL variable with the IP + port of the current machine.
     *
     * References:
     * http://stackoverflow.com/questions/3653065/get-local-ip-address-in-node-js
     * http://stackoverflow.com/questions/14177087/replace-a-string-in-a-file-with-nodejs
     */
    generateSharedJS() {
        var fn = path.join(this.jt.path, this.jt.settings.clientJSTemplateFile) // file with marker
        var newFN = path.join(this.jt.path, this.jt.settings.clientJSFile) // actual file to be sent to clients and admins
        try {
            fs.copySync(fn, newFN);
            replace({
                regex: '{{{SERVER_IP}}}',
                replacement: this.ip,
                paths: [newFN],
                recursive: true,
                silent: true,
            });
            replace({
                regex: '{{{SERVER_PORT}}}',
                replacement: this.port,
                paths: [newFN],
                recursive: true,
                silent: true,
            });
        } catch (err) {
            console.error(err);
        }
    }

    sendParticipantPage(req, res) {
        var sessionId = req.query.sessionId;
        var session = null;
        if (sessionId == null || sessionId == undefined) {
            session = this.jt.data.getMostRecentActiveSession();
        } else {
            session = Utils.findByIdWOJQ(this.jt.data.sessions, sessionId);
        }
        if (session === null) {
            res.sendFile(path.resolve(this.jt.path, './' + this.jt.settings.participantUI + '/invalidSession.html'));
        } else {
            session.sendParticipantPage(req, res);
        }
    }

}

var exports = module.exports = {};
exports.new = StaticServer;
