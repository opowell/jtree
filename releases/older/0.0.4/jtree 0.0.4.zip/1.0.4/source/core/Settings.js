const path      = require('path');
const fs        = require('fs-extra');
//const getportsync  = require('get-port-sync');
const openport  = require('openport');

class Settings {

     constructor(jt) {

         this.jt = jt;

         this.admins                 = {};
         this.adminLoginReq          = false; // whether or not admins need to login.
         this.adminUI                = 'internal/clients/admin';
         this.appFolders             = ['apps']; // the location of apps folders
         this.autoSaveFreq           = 1000; // how often to save active sessions, in ms.
         this.clientJSFile           = 'internal/clients/shared/shared.js';
         this.clientJSTemplateFile   = 'internal/sharedTemplate.js';
         this.clientUI               = 'internal/clients/participant';
         this.logPath                = 'internal/logs';
         this.logToConsole           = true;
         this.participantUI          = 'internal/clients/participant';
         this.openAdminOnStart       = true; // whether or not the admin page should be opened when the server starts.
//       this.logFile                = 'internal/log.txt'; If null, creates output in logPath/YYYYMMDD-HHmmss-SSS log.txt

         // On Linux / Mac, ports below 1024 require sudo access.
         var isWin = process.platform === "win32";
         if (isWin) {
             this.port               = 80;
         } else {
             this.port               = 3000;
         }
         this.predefinedQueues       = {};
         this.reloadApps             = true; // load apps every time they are accessed.
         this.sessionsFolder         = 'sessions';
         this.sendSessionAppFiles    = false;
         this.serverTimeInfoFilename = 'internal/serverState.json'; // location of file that stores last time server was active.
         this.sharedUI               = 'internal/clients/shared/';

         var settings = this; // so that settings can be modified without using 'jt.' prefix.
         eval(fs.readFileSync(path.join(this.jt.path, 'internal/settings.js')) + '');

         if (this.port === undefined) {
         //     try {
         //         this.port = getPortSync();
         //     } catch (err) {
         //         this.port = 3000;
         //     }
            openport.find(function(err, port) {
                if (err) { console.log(err); return; }
                this.port = port;
            });
         }


     }

}

var exports = module.exports = {};
exports.new = Settings;
