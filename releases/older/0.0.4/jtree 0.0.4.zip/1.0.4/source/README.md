<br>
jtree
=====

A javascript toolbox for running economics experiments.

RELEASE NOTES
--------------------------
1.0.1
** server
- fixed bug with stage timers expiring multiple times.
** clients
- added missing sharedTemplate.js file.
- hide stage content on load.
** general
- changed default port to 80.
- hide port from participant urls if it is 80.

1.0.0
- initial release
