// Default client functionality to be included in all (most?) apps.
jt.connected = function() {
    jt.socket.on('start-new-app', function(id) {
        location.reload();
    });
}

jt.showPId = function(id) {
    $('#participantId').text(id);
}
