app.groupSize   = 1;
app.workTime    = 150; // in seconds.
app.resultsTime = 30; // in seconds.

// Each row is a problem
app.numbers     = [
    [5, 3],         // Q1
    [8, 11, 5],     // Q2
    [14, 99, 2],    // etc.
    [15, 93, 56],
    [18, 25, 90, 41],
    [87, 35, 76, 19],
    [101, 51, 35, 9, 19]
];

// Answers are recorded as player.A1, player.A2, etc.
var workStage = app.newStage('work');
workStage.duration = app.workTime;

var resultsStage = app.newStage('results');
resultsStage.duration = app.resultsTime;
resultsStage.playerStart = function(player) { // when a player starts this stage

    let app = player.app();

    // For each correct answer, increment player points by 1.
    for (let i=0; i<app.numbers.length; i++) {

        // the problem.
        let prob = app.numbers[i];

        // calculate the answer.
        let ans = 0;
        for (let j=0; j<prob.length; j++) {
            ans = prob[j] + ans;
        }

        // check if player's answer is correct.
        if (ans === player['A' + (i+1)]) {
            player.points++;
        }
    }
}
