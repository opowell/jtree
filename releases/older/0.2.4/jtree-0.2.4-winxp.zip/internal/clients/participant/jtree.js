document.write('<script src="/socket.io/socket.io.js"></script>');
document.write('<script src="/shared/jquery-1.11.1.js"></script>');
document.write('<script src="/shared/shared.js"></script>');
document.write('<script src="/shared/utilsFns.js"></script>');
document.write('<script src="/shared/jquery.cookie.js"></script>');
document.write('<script src="/participant/defaultClient.js"></script>');
document.write('<link rel="stylesheet" href="/participant/popups.css">');
