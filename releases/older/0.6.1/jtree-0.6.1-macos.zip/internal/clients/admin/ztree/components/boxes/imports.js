document.write('<script src="/admin/ztree/components/boxes/GridBox.js"></script>');
document.write('<script src="/admin/ztree/components/boxes/StandardBox.js"></script>');
document.write('<script src="/admin/ztree/components/boxes/TackyBox.js"></script>');
document.write('<script src="/admin/ztree/components/boxes/GridBox.js"></script>');
