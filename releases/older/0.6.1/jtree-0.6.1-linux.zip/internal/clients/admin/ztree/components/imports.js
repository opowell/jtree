document.write('<script src="/admin/ztree/components/boxes/imports.js"></script>');
document.write('<script src="/admin/ztree/components/items/imports.js"></script>');
document.write('<script src="/admin/ztree/components/modals/imports.js"></script>');
document.write('<script src="/admin/ztree/components/panels/imports.js"></script>');
document.write('<script src="/admin/ztree/components/KeyBindings.js"></script>');
document.write('<script src="/admin/ztree/components/MainMenu2.js"></script>');
