// PARAMETERS
var DEFAULT_NUM_PARTICIPANT_VIEWS   = 4;

// VARIABLES
var playerFieldsToSkip = [
    'app',
    'appIndex',
    'clients',
    'group',
    'groupId',
    'id',
    'link',
    'numPoints',
    'participantId',
    'period',
    'roomId',
    'sessionId',
    'stageId',
    'stage',
    'stageIndex',
    'stageTimerStart',
    'stageTimerDuration',
    'stageTimerTimeLeft',
    'stageTimerRunning',
    'status',
    'time',
    'participant'
];

var participantTimers = {};

jt.createRoom = function() {
    var id = $('#create-room-input').val();
    if (id.length > 0) {
        server.createRoom(id);
    }
}

jt.createQueue = function() {
    var id = $('#create-queue-input').val().trim();
    if (id.length > 0) {
        server.createQueue(id);
    }
}

function reloadParticipantView() {
    for (var i in selectedParticipants) {
        var id = selectedParticipants[i];
        var url = location.origin + '/' + id;
        $('#participant-frame-' + id).attr('src', url)
    }
}

jt.setSessionView = function(a) {
    $('.session-tab').addClass('hidden');
    $('#view-session-' + a).removeClass('hidden');
    $('.session-tabBtn').removeClass('active');
    $('#tab-session-' + a).addClass('active');
}

setView = function(a) {
    $('.view').addClass('hidden');
    $('#view-' + a).removeClass('hidden');
    $('.view-tab').removeClass('active');
    $('.view-tab').removeClass('active-top-menu');
    $('#tab-' + a).addClass('active');
    $('#tab-' + a).addClass('active-top-menu');
}

deleteParticipantBtn = function() {
    var pId = $('#deleteParticipantSelect').val();
    server.deleteParticipant(pId);
}

partLink = function(pId) {
    if (jt.interfaceMode === 'basic') {
        return jt.serverURL() + '/' + pId;
    } else {
//        return jt.serverURL() + '/' + pId + '?sessionId=' + jt.data.session.id;
        return jt.serverURL() + '/session/' + jt.data.session.id + '/' + pId;
    }
}

roomLink = function(roomId) {
    return jt.serverURL() + '/room/' + roomId;
}

function ParticipantRow(participant) {
    var div = $('<tr class="participant-' + participant.id +'">');
    div.append($('<td>').text(participant.id));
    div.append($('<td><a href="http://' + partLink(participant.id) + '" target="_blank">' + partLink(participant.id) + '</a></td>'));
    div.append($('<td class="participant-' + participant.id + '-numClients">').text(participant.numClients));
//    div.append($('<td class="participant-' + participant.id + '-numPoints">').text(round(participant.numPoints, 2)));
    div.append($('<td id="app-' + participant.id + '">').text('-'));
//    div.append($('<td class="participant-' + participant.id + '-appIndex">').text('-'));
    var periodDiv = $('<td>');
    periodDiv.append($('<span class="participant-' + participant.id + '-periodIndex">').text('-'));
    div.append(periodDiv);
    div.append($('<td class="participant-' + participant.id + '-groupId">').text('-'));
    div.append($('<td class="participant-' + participant.id + '-stageId">').text('-'));
    div.append($('<td class="participant-' + participant.id + '-timeleft"><span class="minutes"></span>:<span class="seconds"></span></td>'));
    div.append($('<td class="participant-' + participant.id + '-status">').text('-'));
    return div;
}

function clearSelectedParticipants() {
    const numSelected = selectedParticipants.length;
    for (let i=0; i<numSelected; i++) {
        removeSelectedParticipant(selectedParticipants[0]);
    }
}

function roundValue(obj, dec) {
    if (isNumber(obj)) {
        return round(obj-0, dec);
    } else {
        return obj;
    }
}

function setNumParticipants() {
    const amt = $('#setNumParticipants').val();
    server.setNumParticipants(amt);
}

jt.setViewSize = function() {
    $('#setViewSize-Width').val($($('.participant-view')[0]).width());
    $('#setViewSize-Height').val($($('.participant-view')[0]).height());
    $('#setViewSizeModal').modal('show');
}

jt.updateViewSize = function() {
    $('.participant-view').width($('#setViewSize-Width').val());
    $('.participant-view').height($('#setViewSize-Height').val());
    $('#setViewSizeModal').modal('hide');
}

function setParticipantPlayer(pId, player, pDiv) {

    // Get the set of current headers
    var headers = $('#session-participants-headers > th');
    var headersText = [];

    // For each of the current headers, try to add a value for the player.
    for (var j=0; j<headers.length; j++) {
        var field = headers[j].innerHTML;
        if (!playerFieldsToSkip.includes(field)) {
            var foundEl = pDiv.find('.player-' + pId + '-' + field).length > 0;
            var value = '';
            if (player !== null) {
                if (player[field] !== undefined) {
                    value = player[field];
                }
            } else {
                foundEl = false;
            }
            if (!foundEl) {
                pDiv.append($('<td class="player-' + pId + '-' + field +'">'));
            }
            headersText.push(field);
            pDiv.find('.player-' + pId + '-' + field).text(roundValue(value, 2));
        }
    }

    // For each value in the player object,
    for (var i in player) {
        if (!playerFieldsToSkip.includes(i)) {
            if (!headersText.includes(i)) {
                addParticipantPlayerHeader(i);
                headersText.push(i);
            }
            pDiv.find('.player-' + pId + '-' + i).text(roundValue(player[i], 2));
        }
    }
    if (player !== null) {
        $('.participant-' + pId + '-status').text(player.status);
        if (player.status === 'active') {
            pDiv.addClass('player-active');
        } else {
            pDiv.removeClass('player-active');
        }
        var gId = groupId(player.groupId);
        if (player.group !== undefined) {
            gId = player.group.id;
        }
        msgs.playerSetStageIndex({participantId: player.id, stageIndex: player.stageIndex});
        msgs.participantSetGroupId({participantId: player.id, groupId: gId});
        clearInterval(participantTimers[pId]);
        if (player.stageTimerDuration === undefined) {
            var div = $('.participant-' + pId + '-timeleft');
            div.find('.minutes').text('');
            div.find('.seconds').text('');
        } else {
            if (player.stageTimerRunning) {
                var tl = player.stageTimerTimeLeft;
                var st = player.stageTimerStart;
                player.endTime = new Date(st).getTime() + tl;
                var now = Date.now();
                player.timeLeft = player.endTime - now;
                player.stageTimer = setInterval(function() {
                    var now = Date.now();
                    player.timeLeft = player.endTime - now;
                    if (player.timeLeft <= 0) {
                        clearTimeout(player.stageTimer);
                    }
                    var div = $('.participant-' + pId + '-timeleft');
                    var minutes = div.find('.minutes');
                    var seconds = div.find('.seconds');
                    jt.displayTimeLeft(minutes, seconds, player.timeLeft);
                }, jt.data.CLOCK_FREQUENCY);
                participantTimers[pId] = player.stageTimer;
            } else {
                player.timeLeft = player.stageTimerTimeLeft;
            }
            var div = $('.participant-' + pId + '-timeleft');
            var minutes = div.find('.minutes');
            var seconds = div.find('.seconds');
            jt.displayTimeLeft(minutes, seconds, player.timeLeft);
        }
    }

    let participant = player.participant;
    showPlayerCurApp(participant);
    $('.participant-' + participant.id + '-periodIndex').text(participant.periodIndex+1);

}

function updatePartClock() {
    displayTimeLeft($('#clock-minutes'), $('#clock-seconds'), data.timeLeft);
}

function sessionSetAutoplay(b) {
    const iframes = $('iframe.participant-frame');
    for (let i=0; i<iframes.length; i++) {
        let pId = $(iframes[i]).data('pId');
        setParticipantAutoplay(pId, b);
    }
}

function groupId(fullId) {
    if (fullId === undefined) {
        return '';
    }
    var i = fullId.indexOf('_group_');
    return fullId.substring(i + '_group_'.length);
}

function addParticipantPlayerHeader(name) {
    var headers = $('#session-participants-headers');
    headers.append($('<th>').text(name));
    var trows = $('#participants > tr');
    for (var i=0; i<trows.length; i++) {
        var tr = trows[i];
        var id = tr.children[0].innerHTML;
        var td = $('<td class="player-' + id + '-' + name +'">');
        $(tr).append(td);
    }
}

function CustomAppFolder(folder) {
    var div = $('<div>');
    div.addClass('custom-app-folder');
    var location = $('<div>').text(folder);
    location.addClass('custom-app-folder-location');
    div.append(location);
    var actions = $('<div>');
    actions.addClass('actions');
    div.append(actions);
    var fol = folder;
    var removeBtn = $('<a>')
        .click(fol, removeCustomAppFolder)
        .text("remove")
        .addClass('btn')
        .addClass('btn-sm')
        .addClass('btn-secondary')
        .attr('href', '#')
        .attr('role', 'button');
    actions.append(removeBtn);
    return div;
}

function ParticipantView(pId) {
    if (jt.data.session !== null && jt.data.session !== undefined) {
        var url = 'http://' + partLink(pId);
        var frame = $('<iframe>', {
            id:  'participant-frame-' + pId
        });
        $(frame).data('pId', pId);
        frame.attr('src', url);
        frame.addClass('participant-frame');
        return frame;
   } else {
       return null;
   }
}

function removeCustomAppFolder(folder) {

}

function showPlayerCurApp(participant) {
    var appText = participant.appIndex + '-';
    if (participant.appIndex < 1 || participant.appIndex > jt.data.session.apps.length) {
    } else {
        var app = jt.data.session.apps[participant.appIndex-1];
        appText = appText + app.id;
    }
    $('#app-' + participant.id).text(appText);
//    $('.participant-' + participant.id + '-appIndex').text(participant.appIndex);
}

function openClient(event) {
    // TODO
}

// DRAG-DROP UI
function showPanel(t, tt, ll, hh, ww, bb, rr, override) {
    var el = $(t);
    el.removeAttr('hidden');
}

function Panel(id, title, contentEl) {
    var card;
    var search = $('#panel-' + id);
    if (search.length > 0) {
        card = $(search[0]);
    } else {
        card = $('<div class="card panel ui-widget-content">');
        card.attr('id', 'panel-' + id);
        var cardHeader = $('<div>');
        cardHeader.addClass('card-header');
        card.append(cardHeader);
        var headerText = $('<span>').text(title);
        cardHeader.append(headerText);
    }
    // Set z-Index
    if (contentEl !== null) {
        // Close previous view, if any.
        $(card).find('.panel-content2').remove();

        card.append(contentEl);
        $(contentEl).addClass('panel-content2');
    }
    return card;
}

function participantOpenInNewTab() {
    for (var i in selectedParticipants) {
        var pId = selectedParticipants[i];
        participantOpenInNewTabId(pId);
    }
}

function participantOpenInNewTabId(id) {
    window.open("http://" + partLink(id));
}

function CardPanel(id, title, contentEl) {
    var cardBlock = $('<div class="card-block panel-content">');
    cardBlock.append(contentEl);
    var card = new Panel(id, title, cardBlock);
    return card;
}

function addCardPanel(id, title, contentEl) {
    var panel = new CardPanel(id, title, contentEl);
    panel.attr('hidden', true);
    $('body').append(panel);
    return panel;
}
function addPanel(id, title, contentEl) {
    var panel = new Panel(id, title, contentEl);
    panel.attr('hidden', true);
    $('body').append(panel);
    return panel;
}

// End DRAG-DROP UI

function setPlayerTimeLeft(participant, tl) {
    $('#timeleft-' + participant.id).text(tl);
}

function showPlayerCurPeriod(participant, p) {
    $('#period-' + participant.id).text(p);
}

function socketConnected() {
    server.refresh();
}

function ClientRow(obj) {
    var div = $('<tr>').attr('id', 'client-' + obj.id);
    div.append($('<td>').text(obj.id));
    div.append($('<td>').text(obj.pId));
    div.append($('<td>').text(obj.lastActivity));
    return div;
}

function showParticipants(participants) {
    resetParticipantsTable();
    sessionSetAutoplay(false);
    if (participants !== undefined) {
        for (var pId in participants) {
            var participant = participants[pId];
            showParticipant(participant);
        }
    }
}

function deleteParticipant(pId) {
    $('.participant-' + pId).remove();
    delete jt.data.session.participants[pId];
    $('#deleteParticipantSelect option[value=' + pId + ']').remove();
}

function resetParticipantsTable() {
    $('#participants').empty();
    $('#session-participants-headers').empty();
    const headers = ['id', 'link', 'clients', 'app', 'period', 'group', 'stage', 'time', 'status'];
    for (let i=0; i<headers.length; i++) {
        $('#session-participants-headers').append($('<th>').text(headers[i]));
    }
}

function viewAllParticipants() {
    for (var pId in jt.data.session.participants) {
        var participant = jt.data.session.participants[pId];
        viewParticipant(participant.id);
    }
}

function hideAllParticipants() {
    $('#views').empty();
}

jt.closeParticipantView = function(pId) {
    $('#panel-session-participant-' + pId).remove();
}

jt.refreshParticipantView = function(pId) {
    var panel = $('#participant-frame-' + pId)[0];
    panel.src = panel.src;
}

function viewParticipant(pId) {
    const view = new ParticipantView(pId);
    const elId = 'session-participant-' + pId;
    const existsAlready = $('#panel-' + elId).length > 0;
    const panel = addPanel(elId, 'Participant ' + pId, view);
    $('#panel-' + elId).addClass('participant-view');
    if (!existsAlready) {

        var closeBtn = $('<button type="button" class="headerBtn close float-right"><i title="close" class="fa fa-times"></i></button>');
        closeBtn.click(function() {
            jt.closeParticipantView(pId);
        });
        $($(panel).children()[0]).append(closeBtn);

        var newWinBtn = $('<button type="button" class="headerBtn close float-right"><i title="open in new window" class="fa fa-external-link-alt"></i></button>');
        newWinBtn.click(function() {
            participantOpenInNewTabId(pId);
        });
        $($(panel).children()[0]).append(newWinBtn);

        var autoplayBtn = $('<button title="toggle autoplay" id="' + pId + '-autoplay" type="button" class="headerBtn close float-right">A</button>');
        autoplayBtn.click(function() {
            toggleParticipantAutoplay(pId);
        });
        $($(panel).children()[0]).append(autoplayBtn);

        var refreshBtn = $('<button type="button" class="headerBtn close float-right"><i title="refresh" class="fa fa-redo-alt"></i></button>');
        refreshBtn.click(function() {
            jt.refreshParticipantView(pId);
        });
        $($(panel).children()[0]).append(refreshBtn);

    }
    showPanel('#panel-' + elId, 0, 0, '', '', '', '', false);
    $('#views').append(panel);
}

function toggleParticipantAutoplay(pId) {
    const elId = 'panel-session-participant-' + pId;
    const el = $('#' + elId);
    const apEl = $('#' + pId + '-autoplay');
    setParticipantAutoplay(pId, !apEl.hasClass('headerBtn-on'));
}

function setParticipantAutoplay(pId, b) {
    const elId = 'panel-session-participant-' + pId;
    const el = $('#' + elId);
    const apEl = $('#' + pId + '-autoplay');
    if (b) {
        apEl.addClass('headerBtn-on');
    } else {
        apEl.removeClass('headerBtn-on');
    }
    server.setAutoplay(pId, b);
    // let iframe = el.find('iframe')[0];
    // if (iframe.contentWindow.setAutoplay !== undefined) {
    //     iframe.contentWindow.setAutoplay(b);
    // }
}

function showAppFolders(folders) {
    $('#custom-app-folders').empty();
    for (var i in folders) {
        var folder = folders[i];
        showCustomAppFolder(folder);
    }
}

function showCustomAppFolder(folder) {
    var folderRow = new CustomAppFolder(folder);
    $('#custom-app-folders').append(folderRow);
}

function showParticipant(participant) {
    var participantRow = new ParticipantRow(participant);
    $('#participants').append(participantRow);
    if (participant.player !== null) {
        var playerRow = jt.PlayerRow(participant.player);
        $('#session-data').append(playerRow);
        participant.player.participant = participant;
        setParticipantPlayer(participant.id, participant.player, participantRow);
    }

    $('#deleteParticipantSelect').prepend($('<option>', {
        value: participant.id,
        text: participant.id
    }));

    $('#deleteParticipantSelect').val(participant.id);
}

jt.PlayerRow = function(player) {
    var div = $('<tr class="player-' + player.id +'">');
    div.append($('<td>').text(player.id));
    return div;
}

function StageRow(stage) {
    var div = $('<tr>');
    var name = $('<td>').text(stage.name);
    var wait = $('<td>').text(stage.waitForAll);
    var duration = $('<td>').text(stage.duration);
    div.append(name);
    div.append(wait);
    div.append(duration);
    return div;
}

function clickViewApp(event) {
    event.stopPropagation();
    viewApp(event.data.id, event.data.name);
}

function showQueue(queue) {

    var div = $('<tr queueId="' + queue.id + '" style="cursor: pointer">');
    try {
        div.append($('<td>').text(queue.id));
        div.append($('<td>').text(queue.displayName));
        var appsText = queue.apps.length + ': ';
        for (var i=0; i<queue.apps.length; i++) {
            var app = queue.apps[i];
            appsText += app.appId;
            if (objLength(app.options) > 0) {
                appsText += '(';
                for (var j in app.options) {
                    appsText += app.options[j] + ', ';
                }
                // remove last comma, replace with closing parenthesis
                appsText = appsText.substring(0, appsText.length - 2);
                appsText += ')';
            }
            if (i < queue.apps.length - 1) {
                appsText += ', ';
            }
        }
        div.append($('<td>').text(appsText));
        var que = queue;
        var qId = que.id;

        var actionDiv = $('<div class="btn-group">');
        var startBtn = $('<button class="btn btn-outline-primary btn-sm"><i class="fa fa-play" title="start new session with this queue"></i></button>');
        startBtn.click(function(ev) {
            ev.stopPropagation();
            server.startSessionFromQueue(qId);
        });
        actionDiv.append(startBtn);

        div.click(function() {
             jt.openQueue(que);
        });

        var deleteBtn = jt.DeleteButton();

        deleteBtn.click(function(ev) {
            ev.stopPropagation();
            jt.deleteQueueConfirm(qId);
        });
        actionDiv.append(deleteBtn);

        div.prepend($('<td>').append(actionDiv));

    } catch (err) {
    }

    $('#view-queues-table').append(div);
}

jt.DeleteButton = function() {
    return $(`<button class="btn btn-sm btn-outline-secondary">
        <i class="fa fa-trash" title="delete"></i>
    </button>`);
}

jt.CopyButton = function() {
    return $(`<button class="btn btn-sm btn-outline-secondary">
        <i class="fa fa-copy" title="copy"></i>
    </button>`);
}

jt.deleteQueueConfirm = function(id) {
    if (id === undefined) {
        id = $('#view-queue-id').text();
    }
    jt.confirm(
        'Are you sure you want to delete Queue ' + id + '?',
        function() {
            server.deleteQueue(id);
        }
    );

}

function SessionDiv(session) {
    var row = $('<tr role="button" style="cursor: pointer">');
    var actionDiv = $('<td>');
    var delBtn = jt.DeleteButton();
    delBtn.click(function (ev) {
        ev.stopPropagation();
        var sessionId = $(ev.target).parents('tr').attr('sessionId');
        jt.confirm(
            'Are you sure you want to delete Session ' + sessionId + '?',
            function() {
                jt.socket.emit('deleteSession', sessionId);
            }
        );
    });
    actionDiv.append(delBtn);
    row.append(actionDiv);
    row.append($('<td>').text(session.id));
    row.append($('<td>').text(session.numParticipants));
    row.append($('<td class="truncate">').text(session.numApps + ': ' + session.appSequence));
    var aId = session.id;
    row.attr('sessionId', aId);
    row.click({id: aId, name: aId}, server.openSession);
    return row;
}

function setQueue(event) {
    event.stopPropagation();
    console.log('set session queue: ' + event.data.id + ', name = ' + event.data.name);
    server.setQueue(event.data.id);
}

function setQueueAndStart(event) {
    event.stopPropagation();
    console.log('set session queue and start: ' + event.data.id + ', name = ' + event.data.name);
    server.setQueueAndStart(event.data.id);
}

function addQueue(event) {
    event.stopPropagation();
    console.log('add queue to session: ' + event.data.id + ', name = ' + event.data.name);
    server.addQueue(event.data.id);
}

function addAppToSessionAndStart(event) {
    event.stopPropagation();
    console.log('add app to session and start: ' + event.data.id + ', name = ' + event.data.name);
    server.addAppToSessionAndStart(event.data.id);
    setPage('participants');
}

function addAppToSession(event) {
    event.stopPropagation();
    console.log('add app to session: ' + event.data.id + ', name = ' + event.data.name);
    server.addAppToSession({id: event.data.id, sId: data.session.id});
}

function addSelectedAppToQueue() {
    var id = $('#addAppToQueueSelect').val();
    server.sessionAddApp(id);
}

jt.deleteApp = function() {
    var appId = $('#view-app-id').text();
    jt.confirm(
        'Are you sure you want to delete the app ' + appId + '?',
        function() {
            jt.socket.emit('deleteApp', appId);
        }
    );
}

jt.deleteSession = function() {
    var sId = $('#session-id').text();
    jt.confirm(
        'Are you sure you want to delete Session ' + sId + '?',
        function() {
            jt.socket.emit('deleteApp', sId);
        }
    );
}

function showAppInfos(appInfos) {
    $('#appInfos').empty();
    for (var a in appInfos) {
        var app = appInfos[a];
        var row = jt.AppRow(app, {}, ['id', 'description']);
        row.click(function(ev) {
            if (
                ($(ev.target).prop('tagName') !== 'SELECT') &&
                ($(ev.target).prop('tagName') !== 'INPUT')
            ) {
                jt.openApp($(this).data('appId'));
            }
        });
        row.css('cursor', 'pointer');
        row.data('appId', app.id);
        row.attr('appId', app.id);
        var actionDiv = $('<div class="btn-group">');
        var createSessionBtn = $(`
        <button class="btn btn-outline-primary btn-sm">
            <i class="fa fa-play" title="start new session with this app"></i>
        </button>`);
        createSessionBtn.click(function() {
            var optionEls = $(this).parents('tr').find('[app-option-name]');
            var options = jt.deriveAppOptions(optionEls);
            server.createSessionAndAddApp($(this).parents('tr').data('appId'), options);
        });
        actionDiv.append(createSessionBtn);
        var addToQueueBtn = $(`<button class="btn btn-sm btn-outline-primary">
            <i class="fa fa-plus" title="add to queue"></i>
        </button>`);
        addToQueueBtn.click(function(ev) {
            ev.stopPropagation();
            var appId = $(ev.target).parents('tr').attr('appId');
            jt.addAppToNewSessionQueue(appId);
        })
        actionDiv.append(addToQueueBtn);

        var delBtn = jt.DeleteButton();
        delBtn.click(function(ev) {
            ev.stopPropagation();
            var appId = $(ev.target).parents('tr').attr('appId');
            jt.confirm(
                'Are you sure you want to delete App ' + appId + '?',
                function() {
                    jt.socket.emit('deleteApp', appId);
                }
            );
        });
        actionDiv.append(delBtn);

        row.prepend($('<td>').append(actionDiv));

        $('#appInfos').append(row);
    }
}

jt.addAppToNewSessionQueue = function(id) {
    var div = $('<span class="view-apps-queue-app">').text(id);
    $('#view-apps-queue').append(div);
}

jt.createApp = function() {
    var appId = $('#create-app-input').val();
    jt.socket.emit('createApp', appId);
}

function showSessions() {
    $('#active-sessions').empty();
    $('#inactive-sessions').empty();
    $('#view-sessions-list').empty();
    for (var i=0; i<jt.data.sessions.length; i++) {
        showSessionRow(jt.data.sessions[i]);
    }

}

function showSessionInView(session) {
}

function showSessionRow(session) {
    $('#view-sessions-list').prepend(SessionDiv(session));
    $('#active-sessions').prepend(SessionDiv(session));
}

function updateSessionApps() {
    $('#session-apps-table').empty();
    if (jt.data.session !== null && jt.data.session !== undefined) {
        for (var a in jt.data.session.apps) {

            var app = jt.data.session.apps[a];

            var row = jt.AppRow(app, app.optionValues, ['#', 'id', 'options']);
            row.data({aId: app.id, i:a, sId: jt.data.session.id});
            $(row).find('[app-option-name]').change(function() {
                var data = $(this).parents('tr').data();
                data.name = $(this).attr('app-option-name');
                data.value = $(this).val();
                jt.socket.emit('setSessionAppOption', data);
            });
            var actionsEl = $('<td>');

            var deleteBtn = jt.DeleteButton();
            deleteBtn.click(function(ev) {
                 server.sessionDeleteApp($(this).parents('tr').data());
            });
            actionsEl.append(deleteBtn);
            row.prepend(actionsEl);

            $('#session-apps-table').append(row);
        }
    }
}

jt.showAddAppToSessionModal = function() {
    $('#addAppToSessionModal').modal('show');
    $('#addAppToSessionModal-apps').empty();
    for (var i in jt.data.appInfos) {
        var app = jt.data.appInfos[i];
        var row = jt.AppRow(app, {}, ['id', 'description']);
        row.data('appId', app.id);

        row.click(function(ev) {
            if (
                ($(ev.target).prop('tagName') !== 'SELECT') &&
                ($(ev.target).prop('tagName') !== 'INPUT')
            ) {
                var optionEls = $(this).find('[app-option-name]');
                var options = jt.deriveAppOptions(optionEls);
                server.sessionAddApp($(this).data('appId'), options);
                $('#addAppToSessionModal').modal('hide');
            }
        });
        row.css('cursor', 'pointer');

        $('#addAppToSessionModal-apps').append(row);
    }
}

jt.showAddQueueToSessionModal = function() {
    $('#addQueueToSessionModal').modal('show');
    $('#addQueueToSessionModal-queues').empty();
    for (var i in jt.data.queues) {
        var queue = jt.data.queues[i];
        var row = jt.QueueRow(queue, ['id', 'apps']);
        row.css('cursor', 'pointer');
        row.data('queue', queue.id);

        row.click(function(ev) {
            server.sessionAddQueue($(this).data('queue'));
            $('#addQueueToSessionModal').modal('hide');
        });

        $('#addQueueToSessionModal-queues').append(row);
    }
}

jt.showAddAppToRoomModal = function() {
    $('#addAppToRoomModal').modal('show');
    $('#addAppToRoomModal-apps').empty();
    for (var i in jt.data.appInfos) {
        var app = jt.data.appInfos[i];
        var row = $('<tr>');
        row.append($('<td>').text(app.id));
        row.append($('<td>').text(app.numPeriods));
        row.append($('<td>').text((app.name !== undefined ? app.name : app.id)));
        row.append($('<td>').text((app.description !== undefined ? app.description : '')));
        row.data('appId', app.id);
        row.click(function(ev) {
            server.roomAddApp($(this).data('appId'));
        });
        $('#addAppToRoomModal-apps').append(row);
    }
}

jt.addAppToNewQueue = function(aId) {

}

jt.AppRow = function(app, options, cols) {

    if (cols === undefined) {
        cols = ['id', 'name', 'description'];
    }

    var row = $('<tr>');

    if (app.indexInSession !== undefined) {
        app.index = app.indexInSession;
    }

    if (app.indexInQueue !== undefined) {
        app.index = app.indexInQueue;
    }

    try {

        row.data('appId', app.id);

        for (var i in cols) {
            var col = cols[i];
            switch(col) {
            case '#':
                row.append($('<td>').text(app.index));
                break;
            case 'id':
                row.append($('<td>').text(app.id));
                break;
            case 'description':
                row.append($('<td>').text((app.description)));
                break;
            case 'name':
                row.append($('<td>').text((app.name !== undefined ? app.name : app.id)));
                break;
            case 'options':
                var optionsEl = $('<td style="display: flex; flex-wrap: wrap; padding-top: calc(.375rem - 1px);">');
                for (var i in app.options) {
                    var option = app.options[i];
                    var selected = undefined;
                    if (app[option.name] !== undefined) {
                        selected = app[option.name];
                    }
                    if (option.defaultVal !== undefined) {
                        selected = option.defaultVal;
                    }
                    if (options !== undefined && options[option.name] !== undefined) {
                        selected = options[option.name];
                    }
                    var div = AppOptionDiv(option, selected);
                    optionsEl.append(div);
                }
                row.append(optionsEl);
                break;
            }
        }

    } catch (err) {}

    return row;
}

jt.QueueRow = function(queue, cols) {

    if (cols === undefined) {
        cols = ['id', 'apps'];
    }

    var row = $('<tr>');

    row.data('queueId', queue.id);

    for (var i in cols) {
        var col = cols[i];
        switch(col) {
        case 'id':
            row.append($('<td>').text(queue.id));
            break;
        case 'apps':
            var appsEl = $('<td>');
            for (var i in queue.apps) {
                var app = queue.apps[i];
                var div = QueueAppDiv(app);
                appsEl.append(div);
            }
            row.append(appsEl);
            break;
        }
    }

    return row;
}

jt.showAddAppToQueueModal = function() {
    $('#addAppToQueueModal').modal('show');
    $('#addAppToQueueModal-apps').empty();
    for (var i in jt.data.appInfos) {
        var app = jt.data.appInfos[i];
        var row = jt.AppRow(app, {}, ['id', 'name', 'description']).css('cursor', 'pointer');
        row.click(function(ev) {
            if ($(ev.target).prop('tagName') !== 'SELECT') {
                var optionEls = $(this).find('[app-option-name]');
                var options = jt.deriveAppOptions(optionEls);
                server.queueAddApp($(this).data('appId'), options);
            }
        });
        $('#addAppToQueueModal-apps').append(row);
    }
}

function showStages(stages) {
    $('#stages').empty();
    for (var s in stages) {
        var stageRow = new StageRow(stages[s]);
        $('#stages').append(stageRow);
    }
}

function showSessionAppName(an) {
    $('#sessionAppName').text(an);
}

jt.startSessionFromQueue = function(id) {
    if (id === undefined) {
        id = $('#view-queue-id').text();
    }
    server.startSessionFromQueue(id);
}

function updateSessionCanPlay(session) {
    if (session.isRunning) {
        $('#sessionResumeBtn').addClass('disabled');
        $('#sessionPauseBtn').removeClass('disabled');
        $('#session-canPlay').text('running');
    } else {
        $('#sessionResumeBtn').removeClass('disabled');
        $('#sessionPauseBtn').addClass('disabled');
        $('#session-canPlay').text('paused');
    }
}

function updateSessionActive(session) {
    if (session.active) {
        $('#sessionSetActiveBtn').addClass('disabled');
        $('#sessionSetInactiveBtn').removeClass('disabled');
        $('#session-status').text('active');
    } else {
        $('#sessionSetActiveBtn').removeClass('disabled');
        $('#sessionSetInactiveBtn').addClass('disabled');
        $('#session-status').text('inactive');
    }
}

function viewCurApp() {
    viewApp(data.appId, data.appName);
}

function viewApp(id, name) {
    console.log('view app ' + id);
    $('#app-name').text(name);
    $('#app-id').text(id);
    if (data.viewedApp == null || id != data.viewedApp.id) {
        server.getApp(id);
    } else {
        showStages(data.viewedApp.stages);
        setPage('app');
    }
    data.viewedAppId = id;
}

function showPId(id) {
    $('#jt-admin-menu-login').text(id);
}

function addAppFolder() {
    var folder = $('#input-app-folder').val();
    server.addAppFolder(folder);
}

jt.setApps = function(apps) {
    jt.data.appInfos = apps;
    showAppInfos(apps);
}

function refresh(ag) {
    console.log('refresh');

    jt.data.clockRunning = ag.clockRunning;
    jt.data.ag = ag;
    jt.data.predefinedQueues = ag.predefinedQueues;
    jt.data.appName = ag.appName;
    jt.data.sessions = ag.sessions;
    jt.data.rooms = ag.rooms;
    jt.data.queues = ag.queues;
    jt.data.jtreeLocalPath = ag.jtreeLocalPath;

    jt.setApps(ag.apps);
    showSessions();
    showAppFolders(ag.appFolders);
    showRooms();
    showQueues();
}

function showRooms() {
    $('#rooms-list').empty();
    for (var i in jt.data.rooms) {
        var room = jt.data.rooms[i];
        showRoom(room);
    }
}

function showQueues() {
    $('#view-queues-table').empty();
    for (var i in jt.data.queues) {
        var queue = jt.data.queues[i];
        showQueue(queue);
    }
}

function showRoom(room) {
    var div = $('<div class="card my-1" style="width: 25rem;">');
    var body = $('<div class="card-body">');
    div.append(body);
    var title = $('<h6 class="card-title">').text(room.displayName + ' (' + room.id + ')');
    var propsDiv = $('<div>');

    body.append(title);
    div.click(function() {
        openRoom(room);
    });
    $('#rooms-list').append(div);
}

jt.viewRoomUpdateLabel = function(roomPart) {
    if (roomPart.roomId === $('#view-room-id').text()) {
        var label = $('[roomId="' + roomPart.roomId + '"][pId="' + roomPart.id + '"]');
        if (roomPart.clients.length > 0) {
            label.addClass('text-white').addClass('bg-success');
            $('#view-room-labels').append(label);
        } else {
            label.removeClass('text-white').removeClass('bg-success');
            $('#view-room-labels-notconnected').append(label);
        }
        jt.updateViewRoomConnectionNumbers();
    }
}

jt.updateViewRoomConnectionNumbers = function() {
    var connected = 0;
    var notConn = 0;
    var room = jt.getRoom($('#view-room-id').text());
    for (var i in room.participants) {
        if (room.participants[i].clients.length > 0) {
            connected++;
        } else {
            notConn++;
        }
    }
    $('#view-room-connected-title').text('Connected participants (' + connected + ')');
    $('#view-room-notconnected-title').text('Not connected participants (' + notConn + ')');
}

jt.getRoom = function(roomId) {
    for (var r in jt.data.rooms) {
        if (jt.data.rooms[r].id === roomId) {
            return jt.data.rooms[r];
        }
    }
    return null;
}

jt.queue = function(id) {
    for (var r in jt.data.queues) {
        if (jt.data.queues[r].id === id) {
            return jt.data.queues[r];
        }
    }
    return null;
}

jt.app = function(appId) {
    return jt.data.appInfos[appId];
}

jt.viewRoomShowApp = function(appId) {
    var app = jt.app(appId);
    var div = $('<tr>');
    try {
        div.append($('<td>').text(app.id));
        div.append($('<td>').text(app.numPeriods));

        var aId = app.id;
        var sId = data.session.id;
        var delBtn = $('<button class="btn btn-sm btn-secondary">')
        .click({aId: aId, i: i, sId: sId}, server.sessionDeleteApp)
        .text("delete");
        div.append($('<td>').append(delBtn));
    } catch (err) {
    }
    $('#room-apps-table').append(div);
}

jt.viewQueueShowApp = function(app, qId) {
    var appId = app.appId;
    var options = app.options;
    var app2 = jt.app(appId);
    app2.indexInQueue = app.indexInQueue;
    app = app2;
    var div = jt.AppRow(app, options, ['#', 'id', 'options']);
    $('#queue-apps-table').append(div);
    var actionsDiv = $('<div class="btn-group">');
    var deleteBtn = jt.DeleteButton();
    var copyBtn = jt.CopyButton();
    copyBtn.click(function() {
        server.queueAddApp(appId, options);
    });
    actionsDiv.append(copyBtn);
    deleteBtn.click(function() {
        jt.confirm(
            'Are you sure you want to delete App #' + app.indexInQueue + ' - ' + app.id + ' from Queue ' + qId + '?',
            function() {
                jt.socket.emit('deleteAppFromQueue', {qId: qId, aId: app.id});
            }
        );
    });
    actionsDiv.append(deleteBtn);
    div.prepend(actionsDiv);
}

jt.confirm = function(text, ifYes) {
    $('#confirmQuestion').text(text);
    $('#confirmYesBtn').click(ifYes);
    $('#confirmModal').modal('show');
}

jt.openApp = function(appId) {
    var app = jt.app(appId);
    setView('app');

    if (app.title === undefined) {
        $('#view-app-displayName').text(app.id);
    } else {
        $('#view-app-displayName').text(app.title);
    }

    $('#edit-app-id').val(app.id);
    $('#view-app-id').text(app.id);
    $('#view-app-description').text(app.description);
    $('#view-app-appjs').text(app.appjs);
    $('#view-app-clienthtml').text(app.clientHTML);

    var editor = ace.edit("edit-app-appjs");
    editor.setValue(app.appjs, -1);

    var editorCH = ace.edit("edit-app-clienthtml");
    editorCH.setValue(app.clientHTML, -1);

    hljs.highlightBlock($('#view-app-appjs')[0]);
    hljs.highlightBlock($('#view-app-clienthtml')[0]);

    try {
        $('#view-app-clientpreview').contents().find('html').html(app.clientHTML);
    } catch (err) {

    }

    $('#view-app-stages').text(app.stages.length + ': ' + app.stages);
    $('#view-app-periods').text(app.numPeriods);

    $('#view-app-options').empty();
    for (var i in app.options) {
        var option = app.options[i];
        var div = AppOptionDiv(option);
        $('#view-app-options').append(div);
    }
}

jt.saveApp = function() {
    var app = {};
    app.origId = $('#view-app-id').text();
    app.id = $('#edit-app-id').val();
    var editor = ace.edit("edit-app-appjs");
    app.appjs = editor.getValue();

    var editorCH = ace.edit("edit-app-clienthtml");
    app.clientHTML = editorCH.getValue();

    jt.socket.emit('saveApp', app);

}

jt.saveAppAndView = function() {
    jt.saveApp();
    setView('app');
}

QueueAppDiv = function(app) {
    var text = app.appId;
    if (objLength(app.options) > 0) {
        text += '(';
    }
    for (var i in app.options) {
        text += i + '=' + app.options[i] + ', ';
    }
    if (objLength(app.options) > 0) {
        text = text.substring(0, text.length - 2);
        text += ')';
    }
    return $('<div>').text(text);
}

AppOptionDiv = function(option, selected) {
    var div = $('<div class="form-group row option-div">');
    var nameEl = $('<label for="view-app-option-' + option.name + '" class="option-label col-form-label">').text(option.name + ': ');
    div.append(nameEl);
    var tdSel = $('<div class="option-input">');
    div.append(tdSel);
    switch (option.type) {
        case 'select':
        var select = $('<select class="form-control view-app-option" app-option-name="' + option.name + '" id="view-app-option-' + option.name + '">');
        tdSel.append(select);
        for (var j in option.values) {
            var optEl = $('<option value="' + option.values[j] + '">' + option.values[j] + '</option>');
            if (selected !== undefined && selected == option.values[j]) {
                optEl.prop('selected', true);
            }
            select.append(optEl);
        }
        break;
        case 'text':
            var input = $('<input type="text" class="form-control" app-option-name="' + option.name + '" id="view-app-option-' + option.name + '">');
            input.val(option.defaultVal);
            tdSel.append(input);
            break;
        case 'number':
            var tagText = '<input type="number" class="form-control"';
            if (option.min !== null) {
                tagText += ' min=' + option.min;
            }
            if (option.max !== null) {
                tagText += ' max=' + option.max;
            }

            if (option.step !== null) {
                tagText += ' step=' + option.step;
            }
            if (selected !== null && selected !== undefined) {
                tagText += ' value=' + selected;
            } else {
                tagText += ' value=' + option.defaultVal;
            }
            var input = $(tagText + ' class="view-app-option form-control" app-option-name="' + option.name + '" id="view-app-option-' + option.name + '">');
            tdSel.append(input);
            break;
    }
    return div;
}

jt.updateChartPage = function() {

}

jt.chartVar = function() {

    var colors = [
        "#3e95cd", '#3366cc', '#dc3912', '#ff9900', '#109618', '#990099',
        '#0099c6', '#dd4477', '#66aa00', '#b82e2e', '#316395', '#3366cc'
    ]
    var colorIndex = 0;

    var varName = $('#chartVarName').val();

    var ctx = document.getElementById('session-data-chart').getContext('2d');

    var data = {};
    data.datasets = [];
    data.labels = [];

    // Series
    for (var i in jt.data.session.participants) {
        var dataset = {};
        dataset.label = jt.data.session.participants[i].id
        dataset.fill = false;
        dataset.data = [];
        var color = colors[colorIndex++]
        dataset.borderColor = color;
        dataset.pointBorderColor = color;
        dataset.pointBackgroundColor = color;
        dataset.backgroundColor = color;
        data.datasets.push(dataset);
    }

    // X-Axis
    if (jt.data.session.apps.length < 1) {
        return;
    }
    var appId = 0;
    var periods = jt.data.session.apps[appId].periods;
    for (var i in periods) {

        // Add the period as a label
        data.labels.push(periods[i].id);

        // For each series, add a data point, or blank if missing
        for (var d in data.datasets) {
            var dataset = data.datasets[d];
            playerSearch: {
                for (var g in periods[i].groups) {
                    var group = periods[i].groups[g];
                    for (var pl in group.players) {
                        var player = group.players[pl];
                        if (dataset.label === player.id) {
                            // Found player for this dataset, store their data point and quit search.
                            dataset.data.push(player[varName]);
                            break playerSearch;
                        }
                    }
                }
                // If missing, add -1.
                dataset.data.push(-1);
            }
        }
    }


    var options = {
        legend: {
            position: 'right'
        },
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero:true
                },
                scaleLabel: {
                    display: true,
                    labelString: varName
                }
            }],
            xAxes: [{
                scaleLabel: {
                    display: true,
                    labelString: 'Period'
                }
            }]
        },
        elements: {
            line: {
                tension: 0, // disables bezier curves
            }
        }
    }

    var chartInfo = {type: 'line', data: data, options: options};

    var myChart = new Chart(ctx, chartInfo);

}

jt.startSessionWithApp = function() {
    var appId = $('#view-app-id').text();
    var optionEls = $('#view-app [app-option-name]');
    var options = jt.deriveAppOptions(optionEls);
    server.createSessionAndAddApp(appId, options);
}

jt.deriveAppOptions = function(optionEls) {
    var options = {};
    for (var i=0; i<optionEls.length; i++) {
        var el = optionEls[i];
        var name = $(el).attr('app-option-name');
        options[name] = $(el).val();
    }
    return options;
}

function openRoom(room) {
    setView('room');

    $('#view-room-displayName').text(room.displayName);
    $('#view-room-id').text(room.id);
    $('#view-room-roomLink').text(roomLink(room.id));
    $('#view-room-roomLink').attr('href', 'http://' + roomLink(room.id));
    $('#view-room-labels').empty();
    $('#view-room-labels-notconnected').empty();
    $('#view-room-participantLinks').empty();
    jt.updateViewRoomConnectionNumbers();
    $('#room-apps-table').empty();
    for (var i in room.apps) {
        jt.viewRoomShowApp(room.apps[i]);
    }

    $('#edit-room-displayName').text(room.displayName);
    $('#edit-room-displayName-input').val(room.displayName);
    $('#edit-room-id').val(room.id);
    $('#edit-room-useSecureURLs-' + room.useSecureURLs).prop('checked', true);
    $('#edit-room-labels').empty();
    for (var i in room.labels) {
        var label = room.labels[i];
        var labDiv = $('<div class="my-1 view-room-label" roomId="' + room.id + '" pId="' + label + '">').text(label);

        var connected = false;
        for (var j in room.participants) {
            var part = room.participants[j];
            if (part.id === label && part.clients.length > 0) {
                labDiv.addClass('text-white').addClass('bg-success');
                connected = true;
                break;
            }
        }

        if (connected) {
            $('#view-room-labels').append(labDiv);
        } else {
            $('#view-room-labels-notconnected').append(labDiv);
        }


        $('#edit-room-labels').append(label + '\n');
        var prl = partRoomLink(i, room);
        var partLink = $('<a href="http://' + prl + '" target="_blank">' + prl + '</a>');
        $('#view-room-participantLinks').append(partLink);
    }

    $('#edit-room-labels-title').text('Labels (' + room.labels.length + ')');
}

jt.openQueue = function(queue) {
    setView('queue');

    $('#view-queue-displayName').text(queue.displayName);
    $('#view-queue-id').text(queue.id);
    $('#queue-apps-table').empty();
    for (var i in queue.apps) {
        jt.viewQueueShowApp(queue.apps[i], queue.id);
    }

}

jt.saveRoomAndView = function() {
    jt.saveRoom();
    setView('room');
}

jt.saveRoom = function() {
    var newRoom = {};
    newRoom.originalId = $('#view-room-id').text();
    newRoom.id = $('#edit-room-id').val();
    newRoom.displayName = $('#edit-room-displayName-input').val();
    if ($('#edit-room-useSecureURLs-true').prop('checked')) {
        newRoom.useSecureURLs = true;
    } else {
        newRoom.useSecureURLs = false;
    }
    newRoom.labels = $('#edit-room-labels').val().split('\n');
    server.saveRoom(newRoom);
}

function partRoomLink(i, room) {
    var pId = room.labels[i].trim();
    if (room.useSecureURLs) {
        return roomLink(room.id) + '/' + pId + '/' + room.hashes[i];
    } else {
        return roomLink(room.id) + '/' + pId;
    }
}

function removeClient(cId) {
    $('#client-' + cId).remove();
}

function appId(id) {
    var index = id.indexOf('app_');
    var indexPrd = id.indexOf('period_');
    if (index > -1) {
        if (indexPrd < 0) {
            return id.substring(index+'app_'.length);
        } else {
            return id.substring(index+'app_'.length, indexPrd);
        }
    }
    return null;
}

jt.connected = function() {

    $('#startAdvanceSlowest').click(function(ev) {
        ev.stopPropagation();
        server.sessionAdvanceSlowest();
    });

    // Register to listen for messages defined in msgs object.
    // https://stackoverflow.com/questions/29917977/get-event-name-in-events-callback-function-in-socket-io
    for (var i in msgs) {
        console.log('listening for message ' + i);
        (function(i) {
            jt.socket.on(i, function(d) {
                console.log('received message ' + i + ': ' + JSON.stringify(d));
                eval('msgs.' + i + "(d)");
            });
        })(i);
    }

    jt.socket.on('refresh-admin', function(ag) {
        refresh(ag);
    });

    jt.socket.on('refresh-apps', function(appInfos) {
        console.log('refresh-apps');
        jt.data.appInfos = appInfos;
        showAppInfos(appInfos);
    });

    jt.socket.on('stage-end', function(a) {
        stageEnd(a);
        console.log('stage-end');
    });

    jt.socket.on('get-app', function(a) {
        jt.data.viewedApp = a;
        viewApp(a.id, a.title);
    });

    jt.socket.on('add-participant', function(participant) {
        if (participant.session.id === jt.data.session.id) {
            console.log('add participant: ' + participant);
            jt.data.session.participants[participant.id] = participant;
            showParticipant(participant);
            //        viewParticipant(participant.id);
        }
    });

    jt.socket.on('add-client', function(client) {
        if (client.session.id === jt.data.session.id) {
            console.log('add client: ' + client);
            jt.data.session.clients.push(client);
            var participant = findByIdWOJQ(jt.data.session.participants, client.pId);
            if (participant !== null) {
                participant.numClients++;
                $('.participant-' + client.pId + '-numClients').text(participant.numClients);
            }
        }
    });

    jt.socket.on('remove-client', function(client) {
        if (client.session.id === jt.data.session.id) {
            console.log('remove client: ' + client);
            deleteById(jt.data.session.clients, client.id);
            removeClient(client.id);
            var participant = findByIdWOJQ(jt.data.session.participants, client.pId);
            if (participant != null) {
                participant.numClients--;
                $('.participant-' + client.pId + '-numClients').text(participant.numClients);
            }
        }
    });

// TODO: move all message functionality here
    jt.socket.on('messages', function(msgs) {
        for (m in msgs) {
            var msg = msgs[m];
            // eval(msg.type + "(msg.data)");
            switch (msg.type) {
                case 'set-session-app-status':
                    jt.data.session.appSequence[msg.data.index].status = msg.data.status;
                    showSessionAppSequence();
                    break;
                case 'clock-start':
                    startClock(msg.data.endTime);
                    break;
                case 'refresh-admin':
                    refresh(msg.data);
                    break;
            }
        }
    });

    var interfaceMode = localStorage.getItem('interfaceMode');
    if (interfaceMode === null) {
        interfaceMode = 'basic';
    }
    jt.setInterfaceMode(interfaceMode);

  var sId = localStorage.getItem("sessionId");
  if (sId !== null) {
      server.openSessionId(sId);
  } else {
      server.sessionCreate();
  }

}

jt.setInterfaceMode = function(mode) {
    jt.interfaceMode = mode;
    localStorage.setItem('interfaceMode', mode);
    if (mode === 'basic') {
        $('#admin-interface-basic').prop('checked', true);
    }
    else if (mode === 'advanced') {
        $('#admin-interface-advanced').prop('checked', true);
    }
    $('[admin-interface][admin-interface="' + mode + '"]').show();
    $('[admin-interface][admin-interface!="' + mode + '"]').hide();
}

closeViews = function() {
    var views = $('.participant-view');
    views.each(function() {
        this.remove();
    });
}

jt.socketConnected = function() {
    server.refreshAdmin();

    ace.config.set("basePath", "/shared/ace");

    var editor = ace.edit("edit-app-appjs");
    var editorCH = ace.edit("edit-app-clienthtml");
    editor.setTheme("ace/theme/tomorrow");
    editor.session.setMode("ace/mode/javascript");
    editorCH.setTheme("ace/theme/tomorrow");
    editorCH.session.setMode("ace/mode/html");
}

updateAllowNewParts = function() {
    $('#allowNewParts')[0].checked = jt.data.session.allowNewParts;
}
