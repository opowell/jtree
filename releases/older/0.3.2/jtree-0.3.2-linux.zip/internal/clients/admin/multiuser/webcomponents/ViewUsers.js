class ViewUsers extends HTMLElement {
    connectedCallback() {
      this.innerHTML = `
      <!-- USERS -->
      <div id='view-users' class='view hidden'>
          <h2>Users</h2>
          Coming soon.
      </div>
      `;
    }
}

window.customElements.define('view-users', ViewUsers);
