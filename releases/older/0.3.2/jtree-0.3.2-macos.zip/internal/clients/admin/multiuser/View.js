jt.confirm = function(text, ifYes) {
    $('#confirmQuestion').text(text);
    $('#confirmYesBtn').click(ifYes);
    $('#confirmModal').modal('show');
}

QueueAppDiv = function(app) {
    var text = app.appId;
    if (objLength(app.options) > 0) {
        text += '(';
    }
    for (var i in app.options) {
        text += i + '=' + app.options[i] + ', ';
    }
    if (objLength(app.options) > 0) {
        text = text.substring(0, text.length - 2);
        text += ')';
    }
    return $('<div>').text(text);
}

AppOptionRow = function(option, app, options) {
    var selected = undefined;
    if (app[option.name] !== undefined) {
        selected = app[option.name];
    }
    if (option.defaultVal !== undefined) {
        selected = option.defaultVal;
    }
    if (options !== undefined && options[option.name] !== undefined) {
        selected = options[option.name];
    }

    var div = $('<tr>');
    var nameEl = $('<td>').text(option.name);
    div.append(nameEl);
    var tdSel = $('<td class="option-input">');
    div.append(tdSel);
    switch (option.type) {
        case 'select':
        var select = $('<select class="form-control view-app-option" app-option-name="' + option.name + '" id="view-app-option-' + option.name + '">');
        tdSel.append(select);
        for (var j in option.values) {
            var optEl = $('<option value="' + option.values[j] + '">' + option.values[j] + '</option>');
            if (selected !== undefined && selected == option.values[j]) {
                optEl.prop('selected', true);
            }
            select.append(optEl);
        }
        break;
        case 'text':
            var input = $('<input type="text" class="form-control" app-option-name="' + option.name + '" id="view-app-option-' + option.name + '">');
            input.val(option.defaultVal);
            tdSel.append(input);
            break;
        case 'number':
            var tagText = '<input type="number" class="form-control"';
            if (option.min !== null) {
                tagText += ' min=' + option.min;
            }
            if (option.max !== null) {
                tagText += ' max=' + option.max;
            }

            if (option.step !== null) {
                tagText += ' step=' + option.step;
            }
            if (selected !== null && selected !== undefined) {
                tagText += ' value=' + selected;
            } else {
                tagText += ' value=' + option.defaultVal;
            }
            var input = $(tagText + ' class="view-app-option form-control" app-option-name="' + option.name + '" id="view-app-option-' + option.name + '">');
            tdSel.append(input);
            break;
    }
    var description = option.description;
    if (description === undefined) {
        description = 'None given.';
    }
    div.append($('<td>').text(description));
    return div;

}

AppOptionDiv = function(option, selected) {
    var div = $('<div class="form-group row option-div">');
    var nameEl = $('<label for="view-app-option-' + option.name + '" class="option-label col-form-label">').text(option.name + ': ');
    div.append(nameEl);
    var tdSel = $('<div class="option-input">');
    div.append(tdSel);
    switch (option.type) {
        case 'select':
        var select = $('<select class="form-control view-app-option" app-option-name="' + option.name + '" id="view-app-option-' + option.name + '">');
        tdSel.append(select);
        for (var j in option.values) {
            var optEl = $('<option value="' + option.values[j] + '">' + option.values[j] + '</option>');
            if (selected !== undefined && selected == option.values[j]) {
                optEl.prop('selected', true);
            }
            select.append(optEl);
        }
        break;
        case 'text':
            var input = $('<input type="text" class="form-control" app-option-name="' + option.name + '" id="view-app-option-' + option.name + '">');
            input.val(option.defaultVal);
            tdSel.append(input);
            break;
        case 'number':
            var tagText = '<input type="number" class="form-control"';
            if (option.min !== null) {
                tagText += ' min=' + option.min;
            }
            if (option.max !== null) {
                tagText += ' max=' + option.max;
            }

            if (option.step !== null) {
                tagText += ' step=' + option.step;
            }
            if (selected !== null && selected !== undefined) {
                tagText += ' value=' + selected;
            } else {
                tagText += ' value=' + option.defaultVal;
            }
            var input = $(tagText + ' class="view-app-option form-control" app-option-name="' + option.name + '" id="view-app-option-' + option.name + '">');
            tdSel.append(input);
            break;
    }
    return div;
}

jt.AppRow = function(app, options, cols) {

    if (cols === undefined) {
        cols = ['id', 'name', 'description'];
    }

    var row = $('<tr>');

    if (app.indexInSession !== undefined) {
        app.index = app.indexInSession;
    }

    if (app.indexInQueue !== undefined) {
        app.index = app.indexInQueue;
    }

    try {

        row.data('appId', app.id);

        for (var i in cols) {
            var col = cols[i];
            switch(col) {
            case '#':
                row.append($('<td>').text(app.index));
                break;
            case 'id':
                row.append($('<td>').text(app.id));
                break;
            case 'description':
                row.append($('<td>').text((app.description)));
                break;
            case 'name':
                row.append($('<td>').text((app.name !== undefined ? app.name : app.id)));
                break;
                case 'optionsView':
                    var optionsEl = $('<td style="display: flex; flex-wrap: wrap; padding-top: calc(.375rem - 1px);">');
                    for (var i in app.options) {
                        var option = app.options[i];
                        var selected = undefined;
                        if (app[option.name] !== undefined) {
                            selected = app[option.name];
                        }
                        if (option.defaultVal !== undefined) {
                            selected = option.defaultVal;
                        }
                        if (options !== undefined && options[option.name] !== undefined) {
                            selected = options[option.name];
                        }
                        var div = $('<div>').text(option.name + ': ' + selected);
                        optionsEl.append(div);
                    }
                    row.append(optionsEl);
                    break;
            case 'options':
                var optionsEl = $('<td style="display: flex; flex-wrap: wrap; padding-top: calc(.375rem - 1px);">');
                for (var i in app.options) {
                    var option = app.options[i];
                    var selected = undefined;
                    if (app[option.name] !== undefined) {
                        selected = app[option.name];
                    }
                    if (option.defaultVal !== undefined) {
                        selected = option.defaultVal;
                    }
                    if (options !== undefined && options[option.name] !== undefined) {
                        selected = options[option.name];
                    }
                    var div = AppOptionDiv(option, selected);
                    optionsEl.append(div);
                }
                row.append(optionsEl);
                break;
            }
        }

    } catch (err) {}

    return row;
}

jt.QueueRow = function(queue, cols) {

    if (cols === undefined) {
        cols = ['id', 'apps'];
    }

    var row = $('<tr>');

    row.data('queueId', queue.id);

    for (var i in cols) {
        var col = cols[i];
        switch(col) {
        case 'id':
            row.append($('<td>').text(queue.id));
            break;
        case 'apps':
            var appsEl = $('<td>');
            for (var i in queue.apps) {
                var app = queue.apps[i];
                var div = QueueAppDiv(app);
                appsEl.append(div);
            }
            row.append(appsEl);
            break;
        }
    }

    return row;
}

jt.DeleteButton = function() {
    return $(`<button class="btn btn-sm btn-outline-secondary">
        <i class="fa fa-trash" title="delete"></i>
    </button>`);
}

jt.CopyButton = function() {
    return $(`<button class="btn btn-sm btn-outline-secondary">
        <i class="fa fa-copy" title="copy"></i>
    </button>`);
}

jt.PlayerRow = function(player) {
    var div = $('<tr class="player-' + player.id +'">');
    div.append($('<td>').text(player.id));
    return div;
}

jt.setSubView = function(viewName, subViewName) {
    $('.' + viewName + '-tab').addClass('hidden');
    $('#view-' + viewName + '-' + subViewName).removeClass('hidden');
    $('.' + viewName + '-tabBtn').removeClass('active');
    $('#tab-' + viewName + '-' + subViewName).addClass('active');
}
