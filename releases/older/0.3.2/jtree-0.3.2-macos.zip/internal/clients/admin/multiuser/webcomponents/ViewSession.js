class ViewSession extends HTMLElement {
    connectedCallback() {
      this.innerHTML = `
      <div id='view-session' class='view hidden'>

          <h2 id='session-id'></h2>

          <!-- SESSION CONTROLS -->
          <div class='btn-group mb-3'>
              <span class='btn btn-outline-primary btn-sm' onclick='server.sessionAdvanceSlowest();'>
                  <i class="fa fa-play"></i>&nbsp;&nbsp;Start / advance slowest
              </span>
            <button class="btn btn-outline-secondary btn-sm" onclick='setView("edit-app")'>
                <i class="fa fa-copy"></i>&nbsp;&nbsp;Duplicate
            </button>
            <button class="btn btn-outline-secondary btn-sm" onclick='jt.deleteSession()'>
                <i class="fa fa-trash"></i>&nbsp;&nbsp;Delete
            </button>
          </div>

          <!-- SESSION TABS -->
          <ul class="nav nav-tabs">
            <li class="nav-item">
              <div id='tab-session-general' class="nav-link subview-tab session-tabBtn" onclick='jt.setSessionView("general");'>
                  <i class="fa fa-wrench"></i>&nbsp;&nbsp;Settings
              </div>
            </li>
            <li class="nav-item">
              <div id='tab-session-appqueue' class="nav-link subview-tab session-tabBtn" onclick='jt.setSessionView("appqueue");'>
                  <i class="fa fa-list-ol"></i>&nbsp;&nbsp;Apps
              </div>
            </li>
            <li class="nav-item">
              <div id='tab-session-participants' class="nav-link subview-tab session-tabBtn" onclick='jt.setSessionView("participants");'>
                  <i class="fa fa-user"></i>&nbsp;&nbsp;Participants
              </div>
            </li>
            <li class="nav-item">
                <span id='tab-session-activity' class='nav-link subview-tab session-tabBtn' onclick='jt.setSessionView("activity");'>
                    <i class="fa fa-eye"></i>&nbsp;&nbsp;Monitor
                </span>
            </li>
            <li class="nav-item">
                <span id='tab-session-results' class='nav-link subview-tab session-tabBtn' onclick='jt.setSessionView("results");'>
                <i class="fa fa-chart-bar"></i>&nbsp;&nbsp;Data
            </span>
            </li>
          </ul>

          <!-- SESSION - SETUP -->
          <div id='view-session-general' class='session-tab hidden'>

              <div class='tab-grid'>
                  <div>Number of participants</div>
                  <div>
                      <div>
                          <input id='setNumParticipants' style='width: 3em;' type='number' min='0' step='1'>
                          <button type="button" class="btn btn-sm btn-primary" onclick='setNumParticipants();'>Set</button>
                          <small class="form-text text-muted">
                              Setting the number of participants will turn off login of new participants. Participants are added from the list of session participant IDs. More recent participants are removed first.
                          </small>
                      </div>
                  </div>
                  <div>Participant labels</div>
                  <div>
                      <div>
                          <textarea id='setParticipantLabels' cols=80 rows=10></textarea>
                      </div>
                      <button type="button" class="btn btn-sm btn-primary" onclick='setParticipantLabelss();'>Set</button>
                      <small class="form-text text-muted">
                          Each label should be seperated by a comma and/or new line. Setting the participant labels will turn off login of new participants and set the number of participants.
                      </small>
                  </div>
                  <div>Login of new participants</div>
                  <div>
                      <div class="form-check">
                          <input class="form-check-input" type="checkbox" value="" id="allowNewParts" onclick='server.setAllowNewParts();'>
                          <label class="form-check-label" for="allowNewParts">
                              Allow
                          </label>
                      </div>
                      <small class="form-text text-muted">
                          This allows clients to log in as a participant before the participant exists in the session. It does not prevent clients logging in as participants that already exist in the session.
                      </small>
                  </div>

                  <div>
                      Delete participant
                  </div>
                  <div>
                      <select id='deleteParticipantSelect'></select>
                      <button type="button" class="btn btn-sm btn-primary" onclick='deleteParticipantBtn();'>Delete</button>
                      <small class="form-text text-muted">
                          Delete the given participant from the session. Make sure to turn off login of new participants if you wish to prevent clients from re-creating this participant.
                      </small>
                  </div>
                  <div>Labels</div>
                  <div>This is the list of labels for participants.</div>
              </div>

          </div>

          <!-- SESSION - APPS -->
          <div id='view-session-appqueue' class='session-tab hidden'>

              <div class='btn-group mb-3'>
                  <button type='button' class='btn btn-outline-primary btn-sm' onclick='jt.showAddAppToSessionModal();'>
                      <i class="fa fa-plus"></i>&nbsp;&nbsp;add App...
                  </button>
                  <button type='button' class='btn btn-outline-primary btn-sm' onclick='jt.showAddQueueToSessionModal();'>
                      <i class="fa fa-plus"></i>&nbsp;&nbsp;add Queue...
                  </button>
              </div>

                    <table class='table' style='width: 100% !important;'>
                        <thead>
                            <tr>
                                <th></th>
                                <th>#</th>
                                <th>id</th>
                                <th>options</th>
                            </tr>
                        </thead>
                        <tbody id='session-apps-table'></tbody>
                    </table>
          </div>

          <!-- SESSION - LINKS -->
          <div id='view-session-participants' class='session-tab hidden'>
              <table class='table table-hover table-bordered'>
                  <thead>
                      <tr id='session-participants-headers'></tr>
                  </thead>
                  <tbody id='participants'>
                  </tbody>
              </table>
          </div>

          <!-- SESSION - ACTIVITY -->
          <div id='view-session-activity' class='session-tab hidden'>
              <div class='btn-group mb-3'>
                  <span class="btn btn-outline-primary btn-sm" onclick='viewAllParticipants()'>
                      <i class="fa fa-eye"></i>&nbsp;&nbsp;show all
                  </span>
                  <span class="btn btn-outline-primary btn-sm" onclick='hideAllParticipants()'>
                      <i class="fa fa-times"></i>&nbsp;&nbsp;close all
                  </span>
                  <span class='btn btn-outline-primary btn-sm' id='startAutoplay' onclick='server.setAutoplayForAll(true);'>
                      <span class='px-1' style='border: 1px solid; border-radius: 0.3rem;'>A</span>&nbsp;&nbsp;start autoplay
                  </span>
                  <span class='btn btn-outline-primary btn-sm' id='stopAutoplay' onclick='server.setAutoplayForAll(false);'>
                      <span>A</span>&nbsp;&nbsp;stop autoplay
                  </span>
                  <span class="btn btn-outline-primary btn-sm" onclick='jt.setViewSize()'>
                      <i class="fa fa-expand"></i>&nbsp;&nbsp;set size...
                  </span>
              </div>
              <div id='views'></div>
          </div>

          <!-- SESSION - RESULTS -->
          <div id='view-session-results' class='session-tab hidden'>

              <div class='hidden'>
                  <div>Link to session output:&nbsp;</div>
                  <a href='#' target='_blank' id='view-session-results-filelink'></a>
              </div>

              <div>
                  Variable name: <input type='text' id='chartVarName'></input>
              </div>

              <div>
                  Variable select: <select type='text' id='chartVarSelect'></select>
              </div>
  <br>
              <div>
                  X-axis: <select id='chartSeries'>
                      <option value='periods'>Periods</option>
                      <option value='apps'>Apps</option>
                      <option value='groups'>Groups</option>
                      <option value='participants'>Participants</option>
                      <option value='fields'>Fields</option>
                  </select>
              </div>
  <br>
  <div>
      Series: <select id='chartXAxis'>
          <option value='participants'>Participants</option>
          <option value='groups'>Groups</option>
          <option value='periods'>Periods</option>
          <option value='apps'>Apps</option>
          <option value='fields'>Fields</option>
      </select>
  </div>
  <br>
              <span class='btn btn-outline-primary btn-sm' onclick='jt.chartVar();'>Update</span>
  <br>
  <div>FILTERS</div>
              <div>Apps: all / select</div>
              <div>Periods: all / select</div>
              <div>Groups: all / select</div>
              <div>Players: all / select</div>

              <div class="chart-container" style="position: relative; height:30vh; width:60vw">
                  <canvas id='session-data-chart'></canvas>
              </div>

          </div>

      </div>
      `;
    }
}

function updateSessionApps() {
    $('#session-apps-table').empty();
    if (jt.data.session !== null && jt.data.session !== undefined) {
        for (var a in jt.data.session.apps) {

            var app = jt.data.session.apps[a];

            var row = jt.AppRow(app, app.optionValues, ['#', 'id', 'options']);
            row.data({aId: app.id, i:a, sId: jt.data.session.id});
            $(row).find('[app-option-name]').change(function() {
                var data = $(this).parents('tr').data();
                data.name = $(this).attr('app-option-name');
                data.value = $(this).val();
                jt.socket.emit('setSessionAppOption', data);
            });
            var actionsEl = $('<td>');

            var deleteBtn = jt.DeleteButton();
            deleteBtn.click(function(ev) {
                 server.sessionDeleteApp($(this).parents('tr').data());
            });
            actionsEl.append(deleteBtn);
            row.prepend(actionsEl);

            $('#session-apps-table').append(row);
        }
    }
}

function updateSessionCanPlay(session) {
    if (session.isRunning) {
        $('#sessionResumeBtn').addClass('disabled');
        $('#sessionPauseBtn').removeClass('disabled');
        $('#session-canPlay').text('running');
    } else {
        $('#sessionResumeBtn').removeClass('disabled');
        $('#sessionPauseBtn').addClass('disabled');
        $('#session-canPlay').text('paused');
    }
}

function updateSessionActive(session) {
    if (session.active) {
        $('#sessionSetActiveBtn').addClass('disabled');
        $('#sessionSetInactiveBtn').removeClass('disabled');
        $('#session-status').text('active');
    } else {
        $('#sessionSetActiveBtn').removeClass('disabled');
        $('#sessionSetInactiveBtn').addClass('disabled');
        $('#session-status').text('inactive');
    }
}

deleteParticipantBtn = function() {
    var pId = $('#deleteParticipantSelect').val();
    server.deleteParticipant(pId);
}

function ParticipantRow(participant) {
    var div = $('<tr class="participant-' + participant.id +'">');
    div.append($('<td>').text(participant.id));
    div.append($('<td><a href="http://' + partLink(participant.id) + '" target="_blank">' + partLink(participant.id) + '</a></td>'));
    div.append($('<td class="participant-' + participant.id + '-numClients">').text(participant.numClients));
//    div.append($('<td class="participant-' + participant.id + '-numPoints">').text(round(participant.numPoints, 2)));
    div.append($('<td id="app-' + participant.id + '">').text('-'));
//    div.append($('<td class="participant-' + participant.id + '-appIndex">').text('-'));
    var periodDiv = $('<td>');
    periodDiv.append($('<span class="participant-' + participant.id + '-periodIndex">').text('-'));
    div.append(periodDiv);
    div.append($('<td class="participant-' + participant.id + '-groupId">').text('-'));
    div.append($('<td class="participant-' + participant.id + '-stageId">').text('-'));
    div.append($('<td class="participant-' + participant.id + '-timeleft"><span class="minutes"></span>:<span class="seconds"></span></td>'));
    div.append($('<td class="participant-' + participant.id + '-status">').text('-'));
    return div;
}

function sessionSetAutoplay(b) {
    const iframes = $('iframe.participant-frame');
    for (let i=0; i<iframes.length; i++) {
        let pId = $(iframes[i]).data('pId');
        setParticipantAutoplay(pId, b);
    }
}

function addParticipantPlayerHeader(name) {
    var headers = $('#session-participants-headers');
    headers.append($('<th>').text(name));
    var trows = $('#participants > tr');
    for (var i=0; i<trows.length; i++) {
        var tr = trows[i];
        var id = tr.children[0].innerHTML;
        var td = $('<td class="player-' + id + '-' + name +'">');
        $(tr).append(td);
    }
}

// DRAG-DROP UI
function showPanel(t, tt, ll, hh, ww, bb, rr, override) {
    var el = $(t);
    el.removeAttr('hidden');
}

function Panel(id, title, contentEl) {
    var card;
    var search = $('#panel-' + id);
    if (search.length > 0) {
        card = $(search[0]);
    } else {
        card = $('<div class="card panel ui-widget-content">');
        card.attr('id', 'panel-' + id);
        var cardHeader = $('<div>');
        cardHeader.addClass('card-header');
        card.append(cardHeader);
        var headerText = $('<span>').text(title);
        cardHeader.append(headerText);
    }
    // Set z-Index
    if (contentEl !== null) {
        // Close previous view, if any.
        $(card).find('.panel-content2').remove();

        card.append(contentEl);
        $(contentEl).addClass('panel-content2');
    }
    return card;
}

function participantOpenInNewTab() {
    for (var i in selectedParticipants) {
        var pId = selectedParticipants[i];
        participantOpenInNewTabId(pId);
    }
}

function participantOpenInNewTabId(id) {
    window.open("http://" + partLink(id));
}

function CardPanel(id, title, contentEl) {
    var cardBlock = $('<div class="card-block panel-content">');
    cardBlock.append(contentEl);
    var card = new Panel(id, title, cardBlock);
    return card;
}

function addCardPanel(id, title, contentEl) {
    var panel = new CardPanel(id, title, contentEl);
    panel.attr('hidden', true);
    $('body').append(panel);
    return panel;
}
function addPanel(id, title, contentEl) {
    var panel = new Panel(id, title, contentEl);
    panel.attr('hidden', true);
    $('body').append(panel);
    return panel;
}

function showParticipants(participants) {
    resetParticipantsTable();
    sessionSetAutoplay(false);
    if (participants !== undefined) {
        for (var pId in participants) {
            var participant = participants[pId];
            showParticipant(participant);
        }
    }
}

function resetParticipantsTable() {
    $('#participants').empty();
    $('#session-participants-headers').empty();
    const headers = ['id', 'link', 'clients', 'app', 'period', 'group', 'stage', 'time', 'status'];
    for (let i=0; i<headers.length; i++) {
        $('#session-participants-headers').append($('<th>').text(headers[i]));
    }
}

function viewAllParticipants() {
    for (var pId in jt.data.session.participants) {
        var participant = jt.data.session.participants[pId];
        viewParticipant(participant.id);
    }
}

function hideAllParticipants() {
    $('#views').empty();
}

jt.closeParticipantView = function(pId) {
    $('#panel-session-participant-' + pId).remove();
}

jt.refreshParticipantView = function(pId) {
    var panel = $('#participant-frame-' + pId)[0];
    panel.src = panel.src;
}

function viewParticipant(pId) {
    const view = new ParticipantView(pId);
    const elId = 'session-participant-' + pId;
    const existsAlready = $('#panel-' + elId).length > 0;
    const panel = addPanel(elId, 'Participant ' + pId, view);
    $('#panel-' + elId).addClass('participant-view');
    if (!existsAlready) {

        var closeBtn = $('<button type="button" class="headerBtn close float-right"><i title="close" class="fa fa-times"></i></button>');
        closeBtn.click(function() {
            jt.closeParticipantView(pId);
        });
        $($(panel).children()[0]).append(closeBtn);

        var newWinBtn = $('<button type="button" class="headerBtn close float-right"><i title="open in new window" class="fa fa-external-link-alt"></i></button>');
        newWinBtn.click(function() {
            participantOpenInNewTabId(pId);
        });
        $($(panel).children()[0]).append(newWinBtn);

        var autoplayBtn = $('<button title="toggle autoplay" id="' + pId + '-autoplay" type="button" class="headerBtn close float-right">A</button>');
        autoplayBtn.click(function() {
            toggleParticipantAutoplay(pId);
        });
        $($(panel).children()[0]).append(autoplayBtn);

        var refreshBtn = $('<button type="button" class="headerBtn close float-right"><i title="refresh" class="fa fa-redo-alt"></i></button>');
        refreshBtn.click(function() {
            jt.refreshParticipantView(pId);
        });
        $($(panel).children()[0]).append(refreshBtn);

    }
    showPanel('#panel-' + elId, 0, 0, '', '', '', '', false);
    $('#views').append(panel);
}

function toggleParticipantAutoplay(pId) {
    const elId = 'panel-session-participant-' + pId;
    const el = $('#' + elId);
    const apEl = $('#' + pId + '-autoplay');
    setParticipantAutoplay(pId, !apEl.hasClass('headerBtn-on'));
}

function setParticipantAutoplay(pId, b) {
    const elId = 'panel-session-participant-' + pId;
    const el = $('#' + elId);
    const apEl = $('#' + pId + '-autoplay');
    if (b) {
        apEl.addClass('headerBtn-on');
    } else {
        apEl.removeClass('headerBtn-on');
    }
    server.setAutoplay(pId, b);
    // let iframe = el.find('iframe')[0];
    // if (iframe.contentWindow.setAutoplay !== undefined) {
    //     iframe.contentWindow.setAutoplay(b);
    // }
}

function showParticipant(participant) {
    var participantRow = new ParticipantRow(participant);
    $('#participants').append(participantRow);
    if (participant.player !== null) {
        var playerRow = jt.PlayerRow(participant.player);
        $('#session-data').append(playerRow);
        participant.player.participant = participant;
        setParticipantPlayer(participant.id, participant.player, participantRow);
    }

    $('#deleteParticipantSelect').prepend($('<option>', {
        value: participant.id,
        text: participant.id
    }));

    $('#deleteParticipantSelect').val(participant.id);
}

jt.updateChartPage = function() {

}

jt.chartVar = function() {

    var colors = [
        "#3e95cd", '#3366cc', '#dc3912', '#ff9900', '#109618', '#990099',
        '#0099c6', '#dd4477', '#66aa00', '#b82e2e', '#316395', '#3366cc'
    ]
    var colorIndex = 0;

    var varName = $('#chartVarName').val();

    var ctx = document.getElementById('session-data-chart').getContext('2d');

    var data = {};
    data.datasets = [];
    data.labels = [];

    // Series
    for (var i in jt.data.session.participants) {
        var dataset = {};
        dataset.label = jt.data.session.participants[i].id
        dataset.fill = false;
        dataset.data = [];
        var color = colors[colorIndex++]
        dataset.borderColor = color;
        dataset.pointBorderColor = color;
        dataset.pointBackgroundColor = color;
        dataset.backgroundColor = color;
        data.datasets.push(dataset);
    }

    // X-Axis
    if (jt.data.session.apps.length < 1) {
        return;
    }
    var appId = 0;
    var periods = jt.data.session.apps[appId].periods;
    for (var i in periods) {

        // Add the period as a label
        data.labels.push(periods[i].id);

        // For each series, add a data point, or blank if missing
        for (var d in data.datasets) {
            var dataset = data.datasets[d];
            playerSearch: {
                for (var g in periods[i].groups) {
                    var group = periods[i].groups[g];
                    for (var pl in group.players) {
                        var player = group.players[pl];
                        if (dataset.label === player.id) {
                            // Found player for this dataset, store their data point and quit search.
                            dataset.data.push(player[varName]);
                            break playerSearch;
                        }
                    }
                }
                // If missing, add -1.
                dataset.data.push(-1);
            }
        }
    }


    var options = {
        legend: {
            position: 'right'
        },
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero:true
                },
                scaleLabel: {
                    display: true,
                    labelString: varName
                }
            }],
            xAxes: [{
                scaleLabel: {
                    display: true,
                    labelString: 'Period'
                }
            }]
        },
        elements: {
            line: {
                tension: 0, // disables bezier curves
            }
        }
    }

    var chartInfo = {type: 'line', data: data, options: options};

    var myChart = new Chart(ctx, chartInfo);

}

updateAllowNewParts = function() {
    $('#allowNewParts')[0].checked = jt.data.session.allowNewParts;
}

// VARIABLES
var playerFieldsToSkip = [
    'app',
    'appIndex',
    'clients',
    'group',
    'groupId',
    'id',
    'link',
    'numPoints',
    'participantId',
    'period',
    'roomId',
    'sessionId',
    'stageId',
    'stage',
    'stageIndex',
    'stageTimerStart',
    'stageTimerDuration',
    'stageTimerTimeLeft',
    'stageTimerRunning',
    'status',
    'time',
    'participant'
];

function ParticipantView(pId) {
    if (jt.data.session !== null && jt.data.session !== undefined) {
        var url = 'http://' + partLink(pId);
        var frame = $('<iframe>', {
            id:  'participant-frame-' + pId
        });
        $(frame).data('pId', pId);
        frame.attr('src', url);
        frame.addClass('participant-frame');
        return frame;
   } else {
       return null;
   }
}

function setPlayerTimeLeft(participant, tl) {
    $('#timeleft-' + participant.id).text(tl);
}

function showPlayerCurPeriod(participant, p) {
    $('#period-' + participant.id).text(p);
}

function setParticipantPlayer(pId, player, pDiv) {

    // Get the set of current headers
    var headers = $('#session-participants-headers > th');
    var headersText = [];

    // For each of the current headers, try to add a value for the player.
    for (var j=0; j<headers.length; j++) {
        var field = headers[j].innerHTML;
        if (!playerFieldsToSkip.includes(field)) {
            var foundEl = pDiv.find('.player-' + pId + '-' + field).length > 0;
            var value = '';
            if (player !== null) {
                if (player[field] !== undefined) {
                    value = player[field];
                }
            } else {
                foundEl = false;
            }
            if (!foundEl) {
                pDiv.append($('<td class="player-' + pId + '-' + field +'">'));
            }
            headersText.push(field);
            pDiv.find('.player-' + pId + '-' + field).text(roundValue(value, 2));
        }
    }

    // For each value in the player object,
    for (var i in player) {
        if (!playerFieldsToSkip.includes(i)) {
            if (!headersText.includes(i)) {
                addParticipantPlayerHeader(i);
                headersText.push(i);
            }
            pDiv.find('.player-' + pId + '-' + i).text(roundValue(player[i], 2));
        }
    }
    if (player !== null) {
        $('.participant-' + pId + '-status').text(player.status);
        if (player.status === 'active') {
            pDiv.addClass('player-active');
        } else {
            pDiv.removeClass('player-active');
        }
        var gId = groupId(player.groupId);
        if (player.group !== undefined) {
            gId = player.group.id;
        }
        msgs.playerSetStageIndex({participantId: player.id, stageIndex: player.stageIndex});
        msgs.participantSetGroupId({participantId: player.id, groupId: gId});
        clearInterval(participantTimers[pId]);
        if (player.stageTimerDuration === undefined) {
            var div = $('.participant-' + pId + '-timeleft');
            div.find('.minutes').text('');
            div.find('.seconds').text('');
        } else {
            if (player.stageTimerRunning) {
                var tl = player.stageTimerTimeLeft;
                var st = player.stageTimerStart;
                player.endTime = new Date(st).getTime() + tl;
                var now = Date.now();
                player.timeLeft = player.endTime - now;
                player.stageTimer = setInterval(function() {
                    var now = Date.now();
                    player.timeLeft = player.endTime - now;
                    if (player.timeLeft <= 0) {
                        clearTimeout(player.stageTimer);
                    }
                    var div = $('.participant-' + pId + '-timeleft');
                    var minutes = div.find('.minutes');
                    var seconds = div.find('.seconds');
                    jt.displayTimeLeft(minutes, seconds, player.timeLeft);
                }, jt.data.CLOCK_FREQUENCY);
                participantTimers[pId] = player.stageTimer;
            } else {
                player.timeLeft = player.stageTimerTimeLeft;
            }
            var div = $('.participant-' + pId + '-timeleft');
            var minutes = div.find('.minutes');
            var seconds = div.find('.seconds');
            jt.displayTimeLeft(minutes, seconds, player.timeLeft);
        }
    }

    let participant = player.participant;
    showPlayerCurApp(participant);
    $('.participant-' + participant.id + '-periodIndex').text(participant.periodIndex+1);

}

function addQueue(event) {
    event.stopPropagation();
    console.log('add queue to session: ' + event.data.id + ', name = ' + event.data.name);
    server.addQueue(event.data.id);
}

function addAppToSession(event) {
    event.stopPropagation();
    console.log('add app to session: ' + event.data.id + ', name = ' + event.data.name);
    server.addAppToSession({id: event.data.id, sId: data.session.id});
}

jt.deleteSession = function() {
    var sId = $('#session-id').text();
    jt.confirm(
        'Are you sure you want to delete Session ' + sId + '?',
        function() {
            jt.socket.emit('deleteSession', sId);
        }
    );
}

jt.showAddAppToSessionModal = function() {
    $('#addAppToSessionModal').modal('show');
    $('#addAppToSessionModal-apps').empty();
    for (var i in jt.data.appInfos) {
        var app = jt.data.appInfos[i];
        var row = jt.AppRow(app, {}, ['id', 'description']);
        row.data('appId', app.id);

        row.click(function(ev) {
            if (
                ($(ev.target).prop('tagName') !== 'SELECT') &&
                ($(ev.target).prop('tagName') !== 'INPUT')
            ) {
                var optionEls = $(this).find('[app-option-name]');
                var options = jt.deriveAppOptions(optionEls);
                server.sessionAddApp($(this).data('appId'), options);
                $('#addAppToSessionModal').modal('hide');
            }
        });
        row.css('cursor', 'pointer');

        $('#addAppToSessionModal-apps').append(row);
    }
}

jt.showAddQueueToSessionModal = function() {
    $('#addQueueToSessionModal').modal('show');
    $('#addQueueToSessionModal-queues').empty();
    for (var i in jt.data.queues) {
        var queue = jt.data.queues[i];
        var row = jt.QueueRow(queue, ['id', 'apps']);
        row.css('cursor', 'pointer');
        row.data('queue', queue.id);

        row.click(function(ev) {
            server.sessionAddQueue($(this).data('queue'));
            $('#addQueueToSessionModal').modal('hide');
        });

        $('#addQueueToSessionModal-queues').append(row);
    }
}

function updatePartClock() {
    displayTimeLeft($('#clock-minutes'), $('#clock-seconds'), data.timeLeft);
}

closeViews = function() {
    var views = $('.participant-view');
    views.each(function() {
        this.remove();
    });
}

window.customElements.define('view-session', ViewSession);
