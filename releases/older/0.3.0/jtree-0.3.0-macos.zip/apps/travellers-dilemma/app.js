app.addPositiveIntegerOption('numPeriods', 3, null);
app.addSelectOption('groupMatchingType', ['STRANGER', 'PARTNER_RANDOM']);
app.groupSize   = 2;
app.lowerBound  = 10;
app.upperBound  = 50;

var decideStage = app.newStage('decide');

var resultsStage = app.newStage('results');
resultsStage.duration = 30; // in seconds
resultsStage.waitToStart = true;
resultsStage.groupStart = function(group) { // when a group starts this stage
    group.lowestNumber = null;
    // Find out winning number.
    for (var i in group.players) { // i = 0, 1, 2, 3
        var player = group.players[i];
        if (group.lowestNumber === null || player.number < group.lowestNumber) {
            group.lowestNumber = player.number;
        }
    }
    // Assign points
    for (var i in group.players) {
        var player = group.players[i];
        if (player.number <= group.lowestNumber) {
            player.points = 1;
        } else {
            player.points = 0;
        }
    }
}
