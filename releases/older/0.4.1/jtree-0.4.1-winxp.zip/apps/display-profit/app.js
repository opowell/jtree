app.description = 'Displays the profit (over all apps) for the player.';
var thankyouStage = app.newStage('finished');
