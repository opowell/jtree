// Send messages to server.
makeOfferToBuy = function() {
    var price = $('#offerToBuyPrice').val();
    sendMessage('makeOfferToBuy', price);
}
makeOfferToSell = function() {
    var price = $('#offerToSellPrice').val();
    sendMessage('makeOfferToSell', price);
}

// Checks for the client.
checkIfValidOTBPrice = function() {
    var otbInput = $('#offerToBuyPrice');
    var price = parseFloat(otbInput.val());
    var max = otbInput.attr('max');
    setButtonEnabled($('#makeOTBButton'), price <= max);
}
checkIfValidOTSPrice = function() {
    var input = $('#offerToSellPrice');
    var price = parseFloat(input.val());
    var shares = data.player.shares;
    setButtonEnabled($('#makeOTSButton'), shares > 0 && !isNaN(price));
}

// Run once the client page is loaded.
function connected() {
    // Listen to messages from server
    socket.on('auto-stage-data', function(player) {
        $('#offerToBuyPrice').attr('max', player.cash);
        checkIfValidOTBPrice();
        checkIfValidOTSPrice();
    });
}

/**
 Random choose action among:
 1. offer to buy (OTB)
 2. offer to sell (OTS)
 3. buy
 4. sell
 5. do nothing
**/

var prOTB = 0.3;
var prOTS = 0.3;
var prBUY = 0.1;
var prSELL = 0.1;
autoplay = function() {

    if (data.player.stage.name === 'trading') {
        var thOTB = prOTB;
        var thOTS = thOTB + prOTS;
        var thBUY = thOTS + prBUY;
        var thSELL = thBUY + prSELL;

        var x = Math.random();
        if (x < thOTB) {
            // offer to buy
            if (data.player.cash > 0) {
                var price = Math.random()*data.player.cash;
                $('#offerToBuyPrice').val(price);
                makeOfferToBuy();
            }
        } else if (x < thOTS) {
            // offer to sell
            if (data.player.shares > 0) {
                var price = Math.random()*data.player.cash;
                $('#offerToSellPrice').val(price);
                makeOfferToSell();
            }
        } else if (x < thBUY) {
            // buy
            let offers = data.player.group.offers;
            for (let i=0; i<offers.length; i++) {
                let offer = offers[i];
                if (offer.open) {
                    if (offer.seller === data.player.id) {
                        sendMessage('cancelOffer', offer.id);
                        return;
                    } else if (offer.price < data.player.cash) {
                        sendMessage('acceptOTS', offer.id);
                        return;
                    }
                }
            }
        } else if (x < thSELL) {
            // sell
            let offers = data.player.group.offers;
            for (let i=0; i<offers.length; i++) {
                let offer = offers[i];
                if (offer.open) {
                    if (offer.buyer === data.player.id) {
                        sendMessage('cancelOffer', offer.id);
                        return;
                    } else if (data.player.shares > 0) {
                        sendMessage('acceptOTB', offer.id);
                        return;
                    }
                }
            }
        }
        // else do nothing
        
    }

}
