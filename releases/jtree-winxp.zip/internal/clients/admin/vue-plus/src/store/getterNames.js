export const helloWorld = 'helloWorld'
