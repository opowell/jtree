document.write('<script src="/admin/ztree/components/modals/AppPropertiesModal.js"></script>');
document.write('<script src="/admin/ztree/components/modals/HTMLEditorModal.js"></script>');
document.write('<script src="/admin/ztree/components/modals/Modal.js"></script>');
document.write('<script src="/admin/ztree/components/modals/SelectAppModal.js"></script>');
document.write('<script src="/admin/ztree/components/modals/TableModal.js"></script>');
