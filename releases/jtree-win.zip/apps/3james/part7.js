stage.waitToStart = false;

// Display horizontally part 2, part 6 and part 7.

stage.content = `

<form class='cols3'>
    <span style='margin-bottom: 0.2rem;'>
        <div style='margin-top: 0rem; margin-bottom: 0rem;'>
            <p
                id='part7Task1'
                class='comprehension'
                task-name='the <b>first task</b> in Part 6'
                task-name-und='the first task in Part 6'
                task-desc='to guess a number such that you thought three of four randomly selected contributions from Part 5 was greater than or equal to that number, and the other one was less than that number. <br><br>Please answer the following questions about this Task'
                id-prefix='part7Task1'
                style='margin-bottom: 0.2rem;'>
            </p>
        </div>
        <div style='margin-top: 0rem; margin-bottom: 0rem;'>
            <p
                id='part7Task2'
                class='comprehension'
                task-name='the <b>second task</b> in Part 6'
                task-name-und='the second task in Part 6'
                task-desc='to guess a number such that you thought two of four randomly selected contributions from Part 5 were greater than that number, and the other two were less than or equal to that number. <br><br>Please answer the following questions about this Task'
                id-prefix='part7Task2'
                style='margin-bottom: 0.2rem;'>
            </p>
        </div>
        <div style='margin-top: 0rem; margin-bottom: 0rem;'>
            <p
                id='part7Task3'
                class='comprehension'
                task-name='the <b>third task</b> in Part 6'
                task-name-und='the third task in Part 6'
                task-desc='to guess a number such that you thought one of four randomly selected contributions from Part 5 was greater than that number, and the other three were less than or equal to that number. <br><br>Please answer the following questions about this Task'
                id-prefix='part7Task3'
                style='margin-bottom: 0.2rem;'>
            </p>
        </div>
    </span>

    <button>OK</button>
</form>

`

//stage.waitToEnd = true;
