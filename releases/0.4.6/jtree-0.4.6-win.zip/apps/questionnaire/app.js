app.description = 'Simple questionnaire.';

// DEFINE STAGES
var questionsStage = app.newStage('questions');
