app.addNumberOption('numPeriods', 5, 1, null, 1);
app.addNumberOption('outsideOption', 10, 1, null, 1);
app.addTextOption('payoffEqn', '10 + 15*(12 - player.group.numEnter);');
app.groupSize   = 2;
app.payoff = function(player) {
    if (player.enter) {
            return eval(this.payoffEqn);
        } else {
            return this.outsideOption;
        }
}

var decideStage = app.newStage('decide');

var resultsStage = app.newStage('results');
resultsStage.waitToStart = true;
resultsStage.duration = 30; // in seconds
resultsStage.groupStart = function(group) { // when a group starts this stage
    group.numEnter = 0;
    // Find out winning number.
    for (var i in group.players) { // i = 0, 1, 2, 3
        var player = group.players[i];
        if (player.enter) {
            group.numEnter++;
        }
    }
    // Assign points
    for (var i in group.players) {
        var player = group.players[i];
        player.points = app.payoff(player);
    }
}
