var inputStage = app.newStage('input');
